# Supabase Integration Plan for Ice Cream POS System

## Overview
This plan outlines the migration from the current SQLite + localStorage system to Supabase for real-time data synchronization across multiple devices.

## Phase 1: Setup and Configuration

### 1.1 Install Supabase Dependencies
```bash
npm install @supabase/supabase-js
npm install --save-dev @supabase/cli
```

### 1.2 Environment Variables Setup
Create `.env` file with Supabase credentials:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 1.3 Database Schema Migration
Create SQL tables in Supabase that mirror your current SQLite structure:

#### Branches Table
```sql
CREATE TABLE branches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  is_active BOOLEAN DEFAULT true,
  manager_id UUID,
  settings JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### Users Table
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'cashier', 'manager', 'owner')),
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  password_hash TEXT NOT NULL,
  branch_id UUID REFERENCES branches(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### Categories Table
```sql
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  branch_id UUID REFERENCES branches(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### Products Table
```sql
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  category_id UUID REFERENCES categories(id),
  category TEXT NOT NULL,
  base_price DECIMAL(10,2) NOT NULL,
  image TEXT,
  is_active BOOLEAN DEFAULT true,
  variants JSONB DEFAULT '[]',
  branch_id UUID REFERENCES branches(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### Orders Table
```sql
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT NOT NULL,
  items JSONB NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  tax DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  payment_method TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('completed', 'cancelled', 'refunded')),
  customer_name TEXT,
  customer_note TEXT,
  cashier_id UUID REFERENCES users(id),
  cashier_name TEXT NOT NULL,
  branch_id UUID REFERENCES branches(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### Customers Table
```sql
CREATE TABLE customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  loyalty_points INTEGER DEFAULT 0,
  total_spent DECIMAL(10,2) DEFAULT 0,
  last_visit TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  branch_id UUID REFERENCES branches(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 1.4 Row Level Security (RLS) Setup
Enable RLS and create policies for each table:

```sql
-- Enable RLS on all tables
ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

-- Branch-based access policies
CREATE POLICY "Users can access their branch data" ON branches
  FOR ALL USING (auth.uid() IN (
    SELECT id FROM users WHERE branch_id = branches.id
  ));

CREATE POLICY "Users can access their branch users" ON users
  FOR ALL USING (branch_id IN (
    SELECT branch_id FROM users WHERE id = auth.uid()
  ));

-- Similar policies for other tables...
```

## Phase 2: Service Layer Migration

### 2.1 Create Supabase Client
```typescript
// src/services/supabase.ts
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
```

### 2.2 Replace Database Service
Create new `SupabaseService` to replace current `DatabaseService`:

```typescript
// src/services/supabaseService.ts
import { supabase } from './supabase'
import type { Product, Order, User, Branch, Category, Customer } from '../types'

export class SupabaseService {
  // Authentication
  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    return { data, error }
  }

  async signOut() {
    const { error } = await supabase.auth.signOut()
    return { error }
  }

  // Products
  async getProducts(branchId: string): Promise<Product[]> {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('branch_id', branchId)
      .eq('is_active', true)
      .order('name')

    if (error) throw error
    return data || []
  }

  async createProduct(product: Omit<Product, 'id'>): Promise<Product> {
    const { data, error } = await supabase
      .from('products')
      .insert([product])
      .select()
      .single()

    if (error) throw error
    return data
  }

  async updateProduct(product: Product): Promise<Product> {
    const { data, error } = await supabase
      .from('products')
      .update(product)
      .eq('id', product.id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  async deleteProduct(id: string): Promise<void> {
    const { error } = await supabase
      .from('products')
      .update({ is_active: false })
      .eq('id', id)

    if (error) throw error
  }

  // Orders
  async getOrders(branchId: string): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('branch_id', branchId)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  async createOrder(order: Omit<Order, 'id'>): Promise<Order> {
    const { data, error } = await supabase
      .from('orders')
      .insert([order])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Real-time subscriptions
  subscribeToProducts(branchId: string, callback: (payload: any) => void) {
    return supabase
      .channel('products-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products',
          filter: `branch_id=eq.${branchId}`
        },
        callback
      )
      .subscribe()
  }

  subscribeToOrders(branchId: string, callback: (payload: any) => void) {
    return supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `branch_id=eq.${branchId}`
        },
        callback
      )
      .subscribe()
  }
}

export const supabaseService = new SupabaseService()
```

## Phase 3: Hook Updates

### 3.1 Update useAuth Hook
```typescript
// src/hooks/useAuth.ts
import { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'
import { useApp } from '../context/AppContext'

export function useAuth() {
  const { dispatch } = useApp()
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null)
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    return { data, error }
  }

  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    return { error }
  }

  return {
    user,
    loading,
    signIn,
    signOut
  }
}
```

### 3.2 Update useProducts Hook
```typescript
// src/hooks/useProducts.ts
import { useEffect, useState } from 'react'
import { supabaseService } from '../services/supabaseService'
import { useApp } from '../context/AppContext'
import type { Product } from '../types'

export function useProducts() {
  const { state, dispatch } = useApp()
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (state.settings.currentBranchId) {
      loadProducts()
      
      // Subscribe to real-time changes
      const subscription = supabaseService.subscribeToProducts(
        state.settings.currentBranchId,
        (payload) => {
          console.log('Product change:', payload)
          // Handle real-time updates
          if (payload.eventType === 'INSERT') {
            dispatch({ type: 'ADD_PRODUCT', payload: payload.new })
          } else if (payload.eventType === 'UPDATE') {
            dispatch({ type: 'UPDATE_PRODUCT', payload: payload.new })
          } else if (payload.eventType === 'DELETE') {
            dispatch({ type: 'DELETE_PRODUCT', payload: payload.old.id })
          }
        }
      )

      return () => {
        subscription.unsubscribe()
      }
    }
  }, [state.settings.currentBranchId])

  const loadProducts = async () => {
    setLoading(true)
    try {
      const products = await supabaseService.getProducts(state.settings.currentBranchId)
      dispatch({ type: 'SET_PRODUCTS', payload: products })
    } catch (error) {
      console.error('Failed to load products:', error)
    } finally {
      setLoading(false)
    }
  }

  const addProduct = async (productData: Omit<Product, 'id'>) => {
    try {
      const product = await supabaseService.createProduct({
        ...productData,
        branch_id: state.settings.currentBranchId
      })
      // Real-time subscription will handle the state update
      return product
    } catch (error) {
      console.error('Failed to add product:', error)
      throw error
    }
  }

  const updateProduct = async (product: Product) => {
    try {
      const updatedProduct = await supabaseService.updateProduct(product)
      // Real-time subscription will handle the state update
      return updatedProduct
    } catch (error) {
      console.error('Failed to update product:', error)
      throw error
    }
  }

  const deleteProduct = async (id: string) => {
    try {
      await supabaseService.deleteProduct(id)
      // Real-time subscription will handle the state update
    } catch (error) {
      console.error('Failed to delete product:', error)
      throw error
    }
  }

  return {
    products: state.products,
    loading,
    addProduct,
    updateProduct,
    deleteProduct,
    loadProducts
  }
}
```

## Phase 4: Real-time Features

### 4.1 Real-time Order Updates
When a new order is created on the kiosk, it will automatically appear on your mobile device:

```typescript
// In your MenuView or OrdersView component
useEffect(() => {
  const subscription = supabaseService.subscribeToOrders(
    currentBranchId,
    (payload) => {
      if (payload.eventType === 'INSERT') {
        // New order created - show notification
        showNotification(`New order: ${payload.new.order_number}`)
        dispatch({ type: 'ADD_ORDER', payload: payload.new })
      }
    }
  )

  return () => subscription.unsubscribe()
}, [currentBranchId])
```

### 4.2 Live Inventory Updates
Product stock changes will sync across all devices:

```typescript
// Real-time inventory sync
const handleProductUpdate = (payload: any) => {
  if (payload.eventType === 'UPDATE') {
    const updatedProduct = payload.new
    dispatch({ type: 'UPDATE_PRODUCT', payload: updatedProduct })
    
    // Show low stock alert if needed
    if (updatedProduct.stock <= updatedProduct.min_stock) {
      showLowStockAlert(updatedProduct.name)
    }
  }
}
```

## Phase 5: Migration Strategy

### 5.1 Data Migration Script
Create a script to migrate existing data from SQLite to Supabase:

```typescript
// src/utils/migrateToSupabase.ts
import { dbService } from '../services/database'
import { supabaseService } from '../services/supabaseService'

export async function migrateDataToSupabase() {
  try {
    console.log('Starting data migration to Supabase...')
    
    // Migrate branches
    const branches = await dbService.getBranches()
    for (const branch of branches) {
      await supabaseService.createBranch(branch)
    }
    
    // Migrate users
    const users = await dbService.getUsers()
    for (const user of users) {
      await supabaseService.createUser(user)
    }
    
    // Migrate products
    const products = await dbService.getProducts()
    for (const product of products) {
      await supabaseService.createProduct(product)
    }
    
    // Migrate orders
    const orders = await dbService.getOrders()
    for (const order of orders) {
      await supabaseService.createOrder(order)
    }
    
    console.log('Data migration completed successfully!')
  } catch (error) {
    console.error('Migration failed:', error)
    throw error
  }
}
```

### 5.2 Gradual Migration
1. **Phase 1**: Set up Supabase alongside existing SQLite
2. **Phase 2**: Implement dual-write (write to both systems)
3. **Phase 3**: Migrate read operations to Supabase
4. **Phase 4**: Remove SQLite dependency

## Phase 6: Benefits After Migration

### 6.1 Real-time Synchronization
- ✅ Orders placed on kiosk appear instantly on mobile
- ✅ Product updates sync across all devices
- ✅ Inventory changes reflect immediately
- ✅ User actions visible to managers in real-time

### 6.2 Scalability
- ✅ Handle multiple branches and devices
- ✅ Support concurrent users
- ✅ Automatic backups and data recovery
- ✅ Performance optimization

### 6.3 Advanced Features
- ✅ Real-time analytics and reporting
- ✅ Push notifications for important events
- ✅ Offline support with automatic sync
- ✅ Role-based access control

## Implementation Timeline

**Week 1**: Supabase setup and schema creation
**Week 2**: Service layer migration and testing
**Week 3**: Hook updates and real-time features
**Week 4**: Data migration and production deployment

## Cost Considerations

Supabase pricing is based on:
- Database size
- API requests
- Bandwidth usage
- Real-time connections

For a small to medium ice cream business:
- **Free tier**: Up to 500MB database, 2GB bandwidth
- **Pro tier**: $25/month for larger usage
- **Team tier**: $125/month for multiple team members

## Next Steps

1. **Create Supabase account** and project
2. **Set up database schema** using the SQL provided
3. **Install dependencies** and configure environment
4. **Implement service layer** step by step
5. **Test real-time features** with multiple devices
6. **Migrate existing data** when ready

Would you like me to start implementing any specific part of this plan?