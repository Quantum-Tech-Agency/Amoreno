import { Order, InvoiceSettings } from '../types';

export interface PrintOptions {
  width?: number;
  fontSize?: number;
  fontFamily?: string;
  lineHeight?: number;
}

export function generate80mmReceipt(order: any, settings: any, isRTL: boolean = false, t: (key: string) => string): string {
  const invoiceSettings = settings.invoiceSettings || {};
  const width = invoiceSettings.paperSize === '58mm' ? 58 : 80;
  const charWidth = invoiceSettings.paperSize === '58mm' ? 32 : 42;
  
  const centerText = (text: string) => {
    const padding = Math.max(0, Math.floor((charWidth - text.length) / 2));
    return ' '.repeat(padding) + text;
  };

  const leftRightText = (left: string, right: string) => {
    const totalLength = left.length + right.length;
    const spaces = Math.max(1, charWidth - totalLength);
    return left + ' '.repeat(spaces) + right;
  };

  const line = '='.repeat(charWidth);
  const dottedLine = '-'.repeat(charWidth);

  const formatPrice = (price: number) => {
    return `${price.toLocaleString()} د.ع`;
  };

  // Significantly larger font sizes for better readability
  const getFontSize = () => {
    switch (invoiceSettings.fontSize) {
      case 'small': return '12px';
      case 'large': return '20px';
      default: return '16px'; // medium
    }
  };

  // Even larger font sizes for item names
  const getItemFontSize = () => {
    switch (invoiceSettings.fontSize) {
      case 'small': return '14px';
      case 'large': return '24px';
      default: return '20px'; // medium
    }
  };

  // Header font size
  const getHeaderFontSize = () => {
    switch (invoiceSettings.fontSize) {
      case 'small': return '16px';
      case 'large': return '28px';
      default: return '22px'; // medium
    }
  };

  // Secondary text font size
  const getSecondaryFontSize = () => {
    switch (invoiceSettings.fontSize) {
      case 'small': return '10px';
      case 'large': return '16px';
      default: return '14px'; // medium
    }
  };

  const currentBranch = settings.branches?.find((b: any) => b.id === settings.currentBranchId);
  
  // Get custom font if set
  const customFontFamily = settings.customFont 
    ? `"${settings.customFont}", "Noto Sans", "Noto Sans Arabic", system-ui, -apple-system, sans-serif`
    : `"Noto Sans", "Noto Sans Arabic", system-ui, -apple-system, sans-serif`;

  return `
<!DOCTYPE html>
<html dir="${isRTL ? 'rtl' : 'ltr'}" lang="${settings.language}">
<head>
  <meta charset="UTF-8">
  <title>${t('receipt')} - ${order.orderNumber}</title>
  <style>
    @page {
      size: ${width}mm auto;
      margin: 0;
    }
    
    body {
      font-family: ${customFontFamily};
      font-size: ${getFontSize()};
      line-height: 1.4;
      margin: 0;
      padding: 5mm;
      width: ${width - 10}mm;
      direction: ${isRTL ? 'rtl' : 'ltr'};
      color: #000;
      background: #fff;
    }
    
    .header {
      text-align: center;
      margin-bottom: 12px;
      ${invoiceSettings.showBusinessInfo ? 'border-bottom: 2px solid #000;' : ''}
      padding-bottom: 8px;
    }
    
    .business-name {
      font-size: ${getHeaderFontSize()};
      font-weight: bold;
      margin-bottom: 4px;
    }
    
    .header-text {
      font-size: ${getSecondaryFontSize()};
      margin: 4px 0;
      font-style: italic;
    }
    
    .branch-info {
      font-size: ${getSecondaryFontSize()};
      margin: 3px 0;
      color: #444;
    }
    
    .order-info {
      text-align: center;
      margin-bottom: 12px;
      font-size: ${getSecondaryFontSize()};
    }
    
    /* Table styling for items */
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 12px;
    }
    
    .items-table th {
      border-top: 1.5px solid #000;
      border-bottom: 1.5px solid #000;
      padding: 6px 3px;
      text-align: ${isRTL ? 'right' : 'left'};
      font-size: ${getSecondaryFontSize()};
      font-weight: bold;
    }
    
    .items-table td {
      padding: 6px 3px;
      border-bottom: 1px dotted #ccc;
      vertical-align: top;
    }
    
    .item-name {
      font-weight: bold;
      font-size: ${getItemFontSize()};
    }
    
    .item-variant {
      font-size: ${getSecondaryFontSize()};
      color: #555;
    }
    
    .item-price, .item-qty, .item-total {
      text-align: ${isRTL ? 'left' : 'right'};
      font-size: ${getSecondaryFontSize()};
      white-space: nowrap;
    }
    
    .item-total {
      font-weight: bold;
    }
    
    .totals {
      ${invoiceSettings.showTotal ? 'border-top: 2.5px solid #000;' : ''}
      padding-top: 8px;
      margin-top: 8px;
    }
    
    .total-line {
      display: flex;
      justify-content: space-between;
      margin: 2px 0;
      font-size: ${getFontSize()};
    }
    
    .grand-total {
      border-top: 1.5px solid #000;
      border-bottom: 1.5px solid #000;
      padding: 6px 0;
      font-weight: bold;
      font-size: ${getHeaderFontSize()};
    }
    
    .footer {
      text-align: center;
      margin-top: 12px;
      ${invoiceSettings.showFooterMessage ? 'padding-top: 8px; border-top: 1.5px solid #000;' : ''}
      font-size: ${getSecondaryFontSize()};
    }
    
    .number {
      direction: ltr;
      display: inline-block;
    }
    
    .payment-info {
      text-align: center;
      margin: 8px 0;
      font-size: ${getFontSize()};
      font-weight: bold;
    }
    
    .barcode {
      text-align: center;
      margin: 10px 0;
      font-family: 'Libre Barcode 128', monospace;
      font-size: 32px;
    }
    
    .qr-code {
      text-align: center;
      margin: 8px 0;
      font-size: 10px;
    }
    
    .customer-info {
      margin: 6px 0;
      font-size: ${getSecondaryFontSize()};
      padding: 4px;
      background: #f5f5f5;
      border-radius: 4px;
    }
    
    .order-notes {
      margin: 6px 0;
      font-size: ${getSecondaryFontSize()};
      font-style: italic;
      padding: 4px;
      background: #f9f9f9;
      border-radius: 4px;
    }
    
    /* List layout styles */
    .item-list-entry {
      margin-bottom: 10px;
      padding-bottom: 8px;
      border-bottom: 1px dotted #ccc;
    }
    
    .item-list-details {
      display: flex;
      justify-content: space-between;
      margin-top: 4px;
      font-size: ${getSecondaryFontSize()};
    }
    
    .item-list-quantity {
      font-weight: bold;
    }
    
    .item-list-total {
      font-weight: bold;
    }
    
    @media print {
      body {
        width: ${width}mm;
        margin: 0;
        padding: 2mm;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    ${invoiceSettings.showLogo && settings.logo ? `
      <div style="margin-bottom: 6px;">
        <img src="${settings.logo}" alt="Logo" style="max-width: 50px; max-height: 50px;">
      </div>
    ` : ''}
    
    ${invoiceSettings.showBusinessInfo ? `
      <div class="business-name">${settings.businessName}</div>
      <div style="font-size: ${getSecondaryFontSize()};">سیستەمی فرۆشگا</div>
    ` : ''}
    
    ${invoiceSettings.headerText ? `
      <div class="header-text">${invoiceSettings.headerText}</div>
    ` : ''}
    
    ${invoiceSettings.showBranchInfo && currentBranch ? `
      <div class="branch-info">
        <div>${currentBranch.name}</div>
        <div>${currentBranch.address}</div>
        <div>${currentBranch.phone}</div>
      </div>
    ` : ''}
  </div>
  
  <div class="order-info">
    ${invoiceSettings.showOrderNumber ? `
      <div style="font-size: ${getFontSize()}; font-weight: bold;">${t('orderNumber')}: ${order.orderNumber}</div>
    ` : ''}
    
    ${invoiceSettings.showDateTime ? `
      <div class="number">${new Date(order.createdAt).toLocaleString(settings.language === 'ar' ? 'ar-SA' : 'en-US')}</div>
    ` : ''}
    
    ${invoiceSettings.showCashierInfo ? `
      <div>${t('cashier')}: ${order.cashierName}</div>
    ` : ''}
    
    <div>${t('status')}: ${t(order.status)}</div>
  </div>
  
  ${invoiceSettings.showCustomerInfo && order.customerName ? `
    <div class="customer-info">
      <strong>کڕیار:</strong> ${order.customerName}
    </div>
  ` : ''}
  
  ${invoiceSettings.showOrderNotes && order.customerNote ? `
    <div class="order-notes">
      <strong>تێبینی:</strong> ${order.customerNote}
    </div>
  ` : ''}
  
  ${invoiceSettings.showItemDetails ? `
    ${invoiceSettings.useTableLayout !== false ? `
      <table class="items-table">
        <thead>
          <tr>
            <th style="width: 50%;">${isRTL ? 'بەرهەم' : 'Item'}</th>
            <th style="width: 15%; text-align: center;">${isRTL ? 'بڕ' : 'Qty'}</th>
            <th style="width: 15%; text-align: ${isRTL ? 'left' : 'right'};">${isRTL ? 'نرخ' : 'Price'}</th>
            <th style="width: 20%; text-align: ${isRTL ? 'left' : 'right'};">${isRTL ? 'کۆی گشتی' : 'Total'}</th>
          </tr>
        </thead>
        <tbody>
          ${order.items.map((item: any) => `
            <tr>
              <td>
                <div class="item-name">${item.productName}</div>
                ${item.variants && item.variants.length > 0 ? 
                  `<div class="item-variant">${item.variants.map((v: any) => v.name).join(', ')}</div>` : ''}
              </td>
              <td class="item-qty" style="text-align: center;">
                <span class="number">${item.quantity}</span>
              </td>
              <td class="item-price">
                ${invoiceSettings.showPrices ? `<span class="number">${formatPrice(item.basePrice)}</span>` : ''}
              </td>
              <td class="item-total">
                ${invoiceSettings.showPrices ? `<span class="number">${formatPrice(item.total)}</span>` : ''}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : `
      <div>
        ${order.items.map((item: any) => `
          <div class="item-list-entry">
            <div class="item-name">${item.productName}</div>
            ${item.variants && item.variants.length > 0 ? 
              `<div class="item-variant">${item.variants.map((v: any) => v.name).join(', ')}</div>` : ''}
            <div class="item-list-details">
              <span class="item-list-quantity">${item.quantity} × ${invoiceSettings.showPrices ? formatPrice(item.basePrice) : ''}</span>
              ${invoiceSettings.showPrices ? `<span class="item-list-total">${formatPrice(item.total)}</span>` : ''}
            </div>
          </div>
        `).join('')}
      </div>
    `}
  ` : ''}
  
  ${invoiceSettings.showTotal || invoiceSettings.showTax ? `
    <div class="totals">
      ${invoiceSettings.showTax && order.tax > 0 ? `
        <div class="total-line">
          <span>${t('subtotal')}:</span>
          <span class="number">${formatPrice(order.subtotal)}</span>
        </div>
        <div class="total-line">
          <span>${t('tax')}:</span>
          <span class="number">${formatPrice(order.tax)}</span>
        </div>
      ` : ''}
      
      ${invoiceSettings.showTotal ? `
        <div class="total-line grand-total">
          <span>${t('total')}:</span>
          <span class="number">${formatPrice(order.total)}</span>
        </div>
      ` : ''}
    </div>
  ` : ''}
  
  ${invoiceSettings.showPaymentMethod ? `
    <div class="payment-info">
      <div>${t('payment')}: ${order.paymentMethod === 'cash' ? 'نەقد' : 
                                      order.paymentMethod === 'card' ? 'کارت' : 
                                      'مۆبایل'}</div>
    </div>
  ` : ''}
  
  ${invoiceSettings.showBarcode ? `
    <div class="barcode">
      *${order.orderNumber}*
    </div>
  ` : ''}
  
  ${invoiceSettings.includeQRCode ? `
    <div class="qr-code">
      [QR Code: ${order.orderNumber}]
    </div>
  ` : ''}
  
  ${invoiceSettings.showFooterMessage ? `
    <div class="footer">
      <div>${invoiceSettings.footerText || settings.receiptFooter || t('thankYou')}</div>
      ${invoiceSettings.thankYouMessage ? `
        <div style="margin-top: 6px; font-size: ${getSecondaryFontSize()};">
          ${invoiceSettings.thankYouMessage}
        </div>
      ` : ''}
    </div>
  ` : ''}
</body>
</html>`;
}

export function printReceipt(content: string, copies: number = 1) {
  for (let i = 0; i < copies; i++) {
    const printWindow = window.open('', '_blank', 'width=300,height=600');
    if (printWindow) {
      printWindow.document.write(content);
      printWindow.document.close();
      
      // Wait for content to load then print
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          if (i === copies - 1) {
            printWindow.close();
          }
        }, 250);
      };
    }
  }
}