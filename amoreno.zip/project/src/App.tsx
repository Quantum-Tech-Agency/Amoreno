import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import { LoginForm } from './components/Auth/LoginForm';
import { Sidebar } from './components/Layout/Sidebar';
import { Header } from './components/Layout/Header';
import { MenuView } from './views/MenuView';
import { ProductsView } from './views/ProductsView';
import { OrdersView } from './views/OrdersView';
import { CustomersView } from './views/CustomersView';
import { ReportsView } from './views/ReportsView';
import { BranchesView } from './views/BranchesView';
import { SettingsView } from './views/SettingsView';
import { useAuth } from './hooks/useAuth';
import { useApp } from './context/AppContext';

function AppContent() {
  const { user } = useAuth();
  const { state, dispatch } = useApp();
  const [currentView, setCurrentView] = useState<string>('');
  const [isDark, setIsDark] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Set default view based on user role when user logs in or changes
  useEffect(() => {
    if (user) {
      // Set default view based on role
      if (user.role === 'cashier') {
        // Cashiers can only access menu and orders
        if (!['menu', 'orders'].includes(currentView)) {
          setCurrentView('menu');
        }
      } else if (user.role === 'admin' || user.role === 'manager' || user.role === 'owner') {
        // Admin, manager, and owner default to reports view
        if (currentView === '') {
          setCurrentView('reports');
        }
      } else if (currentView === '') {
        // For other roles, set default view if none is selected
        setCurrentView('menu');
      }
    }
  }, [user, currentView]);

  useEffect(() => {
    // Apply theme from settings
    const applyTheme = () => {
      if (state.settings.theme === 'dark') {
        setIsDark(true);
        document.documentElement.classList.add('dark');
      } else {
        setIsDark(false);
        document.documentElement.classList.remove('dark');
      }
    };

    applyTheme();
  }, [state.settings.theme]);

  useEffect(() => {
    // Apply RTL for Arabic
    if (state.settings.language === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = state.settings.language;
    }
  }, [state.settings.language]);

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDark ? 'dark' : 'light';
    const newSettings = { ...state.settings, theme: newTheme };
    
    // Update settings in context
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    
    // Save to localStorage
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    
    // Apply theme immediately
    setIsDark(!isDark);
    if (!isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const closeSidebar = () => {
    setSidebarOpen(false);
  };

  // Handle view change with role-based restrictions
  const handleViewChange = (view: string) => {
    if (user?.role === 'cashier' && !['menu', 'orders'].includes(view)) {
      // Cashiers can only access menu and orders
      setCurrentView('menu');
    } else {
      setCurrentView(view);
    }
  };

  const getViewTitle = () => {
    switch (currentView) {
      case 'menu': return 'مێنو';
      case 'products': return 'بەرهەمەکان';
      case 'orders': return 'داواکاریەکان';
      case 'customers': return 'کڕیارەکان';
      case 'reports': return 'ڕاپۆرتەکان';
      case 'branches': return 'لقەکان';
      case 'settings': return 'ڕێکخستنەکان';
      default: return 'مێنو';
    }
  };

  const renderView = () => {
    switch (currentView) {
      case 'menu': return <MenuView />;
      case 'products': return <ProductsView />;
      case 'orders': return <OrdersView />;
      case 'customers': return <CustomersView />;
      case 'reports': return <ReportsView />;
      case 'branches': return <BranchesView />;
      case 'settings': return <SettingsView />;
      default: return <MenuView />;
    }
  };

  if (!user) {
    return <LoginForm />;
  }

  return (
    <div className={`flex h-screen bg-gray-50 dark:bg-gray-900 ${state.settings.language === 'ar' ? 'font-arabic' : ''}`}>
      <Sidebar 
        currentView={currentView} 
        onViewChange={handleViewChange}
        isOpen={sidebarOpen}
        onClose={closeSidebar}
      />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden lg:ml-0">
        <Header 
          title={getViewTitle()} 
          onThemeToggle={toggleTheme} 
          isDark={isDark}
          onMenuToggle={toggleSidebar}
        />
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {renderView()}
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;