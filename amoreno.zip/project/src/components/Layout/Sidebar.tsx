import React from 'react';
import { 
  Home, 
  Package, 
  ShoppingCart, 
  Users, 
  BarChart3, 
  Settings,
  LogOut,
  IceCream,
  Building,
  X
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useApp } from '../../context/AppContext';
import { useTranslation } from '../../hooks/useTranslation';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ currentView, onViewChange, isOpen, onClose }: SidebarProps) {
  const { user, logout } = useAuth();
  const { state } = useApp();
  const { t } = useTranslation();
  const colorPalette = state.settings.colorPalette;
  const isRTL = state.settings.language === 'ar';

  const menuItems = [
    { id: 'menu', label: 'مێنو', icon: Home },
    { id: 'products', label: 'بەرهەمەکان', icon: Package },
    { id: 'orders', label: 'داواکاریەکان', icon: ShoppingCart },
    { id: 'customers', label: 'کڕیارەکان', icon: Users },
    { id: 'reports', label: 'ڕاپۆرتەکان', icon: BarChart3 },
    { id: 'branches', label: 'لقەکان', icon: Building },
    { id: 'settings', label: 'ڕێکخستنەکان', icon: Settings }
  ];

  const filteredMenuItems = menuItems.filter(item => {
    if (user?.role === 'cashier') {
      return ['menu', 'orders'].includes(item.id);
    }
    return true;
  });

  const currentBranch = state.branches.find(b => b.id === state.settings.currentBranchId);

  const handleItemClick = (viewId: string) => {
    onViewChange(viewId);
    // Close sidebar on mobile after selection
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 ${isRTL ? 'right-0' : 'left-0'} z-50 lg:z-auto
        w-64 bg-white dark:bg-gray-900 
        ${isRTL ? 'border-l' : 'border-r'} border-gray-200 dark:border-gray-700 
        flex flex-col sidebar
        transform transition-transform duration-300 ease-in-out lg:transform-none
        ${isOpen ? 'translate-x-0' : isRTL ? 'translate-x-full' : '-translate-x-full'}
        lg:translate-x-0
      `}>
        {/* Mobile Close Button */}
        <div className="lg:hidden flex justify-end p-4">
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <X className="h-6 w-6 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        <div className="p-6 lg:pt-6 pt-0">
          <div className={`flex items-center ${isRTL ? 'space-x-reverse space-x-3' : 'space-x-3'}`}>
            <div className={`${colorPalette.gradient} p-2 rounded-lg`}>
              {state.settings.logo ? (
                <img src={state.settings.logo} alt="Logo" className="h-6 w-6 object-cover rounded" />
              ) : (
                <IceCream className="h-6 w-6 text-white" />
              )}
            </div>
            <div className={isRTL ? 'text-right' : 'text-left'}>
              <h1 className="text-lg font-bold text-gray-900 dark:text-white">
                {state.settings.businessName}
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">سیستەمی فرۆشگا</p>
            </div>
          </div>
          
          {/* Current Branch Display */}
          {currentBranch && (
            <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className={`flex items-center ${isRTL ? 'space-x-reverse space-x-2' : 'space-x-2'}`}>
                <Building className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <div className={isRTL ? 'text-right' : 'text-left'}>
                  <p className="text-xs font-medium text-blue-800 dark:text-blue-200">لقی ئێستا</p>
                  <p className="text-sm font-semibold text-blue-900 dark:text-blue-100">{currentBranch.name}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <nav className="flex-1 px-3">
          <ul className="space-y-1">
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleItemClick(item.id)}
                    className={`w-full flex items-center ${isRTL ? 'flex-row-reverse' : ''} px-3 py-2 ${isRTL ? 'text-right' : 'text-left'} rounded-lg transition-colors sidebar-item ${
                      isActive
                        ? `${colorPalette.gradient} text-white shadow-lg`
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    <Icon className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'}`} />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className={`flex items-center ${isRTL ? 'space-x-reverse space-x-3' : 'space-x-3'} mb-4`}>
            <div className="bg-gray-300 dark:bg-gray-600 rounded-full p-2">
              <Users className="h-4 w-4 text-gray-600 dark:text-gray-300" />
            </div>
            <div className={isRTL ? 'text-right' : 'text-left'}>
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                {user?.role === 'admin' ? 'بەڕێوەبەر' : 
                 user?.role === 'cashier' ? 'فرۆشیار' : 
                 user?.role === 'manager' ? 'مەنەجەر' : 
                 user?.role === 'owner' ? 'خاوەن' : user?.role}
              </p>
            </div>
          </div>
          <button
            onClick={logout}
            className={`w-full flex items-center ${isRTL ? 'flex-row-reverse' : ''} px-3 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors ${isRTL ? 'text-right' : 'text-left'}`}
          >
            <LogOut className={`h-5 w-5 ${isRTL ? 'ml-3' : 'mr-3'}`} />
            دەرچوون
          </button>
        </div>
      </div>
    </>
  );
}