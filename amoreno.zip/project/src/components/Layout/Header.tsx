import React from 'react';
import { Sun, Moon, Bell, Search, Wifi, WifiOff, RefreshCw, Globe, Menu } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useOfflineSync } from '../../hooks/useOfflineSync';
import { useTranslation } from '../../hooks/useTranslation';

interface HeaderProps {
  title: string;
  onThemeToggle: () => void;
  isDark: boolean;
  onMenuToggle: () => void;
}

export function Header({ title, onThemeToggle, isDark, onMenuToggle }: HeaderProps) {
  const { state, dispatch } = useApp();
  const { syncStatus, syncPendingData } = useOfflineSync();
  const { t } = useTranslation();
  const lowStockCount = state.products.filter(p => p.stock <= p.minStock).length;
  const isRTL = state.settings.language === 'ar';

  const handleLanguageChange = (language: string) => {
    const newSettings = { ...state.settings, language: language as any };
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    
    // Apply language and RTL immediately
    if (language === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = language;
    }
  };

  return (
    <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-4 lg:px-6 py-4">
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`flex items-center ${isRTL ? 'flex-row-reverse' : ''}`}>
          {/* Mobile Menu Button */}
          <button
            onClick={onMenuToggle}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors mr-3"
          >
            <Menu className="h-6 w-6 text-gray-600 dark:text-gray-400" />
          </button>

          <div className={isRTL ? 'text-right' : 'text-left'}>
            <h1 className="text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">{title}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 hidden sm:block">
              {new Date().toLocaleDateString(state.settings.language === 'ar' ? 'ar-SA' : state.settings.language === 'ku' ? 'en-US' : 'en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </div>
        </div>

        <div className={`flex items-center ${isRTL ? 'space-x-reverse space-x-2 lg:space-x-4' : 'space-x-2 lg:space-x-4'} header-controls`}>
          {/* Search - Hidden on small screens */}
          <div className="relative hidden md:block">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 search-icon`} />
            <input
              type="text"
              placeholder="گەڕان..."
              className={`${isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent search-input w-48 lg:w-64`}
            />
          </div>

          {/* Language Selector */}
          <div className="relative">
            <select
              value={state.settings.language}
              onChange={(e) => handleLanguageChange(e.target.value)}
              className={`appearance-none bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg px-2 lg:px-3 py-2 ${isRTL ? 'pl-6 lg:pl-8 pr-2 lg:pr-3' : 'pr-6 lg:pr-8 pl-2 lg:pl-3'} text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent cursor-pointer text-sm`}
            >
              <option value="en">EN</option>
              <option value="ku">کو</option>
              <option value="ar">ع</option>
            </select>
            <Globe className={`absolute ${isRTL ? 'left-1 lg:left-2' : 'right-1 lg:right-2'} top-1/2 transform -translate-y-1/2 h-3 w-3 lg:h-4 lg:w-4 text-gray-400 pointer-events-none`} />
          </div>

          {/* Sync Status */}
          <div className={`hidden lg:flex items-center ${isRTL ? 'space-x-reverse space-x-2' : 'space-x-2'}`}>
            {syncStatus.isOnline ? (
              <div className={`flex items-center text-green-600 dark:text-green-400 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Wifi className="h-4 w-4 lg:h-5 lg:w-5" />
                <span className={`text-xs lg:text-sm ${isRTL ? 'mr-1' : 'ml-1'}`}>سەرهێڵ</span>
              </div>
            ) : (
              <div className={`flex items-center text-red-600 dark:text-red-400 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <WifiOff className="h-4 w-4 lg:h-5 lg:w-5" />
                <span className={`text-xs lg:text-sm ${isRTL ? 'mr-1' : 'ml-1'}`}>دەرهێڵ</span>
              </div>
            )}
            
            {syncStatus.pendingOrders > 0 && (
              <button
                onClick={syncPendingData}
                disabled={syncStatus.isSyncing || !syncStatus.isOnline}
                className={`flex items-center text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 px-2 py-1 rounded-lg transition-colors disabled:opacity-50 ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <RefreshCw className={`h-3 w-3 lg:h-4 lg:w-4 ${isRTL ? 'ml-1' : 'mr-1'} ${syncStatus.isSyncing ? 'animate-spin' : ''}`} />
                <span className="text-xs lg:text-sm number">{syncStatus.pendingOrders}</span>
              </button>
            )}
          </div>

          {/* Notifications */}
          <button className="relative p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
            <Bell className="h-4 w-4 lg:h-5 lg:w-5" />
            {lowStockCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 lg:h-5 lg:w-5 flex items-center justify-center number text-[10px] lg:text-xs">
                {lowStockCount}
              </span>
            )}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onThemeToggle}
            className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
            title={isDark ? 'ڕووناک' : 'تاریک'}
          >
            {isDark ? <Sun className="h-4 w-4 lg:h-5 lg:w-5" /> : <Moon className="h-4 w-4 lg:h-5 lg:w-5" />}
          </button>
        </div>
      </div>
    </header>
  );
}