import React, { useState } from 'react';
import { Upload, Download, AlertCircle, CheckCircle, Clock, FileText } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useTranslation } from '../../hooks/useTranslation';

interface BackupManagementProps {
  onManualBackup: () => void;
  lastBackupTime: string | null;
}

export function BackupManagement({ onManualBackup, lastBackupTime }: BackupManagementProps) {
  const { state, dispatch } = useApp();
  const { t } = useTranslation();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [uploadMessage, setUploadMessage] = useState('');

  const handleBackupUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadStatus('idle');
    setUploadMessage('');

    try {
      const text = await file.text();
      const backupData = JSON.parse(text);

      // Validate backup structure
      if (!backupData.data || !backupData.timestamp) {
        throw new Error('Invalid backup file format');
      }

      const { data } = backupData;

      // Restore data to state
      if (data.orders) {
        dispatch({ type: 'SET_ORDERS', payload: data.orders });
        localStorage.setItem('synced_orders', JSON.stringify(data.orders));
      }

      if (data.products) {
        dispatch({ type: 'SET_PRODUCTS', payload: data.products });
        localStorage.setItem('app_products', JSON.stringify(data.products));
      }

      if (data.categories) {
        dispatch({ type: 'SET_CATEGORIES', payload: data.categories });
      }

      if (data.customers) {
        dispatch({ type: 'SET_CUSTOMERS', payload: data.customers });
      }

      if (data.users) {
        // Add default passwords for security
        const usersWithPasswords = data.users.map((user: any) => ({
          ...user,
          password: user.password || 'password' // Default password if not provided
        }));
        dispatch({ type: 'SET_USERS', payload: usersWithPasswords });
        localStorage.setItem('app_users', JSON.stringify(usersWithPasswords));
      }

      if (data.settings) {
        dispatch({ type: 'SET_SETTINGS', payload: data.settings });
        localStorage.setItem('app_settings', JSON.stringify(data.settings));
      }

      setUploadStatus('success');
      setUploadMessage(`Backup restored successfully from ${new Date(backupData.timestamp).toLocaleString()}`);

      // Clear the file input
      e.target.value = '';

    } catch (error) {
      console.error('Failed to restore backup:', error);
      setUploadStatus('error');
      setUploadMessage('Failed to restore backup. Please check the file format.');
    } finally {
      setIsUploading(false);
    }
  };

  const formatBackupTime = (timeString: string | null) => {
    if (!timeString) return 'Never';
    
    const date = new Date(timeString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hours ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
      <div className="flex items-center mb-6">
        <div className="bg-blue-100 dark:bg-blue-900/20 p-2 rounded-lg">
          <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
        </div>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
          Backup Management
        </h2>
      </div>

      <div className="space-y-6">
        {/* Backup Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-gray-600 dark:text-gray-400 mr-2" />
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Last Backup</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {formatBackupTime(lastBackupTime)}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center">
              <Download className="h-5 w-5 text-green-600 dark:text-green-400 mr-2" />
              <div>
                <p className="text-sm font-medium text-gray-900 dark:text-white">Auto Backup</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Every 30 minutes
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Manual Backup */}
        <div>
          <h3 className="text-md font-semibold text-gray-900 dark:text-white mb-3">
            Manual Backup
          </h3>
          <div className="flex items-center space-x-4">
            <button
              onClick={onManualBackup}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center"
            >
              <Download className="h-4 w-4 mr-2" />
              Create Backup Now
            </button>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Download a complete backup of all your data
            </p>
          </div>
        </div>

        {/* Upload Backup */}
        <div>
          <h3 className="text-md font-semibold text-gray-900 dark:text-white mb-3">
            Restore from Backup
          </h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleBackupUpload}
                  disabled={isUploading}
                  className="hidden"
                  id="backup-upload"
                />
                <label
                  htmlFor="backup-upload"
                  className={`cursor-pointer bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center ${
                    isUploading ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {isUploading ? 'Uploading...' : 'Upload Backup File'}
                </label>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Select a backup JSON file to restore your data
              </p>
            </div>

            {/* Upload Status */}
            {uploadStatus !== 'idle' && (
              <div className={`p-3 rounded-lg flex items-start ${
                uploadStatus === 'success' 
                  ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
                  : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
              }`}>
                {uploadStatus === 'success' ? (
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                )}
                <div>
                  <p className={`text-sm font-medium ${
                    uploadStatus === 'success' 
                      ? 'text-green-800 dark:text-green-200'
                      : 'text-red-800 dark:text-red-200'
                  }`}>
                    {uploadStatus === 'success' ? 'Backup Restored Successfully' : 'Restore Failed'}
                  </p>
                  <p className={`text-sm ${
                    uploadStatus === 'success' 
                      ? 'text-green-700 dark:text-green-300'
                      : 'text-red-700 dark:text-red-300'
                  }`}>
                    {uploadMessage}
                  </p>
                </div>
              </div>
            )}

            {/* Warning */}
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 mr-2 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                    Warning: Restoring from backup will replace all current data
                  </p>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                    Make sure to create a backup of your current data before restoring from a file.
                    This action cannot be undone.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Backup Information */}
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
            What's included in backups:
          </h4>
          <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
            <li>• All orders and transaction history</li>
            <li>• Products, categories, and inventory data</li>
            <li>• Customer information and loyalty points</li>
            <li>• User accounts (passwords excluded for security)</li>
            <li>• System settings and preferences</li>
          </ul>
        </div>
      </div>
    </div>
  );
}