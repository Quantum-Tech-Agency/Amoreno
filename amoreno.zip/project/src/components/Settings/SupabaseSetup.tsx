import React, { useState, useEffect } from 'react';
import { Database, Wifi, WifiOff, RefreshCw, CheckCircle, AlertCircle, Upload } from 'lucide-react';
import { supabaseService } from '../../services/supabaseService';
import { useApp } from '../../context/AppContext';

interface SupabaseSetupProps {
  onClose: () => void;
}

export function SupabaseSetup({ onClose }: SupabaseSetupProps) {
  const { state } = useApp();
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);
  const [migrationStatus, setMigrationStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [migrationMessage, setMigrationMessage] = useState('');

  useEffect(() => {
    checkConnection();
  }, []);

  const checkConnection = async () => {
    setIsLoading(true);
    try {
      const connected = await supabaseService.healthCheck();
      setIsConnected(connected);
    } catch (error) {
      setIsConnected(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMigration = async () => {
    setIsMigrating(true);
    setMigrationStatus('idle');
    setMigrationMessage('');

    try {
      // Prepare local data for migration
      const localData = {
        branches: state.branches,
        categories: state.categories,
        products: state.products,
        orders: state.orders,
        customers: state.customers
      };

      await supabaseService.migrateFromLocalData(localData);
      
      setMigrationStatus('success');
      setMigrationMessage('Data successfully migrated to Supabase! Your system is now ready for real-time synchronization.');
    } catch (error) {
      console.error('Migration failed:', error);
      setMigrationStatus('error');
      setMigrationMessage(`Migration failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsMigrating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
              <Database className="h-6 w-6 mr-3" />
              Supabase Setup
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>

          <div className="space-y-6">
            {/* Connection Status */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {isLoading ? (
                    <RefreshCw className="h-5 w-5 text-blue-500 animate-spin mr-3" />
                  ) : isConnected ? (
                    <Wifi className="h-5 w-5 text-green-500 mr-3" />
                  ) : (
                    <WifiOff className="h-5 w-5 text-red-500 mr-3" />
                  )}
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-white">
                      Supabase Connection
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {isLoading ? 'Checking connection...' : 
                       isConnected ? 'Connected and ready' : 
                       'Not connected - check your environment variables'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={checkConnection}
                  disabled={isLoading}
                  className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                >
                  Test Connection
                </button>
              </div>
            </div>

            {/* Setup Instructions */}
            {!isConnected && (
              <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                <h3 className="font-medium text-yellow-800 dark:text-yellow-200 mb-2">
                  Setup Required
                </h3>
                <ol className="text-sm text-yellow-700 dark:text-yellow-300 space-y-2 list-decimal list-inside">
                  <li>Create a Supabase project at <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="underline">supabase.com</a></li>
                  <li>Copy your project URL and anon key from the API settings</li>
                  <li>Create a <code className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">.env</code> file with:
                    <pre className="mt-2 p-2 bg-yellow-100 dark:bg-yellow-800 rounded text-xs">
{`VITE_SUPABASE_URL=your_project_url
VITE_SUPABASE_ANON_KEY=your_anon_key`}
                    </pre>
                  </li>
                  <li>Run the SQL schema from <code className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">supabase/schema.sql</code> in your Supabase SQL editor</li>
                  <li>Restart your development server</li>
                </ol>
              </div>
            )}

            {/* Migration Section */}
            {isConnected && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <h3 className="font-medium text-blue-800 dark:text-blue-200 mb-3 flex items-center">
                  <Upload className="h-5 w-5 mr-2" />
                  Data Migration
                </h3>
                
                <p className="text-sm text-blue-700 dark:text-blue-300 mb-4">
                  Migrate your existing local data to Supabase to enable real-time synchronization across all devices.
                </p>

                <div className="space-y-3">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-center">
                    <div className="bg-white dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Branches</p>
                      <p className="font-bold text-blue-600">{state.branches.length}</p>
                    </div>
                    <div className="bg-white dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Categories</p>
                      <p className="font-bold text-blue-600">{state.categories.length}</p>
                    </div>
                    <div className="bg-white dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Products</p>
                      <p className="font-bold text-blue-600">{state.products.length}</p>
                    </div>
                    <div className="bg-white dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Orders</p>
                      <p className="font-bold text-blue-600">{state.orders.length}</p>
                    </div>
                    <div className="bg-white dark:bg-gray-800 p-3 rounded">
                      <p className="text-xs text-gray-600 dark:text-gray-400">Customers</p>
                      <p className="font-bold text-blue-600">{state.customers.length}</p>
                    </div>
                  </div>

                  <button
                    onClick={handleMigration}
                    disabled={isMigrating}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center"
                  >
                    {isMigrating ? (
                      <>
                        <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                        Migrating Data...
                      </>
                    ) : (
                      <>
                        <Upload className="h-5 w-5 mr-2" />
                        Migrate to Supabase
                      </>
                    )}
                  </button>

                  {/* Migration Status */}
                  {migrationStatus !== 'idle' && (
                    <div className={`p-3 rounded-lg flex items-start ${
                      migrationStatus === 'success' 
                        ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
                        : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
                    }`}>
                      {migrationStatus === 'success' ? (
                        <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                      ) : (
                        <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                      )}
                      <div>
                        <p className={`text-sm font-medium ${
                          migrationStatus === 'success' 
                            ? 'text-green-800 dark:text-green-200'
                            : 'text-red-800 dark:text-red-200'
                        }`}>
                          {migrationStatus === 'success' ? 'Migration Successful!' : 'Migration Failed'}
                        </p>
                        <p className={`text-sm ${
                          migrationStatus === 'success' 
                            ? 'text-green-700 dark:text-green-300'
                            : 'text-red-700 dark:text-red-300'
                        }`}>
                          {migrationMessage}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Benefits */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 dark:text-white mb-3">
                Benefits of Supabase Integration
              </h3>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                  Real-time data synchronization across all devices
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                  Automatic backups and data recovery
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                  Scalable infrastructure for business growth
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                  Enhanced security with Row Level Security
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                  Multi-user collaboration support
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}