import React, { useState, useEffect } from 'react';
import { X, Upload, Check, Trash2, Type, RefreshCw, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useTranslation } from '../../hooks/useTranslation';

interface FontManagementProps {
  onClose: () => void;
}

export function FontManagement({ onClose }: FontManagementProps) {
  const { state, dispatch } = useApp();
  const { t } = useTranslation();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [customFonts, setCustomFonts] = useState<Array<{name: string, url: string, previewText: string}>>([]);
  const [selectedFont, setSelectedFont] = useState<string | null>(state.settings.customFont || null);
  const [previewText, setPreviewText] = useState('بەستەڵەکی ڤانیلا - Vanilla Ice Cream - آيس كريم الفانيليا');

  useEffect(() => {
    // Load saved custom fonts from localStorage
    const savedFonts = localStorage.getItem('custom_fonts');
    if (savedFonts) {
      try {
        setCustomFonts(JSON.parse(savedFonts));
      } catch (error) {
        console.error('Failed to parse saved fonts:', error);
      }
    }
  }, []);

  const handleFontUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if it's a font file
    const validFontTypes = ['font/ttf', 'font/otf', 'font/woff', 'font/woff2', 'application/font-woff', 'application/font-woff2', 'application/x-font-ttf', 'application/x-font-otf'];
    if (!validFontTypes.includes(file.type) && !file.name.match(/\.(ttf|otf|woff|woff2)$/i)) {
      setUploadStatus('error');
      setStatusMessage('Invalid font file. Please upload a TTF, OTF, WOFF, or WOFF2 file.');
      return;
    }

    setIsUploading(true);
    setUploadStatus('idle');
    setStatusMessage('');

    try {
      // Read the font file as a data URL
      const reader = new FileReader();
      reader.onload = async (e) => {
        const fontDataUrl = e.target?.result as string;
        
        // Create a font name from the file name
        const fontName = file.name.replace(/\.(ttf|otf|woff|woff2)$/i, '');
        
        // Create a style element to load the font
        const fontFace = `
          @font-face {
            font-family: "${fontName}";
            src: url("${fontDataUrl}") format("${getFormatFromFileName(file.name)}");
            font-weight: normal;
            font-style: normal;
          }
        `;
        
        // Add the font to the document
        const styleElement = document.createElement('style');
        styleElement.textContent = fontFace;
        document.head.appendChild(styleElement);
        
        // Add the font to the list
        const newFont = {
          name: fontName,
          url: fontDataUrl,
          previewText: previewText
        };
        
        const updatedFonts = [...customFonts, newFont];
        setCustomFonts(updatedFonts);
        
        // Save to localStorage
        localStorage.setItem('custom_fonts', JSON.stringify(updatedFonts));
        
        // Select the new font
        setSelectedFont(fontName);
        
        setUploadStatus('success');
        setStatusMessage(`Font "${fontName}" uploaded successfully!`);
      };
      
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Failed to upload font:', error);
      setUploadStatus('error');
      setStatusMessage('Failed to upload font. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const getFormatFromFileName = (fileName: string): string => {
    if (fileName.endsWith('.ttf')) return 'truetype';
    if (fileName.endsWith('.otf')) return 'opentype';
    if (fileName.endsWith('.woff')) return 'woff';
    if (fileName.endsWith('.woff2')) return 'woff2';
    return 'truetype'; // default
  };

  const handleFontSelection = (fontName: string | null) => {
    setSelectedFont(fontName);
  };

  const handleDeleteFont = (fontName: string) => {
    if (confirm('Are you sure you want to delete this font?')) {
      const updatedFonts = customFonts.filter(font => font.name !== fontName);
      setCustomFonts(updatedFonts);
      
      // Save to localStorage
      localStorage.setItem('custom_fonts', JSON.stringify(updatedFonts));
      
      // If the deleted font was selected, reset selection
      if (selectedFont === fontName) {
        setSelectedFont(null);
      }
    }
  };

  const handleSave = () => {
    const newSettings = {
      ...state.settings,
      customFont: selectedFont
    };
    
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    
    // Apply the font immediately
    if (selectedFont) {
      const font = customFonts.find(f => f.name === selectedFont);
      if (font) {
        document.documentElement.style.fontFamily = `"${selectedFont}", "Noto Sans", system-ui, -apple-system, sans-serif`;
      }
    } else {
      // Reset to default font
      if (state.settings.language === 'ar') {
        document.documentElement.style.fontFamily = `"Noto Sans Arabic", "Noto Sans", system-ui, -apple-system, sans-serif`;
      } else {
        document.documentElement.style.fontFamily = `"Noto Sans", system-ui, -apple-system, sans-serif`;
      }
    }
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
              <Type className="h-6 w-6 mr-3" />
              بەڕێوەبردنی فۆنتەکان
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Font Upload */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                بارکردنی فۆنتی نوێ
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <input
                      type="file"
                      accept=".ttf,.otf,.woff,.woff2"
                      onChange={handleFontUpload}
                      disabled={isUploading}
                      className="hidden"
                      id="font-upload"
                    />
                    <label
                      htmlFor="font-upload"
                      className={`cursor-pointer bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center ${
                        isUploading ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      {isUploading ? (
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Upload className="h-4 w-4 mr-2" />
                      )}
                      {isUploading ? 'بارکردن...' : 'بارکردنی فۆنت'}
                    </label>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    فایلی فۆنتی TTF، OTF، WOFF، یان WOFF2 هەڵبژێرە
                  </p>
                </div>

                {/* Upload Status */}
                {uploadStatus !== 'idle' && (
                  <div className={`p-3 rounded-lg flex items-start ${
                    uploadStatus === 'success' 
                      ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
                      : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
                  }`}>
                    {uploadStatus === 'success' ? (
                      <Check className="h-5 w-5 text-green-600 dark:text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 mt-0.5 flex-shrink-0" />
                    )}
                    <div>
                      <p className={`text-sm font-medium ${
                        uploadStatus === 'success' 
                          ? 'text-green-800 dark:text-green-200'
                          : 'text-red-800 dark:text-red-200'
                      }`}>
                        {uploadStatus === 'success' ? 'بارکردن سەرکەوتوو بوو' : 'بارکردن شکستی هێنا'}
                      </p>
                      <p className={`text-sm ${
                        uploadStatus === 'success' 
                          ? 'text-green-700 dark:text-green-300'
                          : 'text-red-700 dark:text-red-300'
                      }`}>
                        {statusMessage}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Font Preview */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                پێشبینینی فۆنت
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    دەقی پێشبینین
                  </label>
                  <input
                    type="text"
                    value={previewText}
                    onChange={(e) => setPreviewText(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="دەقێک بنووسە بۆ پێشبینینی فۆنت..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* System Fonts */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      فۆنتە سیستەمیەکان
                    </h4>
                    <div className="space-y-2">
                      <button
                        onClick={() => handleFontSelection(null)}
                        className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                          selectedFont === null
                            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                            : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-gray-900 dark:text-white">
                            فۆنتی بنەڕەتی
                          </span>
                          {selectedFont === null && (
                            <Check className="h-5 w-5 text-blue-500" />
                          )}
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          Noto Sans / Noto Sans Arabic
                        </p>
                        <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded">
                          <p className="font-['Noto_Sans']">{previewText}</p>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Custom Fonts */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      فۆنتە تایبەتەکان
                    </h4>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {customFonts.length === 0 ? (
                        <div className="text-center py-8 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                          <Type className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            هیچ فۆنتێکی تایبەت بارنەکراوە
                          </p>
                          <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                            فۆنتێک باربکە بۆ دەستپێکردن
                          </p>
                        </div>
                      ) : (
                        customFonts.map((font) => (
                          <div
                            key={font.name}
                            className={`p-3 rounded-lg border-2 transition-all ${
                              selectedFont === font.name
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                                : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-gray-900 dark:text-white">
                                {font.name}
                              </span>
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => handleFontSelection(font.name)}
                                  className={`p-1 rounded ${
                                    selectedFont === font.name
                                      ? 'text-blue-600 bg-blue-100 dark:bg-blue-900/30'
                                      : 'text-gray-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20'
                                  }`}
                                  title="Select Font"
                                >
                                  <Check className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteFont(font.name)}
                                  className="p-1 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"
                                  title="Delete Font"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                            <div 
                              className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded"
                              style={{ fontFamily: `"${font.name}", sans-serif` }}
                            >
                              <p>{previewText}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Font Usage Information */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-900 dark:text-blue-100 mb-2">
                زانیاری دەربارەی فۆنتەکان:
              </h4>
              <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                <li>• فۆنتەکان لە ناو وێبگەڕەکەت پاشەکەوت دەکرێن</li>
                <li>• فۆنتەکان لە هەموو بەشەکانی ئەپەکەدا جێبەجێ دەکرێن</li>
                <li>• فۆنتەکان لە پسوڵەکانیشدا بەکاردێن</li>
                <li>• بۆ باشترین ئەنجام، فۆنتێک هەڵبژێرە کە پشتگیری زمانەکانت بکات</li>
                <li>• قەبارەی فایلی فۆنت کاریگەری لەسەر خێرایی ئەپەکە دەبێت</li>
              </ul>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-600">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              هەڵوەشاندنەوە
            </button>
            <button
              onClick={handleSave}
              className="px-6 py-2 bg-gradient-to-r from-blue-500 to-cyan-600 text-white rounded-lg hover:from-blue-600 hover:to-cyan-700 transition-all flex items-center"
            >
              <Check className="h-4 w-4 mr-2" />
              پاشەکەوتکردن
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}