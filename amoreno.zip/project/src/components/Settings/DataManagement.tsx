import React, { useState } from 'react';
import { Trash2, AlertTriangle, RefreshCw, DollarSign, ShoppingCart, Users, BarChart3 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useTranslation } from '../../hooks/useTranslation';
import { dbService } from '../../services/database';

interface DataManagementProps {
  onClose: () => void;
}

export function DataManagement({ onClose }: DataManagementProps) {
  const { state, dispatch } = useApp();
  const { t } = useTranslation();
  const [isResetting, setIsResetting] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);

  const handleResetFinancialData = async () => {
    if (confirmText !== 'RESET') {
      alert('Please type "RESET" to confirm');
      return;
    }

    setIsResetting(true);
    try {
      // Clear orders
      dispatch({ type: 'SET_ORDERS', payload: [] });
      
      // Clear customers
      dispatch({ type: 'SET_CUSTOMERS', payload: [] });
      
      // Clear from localStorage
      localStorage.removeItem('synced_orders');
      localStorage.removeItem('offline_orders');
      localStorage.removeItem('app_customers');
      
      // Reset database tables (if using SQLite)
      try {
        await dbService.resetFinancialData();
      } catch (error) {
        console.warn('Database reset failed, continuing with local storage reset:', error);
      }
      
      alert('Financial data has been successfully reset!');
      setShowConfirmation(false);
      setConfirmText('');
      onClose();
    } catch (error) {
      console.error('Failed to reset financial data:', error);
      alert('Failed to reset financial data. Please try again.');
    } finally {
      setIsResetting(false);
    }
  };

  const getDataStats = () => {
    const totalOrders = state.orders.length;
    const totalRevenue = state.orders
      .filter(o => o.status === 'completed')
      .reduce((sum, order) => sum + order.total, 0);
    const totalCustomers = state.customers.length;
    
    return {
      totalOrders,
      totalRevenue,
      totalCustomers
    };
  };

  const stats = getDataStats();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
              <BarChart3 className="h-6 w-6 mr-3" />
              Data Management
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>

          {!showConfirmation ? (
            <>
              {/* Current Data Overview */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Current Financial Data
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                    <div className="flex items-center">
                      <ShoppingCart className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Total Orders</p>
                        <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">{stats.totalOrders}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                    <div className="flex items-center">
                      <DollarSign className="h-8 w-8 text-green-600 dark:text-green-400" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-green-600 dark:text-green-400">Total Revenue</p>
                        <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                          {stats.totalRevenue.toLocaleString()} د.ع
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                    <div className="flex items-center">
                      <Users className="h-8 w-8 text-purple-600 dark:text-purple-400" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-purple-600 dark:text-purple-400">Total Customers</p>
                        <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">{stats.totalCustomers}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Reset Financial Data Section */}
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-6">
                <div className="flex items-start">
                  <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400 mt-1 flex-shrink-0" />
                  <div className="ml-3 flex-1">
                    <h3 className="text-lg font-semibold text-red-900 dark:text-red-100 mb-2">
                      Reset Financial Data
                    </h3>
                    <p className="text-red-800 dark:text-red-200 mb-4">
                      This action will permanently delete all financial data including:
                    </p>
                    <ul className="text-red-700 dark:text-red-300 text-sm space-y-1 mb-4 ml-4">
                      <li>• All order history and transactions</li>
                      <li>• Customer information and loyalty points</li>
                      <li>• Sales reports and analytics data</li>
                      <li>• Revenue and payment records</li>
                    </ul>
                    <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3 mb-4">
                      <p className="text-yellow-800 dark:text-yellow-200 text-sm font-medium">
                        ⚠️ What will NOT be deleted:
                      </p>
                      <ul className="text-yellow-700 dark:text-yellow-300 text-sm mt-2 ml-4">
                        <li>• Products and categories</li>
                        <li>• User accounts and permissions</li>
                        <li>• System settings and preferences</li>
                        <li>• Branch information</li>
                      </ul>
                    </div>
                    <p className="text-red-800 dark:text-red-200 font-semibold">
                      This action cannot be undone. Make sure to create a backup before proceeding.
                    </p>
                  </div>
                </div>

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={() => setShowConfirmation(true)}
                    className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center"
                    disabled={stats.totalOrders === 0}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Reset Financial Data
                  </button>
                </div>

                {stats.totalOrders === 0 && (
                  <p className="text-gray-500 dark:text-gray-400 text-sm mt-2 text-center">
                    No financial data to reset
                  </p>
                )}
              </div>
            </>
          ) : (
            /* Confirmation Dialog */
            <div className="space-y-6">
              <div className="text-center">
                <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-red-900 dark:text-red-100 mb-2">
                  Confirm Data Reset
                </h3>
                <p className="text-red-800 dark:text-red-200">
                  You are about to permanently delete all financial data.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                  Data to be deleted:
                </h4>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.totalOrders}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Orders</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-600 dark:text-red-400">
                      {stats.totalRevenue.toLocaleString()}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Revenue (د.ع)</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.totalCustomers}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Customers</p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Type "RESET" to confirm this action:
                </label>
                <input
                  type="text"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
                  placeholder="Type RESET here"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => {
                    setShowConfirmation(false);
                    setConfirmText('');
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleResetFinancialData}
                  disabled={confirmText !== 'RESET' || isResetting}
                  className="flex-1 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                >
                  {isResetting ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Resetting...
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4 mr-2" />
                      Reset Data
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}