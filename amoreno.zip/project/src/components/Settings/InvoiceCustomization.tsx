import React, { useState } from 'react';
import { Receipt, Printer, Eye, Settings as SettingsIcon, FileText, Image, BarChart3, Type, Table } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useTranslation } from '../../hooks/useTranslation';
import { InvoiceSettings } from '../../types';

interface InvoiceCustomizationProps {
  onClose: () => void;
}

export function InvoiceCustomization({ onClose }: InvoiceCustomizationProps) {
  const { state, dispatch } = useApp();
  const { t } = useTranslation();
  const [invoiceSettings, setInvoiceSettings] = useState<InvoiceSettings>(state.settings.invoiceSettings);
  const [activeTab, setActiveTab] = useState<'layout' | 'content' | 'format'>('format');

  const handleSave = () => {
    const newSettings = {
      ...state.settings,
      invoiceSettings
    };
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    onClose();
  };

  const updateSetting = (key: keyof InvoiceSettings, value: any) => {
    setInvoiceSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const ToggleSwitch = ({ checked, onChange, label, description }: {
    checked: boolean;
    onChange: (checked: boolean) => void;
    label: string;
    description?: string;
  }) => (
    <div className="flex items-center justify-between py-3">
      <div className="flex-1">
        <h4 className="text-sm font-medium text-gray-900 dark:text-white">{label}</h4>
        {description && (
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{description}</p>
        )}
      </div>
      <label className="relative inline-flex items-center cursor-pointer">
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          className="sr-only peer"
        />
        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
      </label>
    </div>
  );

  const renderLayoutTab = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Header Section
          </h3>
          <ToggleSwitch
            checked={invoiceSettings.showLogo}
            onChange={(checked) => updateSetting('showLogo', checked)}
            label="Show Business Logo"
            description="Display your business logo at the top of receipts"
          />
          <ToggleSwitch
            checked={invoiceSettings.showBusinessInfo}
            onChange={(checked) => updateSetting('showBusinessInfo', checked)}
            label="Show Business Information"
            description="Include business name and contact details"
          />
          <ToggleSwitch
            checked={invoiceSettings.showBranchInfo}
            onChange={(checked) => updateSetting('showBranchInfo', checked)}
            label="Show Branch Information"
            description="Display current branch details"
          />
          <ToggleSwitch
            checked={invoiceSettings.showDateTime}
            onChange={(checked) => updateSetting('showDateTime', checked)}
            label="Show Date & Time"
            description="Include transaction date and time"
          />
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Order Details
          </h3>
          <ToggleSwitch
            checked={invoiceSettings.showOrderNumber}
            onChange={(checked) => updateSetting('showOrderNumber', checked)}
            label="Show Order Number"
            description="Display unique order identifier"
          />
          <ToggleSwitch
            checked={invoiceSettings.showCashierInfo}
            onChange={(checked) => updateSetting('showCashierInfo', checked)}
            label="Show Cashier Information"
            description="Include cashier name who processed the order"
          />
          <ToggleSwitch
            checked={invoiceSettings.showCustomerInfo}
            onChange={(checked) => updateSetting('showCustomerInfo', checked)}
            label="Show Customer Information"
            description="Display customer name if provided"
          />
          <ToggleSwitch
            checked={invoiceSettings.showOrderNotes}
            onChange={(checked) => updateSetting('showOrderNotes', checked)}
            label="Show Order Notes"
            description="Include any special instructions or notes"
          />
        </div>
      </div>

      <div className="border-t border-gray-200 dark:border-gray-600 pt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
              <Receipt className="h-5 w-5 mr-2" />
              Item Details
            </h3>
            <ToggleSwitch
              checked={invoiceSettings.showItemDetails}
              onChange={(checked) => updateSetting('showItemDetails', checked)}
              label="Show Item Details"
              description="Display product names and descriptions"
            />
            <ToggleSwitch
              checked={invoiceSettings.showItemImages}
              onChange={(checked) => updateSetting('showItemImages', checked)}
              label="Show Item Images"
              description="Include product images (increases receipt size)"
            />
            <ToggleSwitch
              checked={invoiceSettings.showPrices}
              onChange={(checked) => updateSetting('showPrices', checked)}
              label="Show Prices"
              description="Display individual item prices"
            />
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
              <Printer className="h-5 w-5 mr-2" />
              Footer Section
            </h3>
            <ToggleSwitch
              checked={invoiceSettings.showTax}
              onChange={(checked) => updateSetting('showTax', checked)}
              label="Show Tax Breakdown"
              description="Display tax calculations separately"
            />
            <ToggleSwitch
              checked={invoiceSettings.showTotal}
              onChange={(checked) => updateSetting('showTotal', checked)}
              label="Show Total Amount"
              description="Display final total amount"
            />
            <ToggleSwitch
              checked={invoiceSettings.showPaymentMethod}
              onChange={(checked) => updateSetting('showPaymentMethod', checked)}
              label="Show Payment Method"
              description="Include how the customer paid"
            />
            <ToggleSwitch
              checked={invoiceSettings.showBarcode}
              onChange={(checked) => updateSetting('showBarcode', checked)}
              label="Show Barcode"
              description="Include order number as barcode"
            />
            <ToggleSwitch
              checked={invoiceSettings.includeQRCode}
              onChange={(checked) => updateSetting('includeQRCode', checked)}
              label="Include QR Code"
              description="Add QR code for digital receipt access"
            />
            <ToggleSwitch
              checked={invoiceSettings.showFooterMessage}
              onChange={(checked) => updateSetting('showFooterMessage', checked)}
              label="Show Footer Message"
              description="Display thank you message at bottom"
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderContentTab = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Header Text (Optional)
        </label>
        <input
          type="text"
          value={invoiceSettings.headerText}
          onChange={(e) => updateSetting('headerText', e.target.value)}
          placeholder="e.g., Welcome to our store!"
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Footer Text
        </label>
        <textarea
          value={invoiceSettings.footerText}
          onChange={(e) => updateSetting('footerText', e.target.value)}
          placeholder="Thank you for your business!"
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Thank You Message
        </label>
        <input
          type="text"
          value={invoiceSettings.thankYouMessage}
          onChange={(e) => updateSetting('thankYouMessage', e.target.value)}
          placeholder="Come again soon!"
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Number of Copies to Print
          </label>
          <select
            value={invoiceSettings.printCopies}
            onChange={(e) => updateSetting('printCopies', parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value={1}>1 Copy</option>
            <option value={2}>2 Copies</option>
            <option value={3}>3 Copies</option>
            <option value={4}>4 Copies</option>
          </select>
        </div>

        <div className="flex items-end">
          <ToggleSwitch
            checked={invoiceSettings.autoOpenCashDrawer}
            onChange={(checked) => updateSetting('autoOpenCashDrawer', checked)}
            label="Auto Open Cash Drawer"
            description="Automatically open cash drawer after printing"
          />
        </div>
      </div>
    </div>
  );

  const renderFormatTab = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center">
            <Type className="h-4 w-4 mr-2" />
            Font Size
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['small', 'medium', 'large'] as const).map((size) => (
              <button
                key={size}
                onClick={() => updateSetting('fontSize', size)}
                className={`p-3 rounded-lg border-2 transition-all text-center ${
                  invoiceSettings.fontSize === size
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                    : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
                }`}
              >
                <div className={`font-medium ${
                  size === 'small' ? 'text-xs' : 
                  size === 'medium' ? 'text-sm' : 'text-base'
                }`}>
                  Aa
                </div>
                <div className="text-xs text-gray-500 mt-1 capitalize">{size}</div>
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Item names will be displayed in a larger font size for better readability
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center">
            <Table className="h-4 w-4 mr-2" />
            Item Layout
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => updateSetting('useTableLayout', true)}
              className={`p-4 rounded-lg border-2 transition-all ${
                invoiceSettings.useTableLayout !== false
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
              }`}
            >
              <div className="text-center">
                <div className="bg-white dark:bg-gray-800 rounded p-2 mb-2 mx-auto">
                  <div className="w-full h-1 bg-gray-300 dark:bg-gray-600 mb-1"></div>
                  <div className="w-full h-1 bg-gray-300 dark:bg-gray-600 mb-1"></div>
                  <div className="w-full h-1 bg-gray-300 dark:bg-gray-600"></div>
                </div>
                <span className="text-sm font-medium">Table Layout</span>
                <p className="text-xs text-gray-500 mt-1">Organized columns</p>
              </div>
            </button>
            <button
              onClick={() => updateSetting('useTableLayout', false)}
              className={`p-4 rounded-lg border-2 transition-all ${
                invoiceSettings.useTableLayout === false
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
              }`}
            >
              <div className="text-center">
                <div className="bg-white dark:bg-gray-800 rounded p-2 mb-2 mx-auto">
                  <div className="w-full h-2 bg-gray-300 dark:bg-gray-600 mb-2"></div>
                  <div className="w-full h-2 bg-gray-300 dark:bg-gray-600 mb-2"></div>
                  <div className="w-full h-2 bg-gray-300 dark:bg-gray-600"></div>
                </div>
                <span className="text-sm font-medium">List Layout</span>
                <p className="text-xs text-gray-500 mt-1">Simple list view</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Paper Size
        </label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => updateSetting('paperSize', '58mm')}
            className={`p-4 rounded-lg border-2 transition-all ${
              invoiceSettings.paperSize === '58mm'
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
            }`}
          >
            <div className="text-center">
              <div className="bg-white dark:bg-gray-800 rounded p-2 mb-2 mx-auto w-8 h-12 border"></div>
              <span className="text-sm font-medium">58mm</span>
              <p className="text-xs text-gray-500 mt-1">Compact</p>
            </div>
          </button>
          <button
            onClick={() => updateSetting('paperSize', '80mm')}
            className={`p-4 rounded-lg border-2 transition-all ${
              invoiceSettings.paperSize === '80mm'
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
            }`}
          >
            <div className="text-center">
              <div className="bg-white dark:bg-gray-800 rounded p-2 mb-2 mx-auto w-10 h-12 border"></div>
              <span className="text-sm font-medium">80mm</span>
              <p className="text-xs text-gray-500 mt-1">Standard</p>
            </div>
          </button>
        </div>
      </div>

      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
        <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3 flex items-center">
          <Eye className="h-4 w-4 mr-2" />
          Receipt Preview
        </h3>
        <div className="bg-white dark:bg-gray-800 rounded border p-4 max-w-xs mx-auto">
          <div className="text-center space-y-2">
            {invoiceSettings.showLogo && (
              <div className="w-8 h-8 bg-blue-500 rounded mx-auto"></div>
            )}
            {invoiceSettings.showBusinessInfo && (
              <div className={`font-bold ${
                invoiceSettings.fontSize === 'small' ? 'text-sm' : 
                invoiceSettings.fontSize === 'medium' ? 'text-base' : 'text-lg'
              }`}>
                {state.settings.businessName}
              </div>
            )}
            {invoiceSettings.headerText && (
              <div className="text-xs text-gray-600">{invoiceSettings.headerText}</div>
            )}
          </div>
          
          <div className="border-t border-b border-gray-200 py-2 my-2">
            {invoiceSettings.showOrderNumber && (
              <div className="text-xs">Order: #12345</div>
            )}
            {invoiceSettings.showDateTime && (
              <div className="text-xs text-gray-500">Dec 15, 2024 14:30</div>
            )}
          </div>

          {invoiceSettings.showItemDetails && (
            <div className="space-y-1 text-xs">
              {invoiceSettings.useTableLayout !== false ? (
                <table style={{width: '100%', borderCollapse: 'collapse', fontSize: invoiceSettings.fontSize === 'large' ? '14px' : '12px'}}>
                  <thead>
                    <tr style={{borderBottom: '1px solid #ddd'}}>
                      <th style={{textAlign: 'left', padding: '2px'}}>Item</th>
                      <th style={{textAlign: 'center', padding: '2px'}}>Qty</th>
                      <th style={{textAlign: 'right', padding: '2px'}}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr style={{borderBottom: '1px dotted #ddd'}}>
                      <td style={{padding: '2px', fontWeight: 'bold', fontSize: invoiceSettings.fontSize === 'large' ? '16px' : '14px'}}>Vanilla Ice Cream</td>
                      <td style={{padding: '2px', textAlign: 'center'}}>1</td>
                      <td style={{padding: '2px', textAlign: 'right'}}>$4.99</td>
                    </tr>
                    <tr style={{borderBottom: '1px dotted #ddd'}}>
                      <td style={{padding: '2px', fontWeight: 'bold', fontSize: invoiceSettings.fontSize === 'large' ? '16px' : '14px'}}>Chocolate Cone</td>
                      <td style={{padding: '2px', textAlign: 'center'}}>1</td>
                      <td style={{padding: '2px', textAlign: 'right'}}>$5.49</td>
                    </tr>
                  </tbody>
                </table>
              ) : (
                <>
                  <div className="flex justify-between">
                    <span style={{fontWeight: 'bold', fontSize: invoiceSettings.fontSize === 'large' ? '16px' : '14px'}}>Vanilla Ice Cream</span>
                    <span>$4.99</span>
                  </div>
                  <div className="flex justify-between">
                    <span style={{fontWeight: 'bold', fontSize: invoiceSettings.fontSize === 'large' ? '16px' : '14px'}}>Chocolate Cone</span>
                    <span>$5.49</span>
                  </div>
                </>
              )}
            </div>
          )}

          <div className="border-t border-gray-200 pt-2 mt-2">
            {invoiceSettings.showTotal && (
              <div className="flex justify-between font-bold text-sm">
                <span>Total</span>
                <span>$10.48</span>
              </div>
            )}
            {invoiceSettings.showPaymentMethod && (
              <div className="text-xs text-gray-500 mt-1">Payment: Cash</div>
            )}
          </div>

          {invoiceSettings.showBarcode && (
            <div className="text-center mt-2">
              <div className="text-xs font-mono">||||| ||||| |||||</div>
            </div>
          )}

          {invoiceSettings.showFooterMessage && (
            <div className="text-center text-xs text-gray-500 mt-2">
              {invoiceSettings.footerText}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
              <Receipt className="h-6 w-6 mr-3" />
              دەستکاریکردنی پسوڵە
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>

          {/* Tabs */}
          <div className="flex space-x-1 mb-6 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('layout')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'layout'
                  ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              شێوەپێدان و بەشەکان
            </button>
            <button
              onClick={() => setActiveTab('content')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'content'
                  ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              ناوەڕۆک و دەق
            </button>
            <button
              onClick={() => setActiveTab('format')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'format'
                  ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              شێوەپێدان و پێشبینین
            </button>
          </div>

          {/* Tab Content */}
          <div className="min-h-[400px]">
            {activeTab === 'layout' && renderLayoutTab()}
            {activeTab === 'content' && renderContentTab()}
            {activeTab === 'format' && renderFormatTab()}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-600">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              هەڵوەشاندنەوە
            </button>
            <button
              onClick={handleSave}
              className="px-6 py-2 bg-gradient-to-r from-blue-500 to-cyan-600 text-white rounded-lg hover:from-blue-600 hover:to-cyan-700 transition-all flex items-center"
            >
              <SettingsIcon className="h-4 w-4 mr-2" />
              پاشەکەوتکردنی ڕێکخستنەکان
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}