import React from 'react';
import { Clock, Eye, Printer } from 'lucide-react';
import { Order } from '../../types';
import { format } from 'date-fns';

interface OrderHistoryProps {
  orders: Order[];
  onViewOrder: (order: Order) => void;
  onPrintOrder: (order: Order) => void;
}

export function OrderHistory({ orders, onViewOrder, onPrintOrder }: OrderHistoryProps) {
  const recentOrders = orders.slice(0, 15); // Show more orders

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 h-full">
      <div className="flex items-center mb-4">
        <Clock className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-2" />
        <h2 className="text-lg font-bold text-gray-900 dark:text-white">Recent Orders</h2>
      </div>

      <div className="space-y-2 max-h-80 overflow-y-auto">
        {recentOrders.length === 0 ? (
          <div className="text-center py-6">
            <Clock className="h-8 w-8 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-500 dark:text-gray-400 text-sm">No recent orders</p>
          </div>
        ) : (
          recentOrders.map((order) => (
            <div
              key={order.id}
              className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors border border-gray-100 dark:border-gray-600"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-gray-900 dark:text-white text-sm truncate">
                      {order.orderNumber}
                    </span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                      order.status === 'completed'
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                        : order.status === 'cancelled'
                        ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400'
                        : 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
                    <span>{order.items.length} item(s)</span>
                    <span className="font-medium text-blue-600 dark:text-blue-400 number">{order.total.toLocaleString()} د.ع</span>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-500">
                    {format(order.createdAt, 'MMM dd, HH:mm')}
                  </div>
                </div>
                <div className="flex space-x-1 ml-2">
                  <button
                    onClick={() => onViewOrder(order)}
                    className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                    title="View Details"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onPrintOrder(order)}
                    className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                    title="Print Receipt"
                  >
                    <Printer className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}