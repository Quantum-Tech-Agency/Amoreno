import React from 'react';
import { Package, AlertCircle } from 'lucide-react';
import { Product } from '../../types';

interface ProductGridProps {
  products: Product[];
  selectedCategory: string;
  onProductSelect: (product: Product) => void;
}

export function ProductGrid({ products, selectedCategory, onProductSelect }: ProductGridProps) {
  const filteredProducts = products.filter(
    product => selectedCategory === 'all' || product.category === selectedCategory
  );

  const categories = [
    { id: 'all', name: 'All Items', color: 'bg-gray-500' },
    { id: 'classic', name: 'Classic Flavors', color: 'bg-blue-500' },
    { id: 'premium', name: 'Premium Flavors', color: 'bg-purple-500' },
    { id: 'toppings', name: 'Toppings', color: 'bg-green-500' }
  ];

  return (
    <div className="space-y-6">
      {/* Category Filter */}
      <div className="flex flex-wrap gap-3">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => {}}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedCategory === category.id
                ? `${category.color} text-white shadow-lg`
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {filteredProducts.map((product) => (
          <button
            key={product.id}
            onClick={() => onProductSelect(product)}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-lg transition-all duration-200 p-4 border border-gray-200 dark:border-gray-700 hover:border-pink-300 dark:hover:border-pink-600 group"
          >
            <div className="aspect-square rounded-lg overflow-hidden mb-3 bg-gray-100 dark:bg-gray-700">
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-8 w-8 text-gray-400" />
                </div>
              )}
            </div>

            <div className="text-left">
              <h3 className="font-medium text-gray-900 dark:text-white text-sm mb-1 truncate">
                {product.name}
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-2 line-clamp-2">
                {product.description}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-pink-600 dark:text-pink-400">
                  ${product.basePrice.toFixed(2)}
                </span>
                {product.stock <= product.minStock && (
                  <AlertCircle className="h-4 w-4 text-red-500" />
                )}
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Stock: {product.stock}
              </div>
            </div>
          </button>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No products found in this category</p>
        </div>
      )}
    </div>
  );
}