import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { Product, ProductVariant, SelectedVariant } from '../../types';

interface ProductCustomizerProps {
  product: Product;
  onAddToOrder: (
    product: Product,
    variants: SelectedVariant[],
    quantity: number,
    specialInstructions?: string
  ) => void;
  onClose: () => void;
}

export function ProductCustomizer({ product, onAddToOrder, onClose }: ProductCustomizerProps) {
  const [selectedVariants, setSelectedVariants] = useState<SelectedVariant[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [specialInstructions, setSpecialInstructions] = useState('');

  const variants = {
    container: product.variants.filter(v => v.type === 'container'),
    size: product.variants.filter(v => v.type === 'size'),
    topping: product.variants.filter(v => v.type === 'topping')
  };

  const handleVariantSelect = (variant: ProductVariant) => {
    const selected: SelectedVariant = {
      id: variant.id,
      name: variant.name,
      price: variant.price,
      type: variant.type
    };

    if (variant.type === 'topping') {
      // Allow multiple toppings
      const exists = selectedVariants.find(v => v.id === variant.id);
      if (exists) {
        setSelectedVariants(selectedVariants.filter(v => v.id !== variant.id));
      } else {
        setSelectedVariants([...selectedVariants, selected]);
      }
    } else {
      // Only one container/size allowed
      setSelectedVariants([
        ...selectedVariants.filter(v => v.type !== variant.type),
        selected
      ]);
    }
  };

  const isVariantSelected = (variantId: string) => {
    return selectedVariants.some(v => v.id === variantId);
  };

  const calculateTotal = () => {
    const variantTotal = selectedVariants.reduce((sum, variant) => sum + variant.price, 0);
    return (product.basePrice + variantTotal) * quantity;
  };

  const handleAddToOrder = () => {
    onAddToOrder(product, selectedVariants, quantity, specialInstructions);
    onClose();
  };

  const canAddToOrder = () => {
    // For ice cream, require container and size selection
    if (product.category === 'classic' || product.category === 'premium') {
      const hasContainer = selectedVariants.some(v => v.type === 'container');
      const hasSize = selectedVariants.some(v => v.type === 'size');
      return hasContainer && hasSize;
    }
    return true;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <img
                src={product.image}
                alt={product.name}
                className="w-16 h-16 rounded-lg object-cover"
              />
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {product.name}
                </h2>
                <p className="text-gray-600 dark:text-gray-400">
                  {product.description}
                </p>
                <p className="text-lg font-semibold text-pink-600 dark:text-pink-400 mt-1">
                  ${product.basePrice.toFixed(2)}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Container Selection */}
            {variants.container.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Choose Container *
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {variants.container.map((variant) => (
                    <button
                      key={variant.id}
                      onClick={() => handleVariantSelect(variant)}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        isVariantSelected(variant.id)
                          ? 'border-pink-500 bg-pink-50 dark:bg-pink-900/20'
                          : 'border-gray-200 dark:border-gray-600 hover:border-pink-300 dark:hover:border-pink-600'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900 dark:text-white">
                          {variant.name}
                        </span>
                        {variant.price > 0 && (
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            +${variant.price.toFixed(2)}
                          </span>
                        )}
                      </div>
                      {isVariantSelected(variant.id) && (
                        <Check className="h-5 w-5 text-pink-500 mt-2" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selection */}
            {variants.size.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Choose Size *
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  {variants.size.map((variant) => (
                    <button
                      key={variant.id}
                      onClick={() => handleVariantSelect(variant)}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        isVariantSelected(variant.id)
                          ? 'border-pink-500 bg-pink-50 dark:bg-pink-900/20'
                          : 'border-gray-200 dark:border-gray-600 hover:border-pink-300 dark:hover:border-pink-600'
                      }`}
                    >
                      <div className="text-center">
                        <span className="font-medium text-gray-900 dark:text-white block">
                          {variant.name}
                        </span>
                        {variant.price > 0 && (
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            +${variant.price.toFixed(2)}
                          </span>
                        )}
                      </div>
                      {isVariantSelected(variant.id) && (
                        <Check className="h-5 w-5 text-pink-500 mt-2 mx-auto" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                Quantity
              </h3>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                >
                  -
                </button>
                <span className="text-xl font-semibold text-gray-900 dark:text-white w-12 text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Special Instructions */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                Special Instructions
              </h3>
              <textarea
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                placeholder="Any special requests or notes..."
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent resize-none"
                rows={3}
              />
            </div>
          </div>

          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200 dark:border-gray-600">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Total</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                ${calculateTotal().toFixed(2)}
              </p>
            </div>
            <button
              onClick={handleAddToOrder}
              disabled={!canAddToOrder()}
              className="px-8 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-lg font-medium hover:from-pink-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              Add to Order
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}