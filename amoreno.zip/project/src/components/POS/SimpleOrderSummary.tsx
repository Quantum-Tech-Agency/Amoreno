import React from 'react';
import { Trash2, Plus, Minus, Printer, X } from 'lucide-react';
import { OrderItem } from '../../types';
import { useApp } from '../../context/AppContext';
import { useTranslation } from '../../hooks/useTranslation';

interface SimpleOrderSummaryProps {
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onRemoveItem: (itemId: string) => void;
  onPrint: () => void;
  onClearOrder: () => void;
}

export function SimpleOrderSummary({
  items,
  subtotal,
  tax,
  total,
  onUpdateQuantity,
  onRemoveItem,
  onPrint,
  onClearOrder
}: SimpleOrderSummaryProps) {
  const { state } = useApp();
  const { t } = useTranslation();
  const colorPalette = state.settings.colorPalette;
  const isRTL = state.settings.language === 'ar';

  const formatPrice = (price: number) => {
    return `${price.toLocaleString()} د.ع`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 h-full flex flex-col">
      <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('currentOrder')}</h2>
        {items.length > 0 && (
          <button
            onClick={onClearOrder}
            className={`text-red-600 hover:text-red-700 text-xs font-medium flex items-center px-2 py-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <X className={`h-3 w-3 ${isRTL ? 'ml-1' : 'mr-1'}`} />
            {t('clearOrder')}
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto">
        {items.length === 0 ? (
          <div className="text-center py-8">
            <div className="bg-gray-100 dark:bg-gray-700 rounded-full p-3 w-12 h-12 mx-auto mb-3 flex items-center justify-center">
              <Plus className="h-6 w-6 text-gray-400" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-sm">{t('noItemsInOrder')}</p>
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
              {t('selectProducts')}
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {items.map((item) => (
              <div
                key={item.id}
                className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 border border-gray-100 dark:border-gray-600"
              >
                {/* Item Header */}
                <div className={`flex items-center justify-between mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <h3 className="font-medium text-gray-900 dark:text-white text-sm leading-tight">
                    {item.productName}
                  </h3>
                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>

                {/* Quantity Controls and Price */}
                <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center ${isRTL ? 'space-x-reverse space-x-2' : 'space-x-2'}`}>
                    <button
                      onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                      className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                    >
                      <Minus className="h-3 w-3" />
                    </button>
                    <span className="font-medium text-gray-900 dark:text-white text-sm w-6 text-center number">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                    >
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <div className={isRTL ? 'text-left' : 'text-right'}>
                    <div className="text-xs text-gray-500 dark:text-gray-400 number">
                      {formatPrice(item.basePrice)} {t('each')}
                    </div>
                    <div className={`font-bold text-sm bg-gradient-to-r ${colorPalette.primary} bg-clip-text text-transparent number`}>
                      {formatPrice(item.total)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {items.length > 0 && (
        <div className="border-t border-gray-200 dark:border-gray-600 pt-4 mt-4">
          <div className="space-y-1 mb-4">
            <div className={`flex justify-between text-lg font-bold text-gray-900 dark:text-white ${isRTL ? 'flex-row-reverse' : ''}`}>
              <span>{t('total')}</span>
              <span className="number">{formatPrice(total)}</span>
            </div>
          </div>

          <button
            onClick={onPrint}
            className={`w-full ${colorPalette.gradient} text-white py-3 rounded-lg font-medium hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all shadow-lg flex items-center justify-center ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Printer className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('printOrder')}
          </button>
        </div>
      )}
    </div>
  );
}