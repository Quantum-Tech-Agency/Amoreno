import React from 'react';
import { Category } from '../../types';
import { useApp } from '../../context/AppContext';

interface CategoryFilterProps {
  categories: Category[];
  selectedCategory: string;
  onCategorySelect: (categoryId: string) => void;
}

export function CategoryFilter({ categories, selectedCategory, onCategorySelect }: CategoryFilterProps) {
  const { state } = useApp();
  const colorPalette = state.settings.colorPalette;

  const allCategory = { id: 'all', name: 'All Items' };
  const allCategories = [allCategory, ...categories.filter(c => c.isActive).sort((a, b) => a.sortOrder - b.sortOrder)];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 text-center">
        Categories
      </h3>
      <div className="flex flex-wrap gap-2 justify-center">
        {allCategories.map((category) => (
          <button
            key={category.id}
            onClick={() => onCategorySelect(category.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all transform hover:scale-105 ${
              selectedCategory === category.id
                ? `${colorPalette.gradient} text-white shadow-lg`
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>
    </div>
  );
}