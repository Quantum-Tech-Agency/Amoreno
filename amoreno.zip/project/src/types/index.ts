export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'cashier' | 'manager' | 'owner';
  firstName: string;
  lastName: string;
  isActive: boolean;
  createdAt: Date;
  password?: string;
  branchId: string;
}

export interface Branch {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  isActive: boolean;
  managerId?: string;
  createdAt: Date;
  settings: BranchSettings;
}

export interface BranchSettings {
  businessName: string;
  logo?: string;
  taxRate: number;
  currency: string;
  theme: 'light' | 'dark';
  language: 'en' | 'ar' | 'ku';
  receiptFooter: string;
  colorPalette: ColorPalette;
}

export interface InvoiceSettings {
  showLogo: boolean;
  showBusinessInfo: boolean;
  showBranchInfo: boolean;
  showCashierInfo: boolean;
  showOrderNumber: boolean;
  showDateTime: boolean;
  showItemDetails: boolean;
  showPrices: boolean;
  showTax: boolean;
  showTotal: boolean;
  showPaymentMethod: boolean;
  showBarcode: boolean;
  showFooterMessage: boolean;
  paperSize: '58mm' | '80mm';
  fontSize: 'small' | 'medium' | 'large';
  headerText: string;
  footerText: string;
  thankYouMessage: string;
  includeQRCode: boolean;
  showItemImages: boolean;
  showCustomerInfo: boolean;
  showOrderNotes: boolean;
  printCopies: number;
  autoOpenCashDrawer: boolean;
  useTableLayout?: boolean;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: Date;
  branchId: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  categoryId: string;
  category: string;
  basePrice: number;
  image: string;
  isActive: boolean;
  variants: ProductVariant[];
  branchId: string;
  stock?: number;
  minStock?: number;
}

export interface ProductVariant {
  id: string;
  name: string;
  price: number;
  type: 'size' | 'container' | 'topping';
}

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  basePrice: number;
  quantity: number;
  variants: SelectedVariant[];
  specialInstructions?: string;
  total: number;
}

export interface SelectedVariant {
  id: string;
  name: string;
  price: number;
  type: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: 'cash' | 'card' | 'mobile';
  status: 'completed' | 'cancelled' | 'refunded';
  customerName?: string;
  customerNote?: string;
  cashierId: string;
  cashierName: string;
  branchId: string;
  createdAt: Date;
  completedAt: Date;
}

export interface InventoryItem {
  id: string;
  productId: string;
  productName: string;
  currentStock: number;
  minStock: number;
  maxStock: number;
  unit: string;
  lastRestocked: Date;
  cost: number;
  branchId: string;
}

export interface Sale {
  id: string;
  orderId: string;
  amount: number;
  paymentMethod: string;
  date: Date;
  cashierId: string;
  branchId: string;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  loyaltyPoints: number;
  totalSpent: number;
  lastVisit: Date;
  createdAt: Date;
  branchId: string;
}

export interface ColorPalette {
  id: string;
  name: string;
  primary: string;
  secondary: string;
  gradient: string;
}

export interface AppSettings {
  businessName: string;
  logo?: string;
  taxRate: number;
  currency: string;
  theme: 'light' | 'dark';
  language: 'en' | 'ar' | 'ku';
  receiptFooter: string;
  colorPalette: ColorPalette;
  currentBranchId: string;
  invoiceSettings: InvoiceSettings;
  customFont?: string | null;
}