import initSqlJs, { Database } from 'sql.js';

class DatabaseService {
  private db: Database | null = null;
  private isInitialized = false;

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      const SQL = await initSqlJs({
        locateFile: (file) => `https://sql.js.org/dist/${file}`
      });

      // Try to load existing database from localStorage
      const savedDb = localStorage.getItem('pos_database');
      if (savedDb) {
        try {
          const uint8Array = new Uint8Array(JSON.parse(savedDb));
          this.db = new SQL.Database(uint8Array);
          console.log('✅ Database loaded from localStorage');
        } catch (error) {
          console.warn('⚠️ Failed to load database from localStorage, creating new one:', error);
          this.db = new SQL.Database();
          await this.createTables();
          await this.seedInitialData();
        }
      } else {
        this.db = new SQL.Database();
        await this.createTables();
        await this.seedInitialData();
      }

      this.isInitialized = true;
      console.log('✅ Database initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize database:', error);
      // Don't throw error, let the app continue with localStorage fallback
      this.isInitialized = false;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const tables = [
      // Branches table
      `CREATE TABLE IF NOT EXISTS branches (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        isActive INTEGER DEFAULT 1,
        managerId TEXT,
        settings TEXT,
        createdAt TEXT NOT NULL
      )`,

      // Users table
      `CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        email TEXT NOT NULL,
        role TEXT NOT NULL,
        firstName TEXT NOT NULL,
        lastName TEXT NOT NULL,
        isActive INTEGER DEFAULT 1,
        password TEXT NOT NULL,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Categories table
      `CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        isActive INTEGER DEFAULT 1,
        sortOrder INTEGER DEFAULT 0,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Products table
      `CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        categoryId TEXT NOT NULL,
        category TEXT NOT NULL,
        basePrice REAL NOT NULL,
        image TEXT,
        isActive INTEGER DEFAULT 1,
        variants TEXT,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (categoryId) REFERENCES categories (id),
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Orders table
      `CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        orderNumber TEXT NOT NULL,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        tax REAL DEFAULT 0,
        discount REAL DEFAULT 0,
        total REAL NOT NULL,
        paymentMethod TEXT NOT NULL,
        status TEXT NOT NULL,
        customerName TEXT,
        customerNote TEXT,
        cashierId TEXT NOT NULL,
        cashierName TEXT NOT NULL,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        completedAt TEXT NOT NULL,
        FOREIGN KEY (cashierId) REFERENCES users (id),
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // Customers table
      `CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        loyaltyPoints INTEGER DEFAULT 0,
        totalSpent REAL DEFAULT 0,
        lastVisit TEXT NOT NULL,
        branchId TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (branchId) REFERENCES branches (id)
      )`,

      // App settings table
      `CREATE TABLE IF NOT EXISTS app_settings (
        id TEXT PRIMARY KEY,
        businessName TEXT NOT NULL,
        logo TEXT,
        taxRate REAL DEFAULT 0,
        currency TEXT DEFAULT 'IQD',
        theme TEXT DEFAULT 'light',
        language TEXT DEFAULT 'ku',
        receiptFooter TEXT,
        colorPalette TEXT,
        currentBranchId TEXT NOT NULL
      )`
    ];

    for (const table of tables) {
      try {
        this.db.run(table);
      } catch (error) {
        console.error('Failed to create table:', error);
      }
    }
  }

  private async seedInitialData(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    try {
      // Create multiple branches
      const branches = [
        {
          id: 'branch-1',
          name: 'لقی سەرەکی - ناوەندی شار',
          address: '١٢٣ شەقامی سەرەکی، ناوەندی شار',
          phone: '+964 750 123 4567',
          email: 'main@icecream.com'
        },
        {
          id: 'branch-2',
          name: 'لقی باکوور - پاساژ',
          address: '٤٥٦ شەقامی پاساژ، ناحیەی باکوور',
          phone: '+964 750 234 5678',
          email: 'north@icecream.com'
        },
        {
          id: 'branch-3',
          name: 'لقی باشوور - پلازا',
          address: '٧٨٩ شەقامی پلازا، ناحیەی باشوور',
          phone: '+964 750 345 6789',
          email: 'south@icecream.com'
        }
      ];

      const defaultBranchSettings = {
        businessName: 'ئەمۆرینۆ ئایسکرێم',
        taxRate: 0,
        currency: 'IQD',
        theme: 'light',
        language: 'ku',
        receiptFooter: 'سوپاس بۆ سەردانەکەت!',
        colorPalette: {
          id: 'blue',
          name: 'شینی زەریا',
          primary: 'from-blue-500 to-cyan-600',
          secondary: 'from-blue-600 to-cyan-700',
          gradient: 'bg-gradient-to-r from-blue-500 to-cyan-600'
        }
      };

      // Insert branches
      for (const branch of branches) {
        this.db.run(`
          INSERT OR IGNORE INTO branches (id, name, address, phone, email, isActive, settings, createdAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          branch.id,
          branch.name,
          branch.address,
          branch.phone,
          branch.email,
          1,
          JSON.stringify(defaultBranchSettings),
          new Date().toISOString()
        ]);
      }

      // Create users for different branches
      const users = [
        // Main Branch Users
        {
          id: 'user-1',
          username: 'admin_main',
          email: 'admin.main@icecream.com',
          role: 'admin',
          firstName: 'ئەحمەد',
          lastName: 'حەسەن',
          password: 'password',
          branchId: 'branch-1'
        },
        {
          id: 'user-2',
          username: 'cashier_main',
          email: 'cashier.main@icecream.com',
          role: 'cashier',
          firstName: 'فاتیمە',
          lastName: 'عەلی',
          password: 'password',
          branchId: 'branch-1'
        },
        // North Branch Users
        {
          id: 'user-3',
          username: 'admin_north',
          email: 'admin.north@icecream.com',
          role: 'admin',
          firstName: 'عومەر',
          lastName: 'محەمەد',
          password: 'password',
          branchId: 'branch-2'
        },
        {
          id: 'user-4',
          username: 'cashier_north',
          email: 'cashier.north@icecream.com',
          role: 'cashier',
          firstName: 'زارا',
          lastName: 'ئەحمەد',
          password: 'password',
          branchId: 'branch-2'
        },
        // South Branch Users
        {
          id: 'user-5',
          username: 'admin_south',
          email: 'admin.south@icecream.com',
          role: 'admin',
          firstName: 'کەریم',
          lastName: 'سەلیم',
          password: 'password',
          branchId: 'branch-3'
        },
        {
          id: 'user-6',
          username: 'cashier_south',
          email: 'cashier.south@icecream.com',
          role: 'cashier',
          firstName: 'لەیلا',
          lastName: 'ڕەشید',
          password: 'password',
          branchId: 'branch-3'
        },
        // Owner (can access all branches)
        {
          id: 'user-owner',
          username: 'owner',
          email: 'owner@icecream.com',
          role: 'owner',
          firstName: 'سەلام',
          lastName: 'کوردستان',
          password: 'password',
          branchId: 'branch-1' // Default branch
        }
      ];

      for (const user of users) {
        this.db.run(`
          INSERT OR IGNORE INTO users (id, username, email, role, firstName, lastName, password, branchId, createdAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          user.id,
          user.username,
          user.email,
          user.role,
          user.firstName,
          user.lastName,
          user.password,
          user.branchId,
          new Date().toISOString()
        ]);
      }

      // Create categories for each branch
      const categoryTemplates = [
        { name: 'بەستەڵەکی نەرم', description: 'جۆرەکانی بەستەڵەکی نەرمی کرێمی', sortOrder: 1 },
        { name: 'بەستەڵەکی سروشتی', description: 'بەستەڵەکی سروشتی دروستکراو لە پێکهاتە ئۆرگانیکەکان', sortOrder: 2 },
        { name: 'بەستەڵەکی ئیتاڵی', description: 'جێلاتۆ و بەستەڵەکی ئیتاڵی ڕاستەقینە', sortOrder: 3 },
        { name: 'ئاوەکان', description: 'ئاوی میوەی تازە و سمووسی', sortOrder: 4 },
        { name: 'زیادکراوەکان', description: 'زیادکراوە و تێکەڵکراوە خۆشەکان', sortOrder: 5 }
      ];

      let categoryId = 1;
      for (const branch of branches) {
        for (const template of categoryTemplates) {
          this.db.run(`
            INSERT OR IGNORE INTO categories (id, name, description, isActive, sortOrder, branchId, createdAt)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `, [
            `cat-${categoryId}`,
            template.name,
            template.description,
            1,
            template.sortOrder,
            branch.id,
            new Date().toISOString()
          ]);
          categoryId++;
        }
      }

      this.saveToLocalStorage();
      console.log('✅ Initial data seeded successfully');
    } catch (error) {
      console.error('❌ Failed to seed initial data:', error);
    }
  }

  saveToLocalStorage(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const dataArray = Array.from(data);
      localStorage.setItem('pos_database', JSON.stringify(dataArray));
      console.log('✅ Database saved to localStorage');
    } catch (error) {
      console.error('❌ Failed to save database to localStorage:', error);
    }
  }

  // Authentication
  async authenticateUser(username: string, password: string): Promise<any | null> {
    if (!this.db) {
      console.warn('Database not available, using fallback authentication');
      return null;
    }
    
    try {
      console.log(`🔍 Searching for user: ${username}`);
      
      const stmt = this.db.prepare('SELECT * FROM users WHERE username = ? AND password = ? AND isActive = 1');
      stmt.bind([username, password]);
      
      let user = null;
      if (stmt.step()) {
        const row = stmt.getAsObject();
        user = {
          ...row,
          isActive: Boolean(row.isActive),
          createdAt: new Date(row.createdAt as string)
        };
        console.log(`✅ User found in database: ${username}`);
      } else {
        console.log(`❌ User not found in database: ${username}`);
      }
      
      stmt.free();
      return user;
    } catch (error) {
      console.error('Authentication error:', error);
      return null;
    }
  }

  // Branch operations
  async getBranches(): Promise<any[]> {
    if (!this.db) {
      console.warn('Database not available, returning empty branches array');
      return [];
    }
    
    try {
      const stmt = this.db.prepare('SELECT * FROM branches WHERE isActive = 1 ORDER BY name');
      const branches = [];
      
      while (stmt.step()) {
        const row = stmt.getAsObject();
        branches.push({
          ...row,
          settings: JSON.parse(row.settings as string),
          isActive: Boolean(row.isActive),
          createdAt: new Date(row.createdAt as string)
        });
      }
      
      stmt.free();
      return branches;
    } catch (error) {
      console.error('Failed to get branches:', error);
      return [];
    }
  }

  async createBranch(branch: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        INSERT INTO branches (id, name, address, phone, email, isActive, managerId, settings, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        branch.id,
        branch.name,
        branch.address,
        branch.phone,
        branch.email,
        branch.isActive ? 1 : 0,
        branch.managerId,
        JSON.stringify(branch.settings),
        branch.createdAt.toISOString()
      ]);
      
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to create branch:', error);
      throw error;
    }
  }

  // User operations
  async getUsers(branchId?: string): Promise<any[]> {
    if (!this.db) {
      console.warn('Database not available, returning empty users array');
      return [];
    }
    
    try {
      let query = 'SELECT * FROM users WHERE isActive = 1';
      const params = [];
      
      if (branchId) {
        query += ' AND branchId = ?';
        params.push(branchId);
      }
      
      query += ' ORDER BY firstName, lastName';
      
      const stmt = this.db.prepare(query);
      if (params.length > 0) {
        stmt.bind(params);
      }
      
      const users = [];
      
      while (stmt.step()) {
        const row = stmt.getAsObject();
        users.push({
          ...row,
          isActive: Boolean(row.isActive),
          createdAt: new Date(row.createdAt as string)
        });
      }
      
      stmt.free();
      return users;
    } catch (error) {
      console.error('Failed to get users:', error);
      return [];
    }
  }

  async createUser(user: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        INSERT INTO users (id, username, email, role, firstName, lastName, isActive, password, branchId, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        user.id,
        user.username,
        user.email,
        user.role,
        user.firstName,
        user.lastName,
        user.isActive ? 1 : 0,
        user.password,
        user.branchId,
        user.createdAt.toISOString()
      ]);
      
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to create user:', error);
      throw error;
    }
  }

  async updateUser(user: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        UPDATE users 
        SET username = ?, email = ?, role = ?, firstName = ?, lastName = ?, isActive = ?, password = ?, branchId = ?
        WHERE id = ?
      `, [
        user.username,
        user.email,
        user.role,
        user.firstName,
        user.lastName,
        user.isActive ? 1 : 0,
        user.password,
        user.branchId,
        user.id
      ]);
      
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to update user:', error);
      throw error;
    }
  }

  async deleteUser(userId: string): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run('UPDATE users SET isActive = 0 WHERE id = ?', [userId]);
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to delete user:', error);
      throw error;
    }
  }

  // Category operations
  async getCategories(branchId: string): Promise<any[]> {
    if (!this.db) {
      console.warn('Database not available, returning empty categories array');
      return [];
    }
    
    try {
      const stmt = this.db.prepare('SELECT * FROM categories WHERE branchId = ? AND isActive = 1 ORDER BY sortOrder');
      stmt.bind([branchId]);
      
      const categories = [];
      
      while (stmt.step()) {
        const row = stmt.getAsObject();
        categories.push({
          ...row,
          isActive: Boolean(row.isActive),
          createdAt: new Date(row.createdAt as string)
        });
      }
      
      stmt.free();
      return categories;
    } catch (error) {
      console.error('Failed to get categories:', error);
      return [];
    }
  }

  async createCategory(category: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        INSERT INTO categories (id, name, description, isActive, sortOrder, branchId, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        category.id,
        category.name,
        category.description,
        category.isActive ? 1 : 0,
        category.sortOrder,
        category.branchId,
        category.createdAt.toISOString()
      ]);
      
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to create category:', error);
      throw error;
    }
  }

  async updateCategory(category: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        UPDATE categories 
        SET name = ?, description = ?, isActive = ?, sortOrder = ?
        WHERE id = ?
      `, [
        category.name,
        category.description,
        category.isActive ? 1 : 0,
        category.sortOrder,
        category.id
      ]);
      
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to update category:', error);
      throw error;
    }
  }

  async deleteCategory(categoryId: string): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run('UPDATE categories SET isActive = 0 WHERE id = ?', [categoryId]);
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to delete category:', error);
      throw error;
    }
  }

  // Product operations
  async getProducts(branchId: string): Promise<any[]> {
    if (!this.db) {
      console.warn('Database not available, returning empty products array');
      return [];
    }
    
    try {
      const stmt = this.db.prepare('SELECT * FROM products WHERE branchId = ? ORDER BY name');
      stmt.bind([branchId]);
      
      const products = [];
      
      while (stmt.step()) {
        const row = stmt.getAsObject();
        products.push({
          ...row,
          variants: JSON.parse(row.variants as string || '[]'),
          isActive: Boolean(row.isActive),
          createdAt: new Date(row.createdAt as string)
        });
      }
      
      stmt.free();
      return products;
    } catch (error) {
      console.error('Failed to get products:', error);
      return [];
    }
  }

  async createProduct(product: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        INSERT INTO products (id, name, description, categoryId, category, basePrice, image, isActive, variants, branchId, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        product.id,
        product.name,
        product.description,
        product.categoryId,
        product.category,
        product.basePrice,
        product.image,
        product.isActive ? 1 : 0,
        JSON.stringify(product.variants || []),
        product.branchId,
        new Date().toISOString()
      ]);
      
      this.saveToLocalStorage();
      console.log('✅ Product created in database');
    } catch (error) {
      console.error('❌ Failed to create product in database:', error);
      throw error;
    }
  }

  async updateProduct(product: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        UPDATE products 
        SET name = ?, description = ?, categoryId = ?, category = ?, basePrice = ?, image = ?, isActive = ?, variants = ?
        WHERE id = ?
      `, [
        product.name,
        product.description,
        product.categoryId,
        product.category,
        product.basePrice,
        product.image,
        product.isActive ? 1 : 0,
        JSON.stringify(product.variants || []),
        product.id
      ]);
      
      this.saveToLocalStorage();
      console.log('✅ Product updated in database');
    } catch (error) {
      console.error('❌ Failed to update product in database:', error);
      throw error;
    }
  }

  async deleteProduct(productId: string): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      // Completely delete the product from the database
      const result = this.db.run('DELETE FROM products WHERE id = ?', [productId]);
      
      if (result && result.changes === 0) {
        console.warn('⚠️ No product found with ID:', productId);
      } else {
        console.log('✅ Product deleted from database successfully');
      }
      
      // Save the updated database to localStorage
      this.saveToLocalStorage();
    } catch (error) {
      console.error('❌ Failed to delete product from database:', error);
      throw error;
    }
  }

  // Order operations
  async getOrders(branchId: string): Promise<any[]> {
    if (!this.db) {
      console.warn('Database not available, returning empty orders array');
      return [];
    }
    
    try {
      const stmt = this.db.prepare('SELECT * FROM orders WHERE branchId = ? ORDER BY createdAt DESC');
      stmt.bind([branchId]);
      
      const orders = [];
      
      while (stmt.step()) {
        const row = stmt.getAsObject();
        orders.push({
          ...row,
          items: JSON.parse(row.items as string),
          createdAt: new Date(row.createdAt as string),
          completedAt: new Date(row.completedAt as string)
        });
      }
      
      stmt.free();
      return orders;
    } catch (error) {
      console.error('Failed to get orders:', error);
      return [];
    }
  }

  async createOrder(order: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      this.db.run(`
        INSERT INTO orders (id, orderNumber, items, subtotal, tax, discount, total, paymentMethod, status, customerName, customerNote, cashierId, cashierName, branchId, createdAt, completedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        order.id,
        order.orderNumber,
        JSON.stringify(order.items),
        order.subtotal,
        order.tax,
        order.discount,
        order.total,
        order.paymentMethod,
        order.status,
        order.customerName,
        order.customerNote,
        order.cashierId,
        order.cashierName,
        order.branchId,
        order.createdAt.toISOString(),
        order.completedAt.toISOString()
      ]);
      
      this.saveToLocalStorage();
    } catch (error) {
      console.error('Failed to create order:', error);
      throw error;
    }
  }

  // Customer operations
  async getCustomers(branchId: string): Promise<any[]> {
    if (!this.db) {
      console.warn('Database not available, returning empty customers array');
      return [];
    }
    
    try {
      const stmt = this.db.prepare('SELECT * FROM customers WHERE branchId = ? ORDER BY name');
      stmt.bind([branchId]);
      
      const customers = [];
      
      while (stmt.step()) {
        const row = stmt.getAsObject();
        customers.push({
          ...row,
          lastVisit: new Date(row.lastVisit as string),
          createdAt: new Date(row.createdAt as string)
        });
      }
      
      stmt.free();
      return customers;
    } catch (error) {
      console.error('Failed to get customers:', error);
      return [];
    }
  }

  // Reset financial data
  async resetFinancialData(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      // Delete all orders
      this.db.run('DELETE FROM orders');
      
      // Delete all customers
      this.db.run('DELETE FROM customers');
      
      this.saveToLocalStorage();
      console.log('✅ Financial data reset successfully');
    } catch (error) {
      console.error('❌ Failed to reset financial data:', error);
      throw error;
    }
  }

  // Export database
  exportDatabase(): Uint8Array {
    if (!this.db) throw new Error('Database not initialized');
    return this.db.export();
  }

  // Import database
  async importDatabase(data: Uint8Array): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file) => `https://sql.js.org/dist/${file}`
      });
      
      this.db = new SQL.Database(data);
      this.saveToLocalStorage();
      console.log('✅ Database imported successfully');
    } catch (error) {
      console.error('❌ Failed to import database:', error);
      throw error;
    }
  }
}

export const dbService = new DatabaseService();