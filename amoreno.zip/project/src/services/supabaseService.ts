import { supabase } from './supabase'
import type { Product, Order, User, Branch, Category, Customer } from '../types'

export class SupabaseService {
  private isAvailable = false

  constructor() {
    this.checkAvailability()
  }

  private async checkAvailability() {
    try {
      const { error } = await supabase.from('branches').select('count', { count: 'exact', head: true })
      this.isAvailable = !error
      if (this.isAvailable) {
        console.log('✅ Supabase service is available')
      }
    } catch (error) {
      console.warn('⚠️ Supabase service not available:', error)
      this.isAvailable = false
    }
  }

  // Authentication
  async signIn(email: string, password: string) {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    return { data, error }
  }

  async signOut() {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { error } = await supabase.auth.signOut()
    return { error }
  }

  async getCurrentUser() {
    if (!this.isAvailable) {
      return null
    }

    const { data: { user } } = await supabase.auth.getUser()
    return user
  }

  // Branches
  async getBranches(): Promise<Branch[]> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('branches')
      .select('*')
      .eq('is_active', true)
      .order('name')

    if (error) throw error
    return data || []
  }

  async createBranch(branch: Omit<Branch, 'id' | 'createdAt'>): Promise<Branch> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('branches')
      .insert([{
        ...branch,
        created_at: new Date().toISOString()
      }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Users
  async getUsers(branchId?: string): Promise<User[]> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    let query = supabase
      .from('users')
      .select('*')
      .eq('is_active', true)

    if (branchId) {
      query = query.eq('branch_id', branchId)
    }

    const { data, error } = await query.order('first_name')

    if (error) throw error
    return data || []
  }

  async createUser(user: Omit<User, 'id' | 'createdAt'>): Promise<User> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('users')
      .insert([{
        ...user,
        created_at: new Date().toISOString()
      }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Categories
  async getCategories(branchId: string): Promise<Category[]> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('branch_id', branchId)
      .eq('is_active', true)
      .order('sort_order')

    if (error) throw error
    return data || []
  }

  async createCategory(category: Omit<Category, 'id' | 'createdAt'>): Promise<Category> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('categories')
      .insert([{
        ...category,
        created_at: new Date().toISOString()
      }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  async updateCategory(category: Category): Promise<Category> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('categories')
      .update({
        ...category,
        updated_at: new Date().toISOString()
      })
      .eq('id', category.id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  async deleteCategory(id: string): Promise<void> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { error } = await supabase
      .from('categories')
      .update({ is_active: false })
      .eq('id', id)

    if (error) throw error
  }

  // Products
  async getProducts(branchId: string): Promise<Product[]> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('branch_id', branchId)
      .eq('is_active', true)
      .order('name')

    if (error) throw error
    return data || []
  }

  async createProduct(product: Omit<Product, 'id'>): Promise<Product> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('products')
      .insert([{
        ...product,
        created_at: new Date().toISOString()
      }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  async updateProduct(product: Product): Promise<Product> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('products')
      .update({
        ...product,
        updated_at: new Date().toISOString()
      })
      .eq('id', product.id)
      .select()
      .single()

    if (error) throw error
    return data
  }

  async deleteProduct(id: string): Promise<void> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { error } = await supabase
      .from('products')
      .update({ is_active: false })
      .eq('id', id)

    if (error) throw error
  }

  // Orders
  async getOrders(branchId: string): Promise<Order[]> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('branch_id', branchId)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  async createOrder(order: Omit<Order, 'id'>): Promise<Order> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('orders')
      .insert([{
        ...order,
        created_at: new Date().toISOString()
      }])
      .select()
      .single()

    if (error) throw error
    return data
  }

  // Customers
  async getCustomers(branchId: string): Promise<Customer[]> {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available')
    }

    const { data, error } = await supabase
      .from('customers')
      .select('*')
      .eq('branch_id', branchId)
      .order('name')

    if (error) throw error
    return data || []
  }

  // Real-time subscriptions
  subscribeToProducts(branchId: string, callback: (payload: any) => void) {
    if (!this.isAvailable) {
      console.warn('⚠️ Supabase not available, skipping real-time subscription')
      return { unsubscribe: () => {} }
    }

    return supabase
      .channel('products-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products',
          filter: `branch_id=eq.${branchId}`
        },
        callback
      )
      .subscribe()
  }

  subscribeToOrders(branchId: string, callback: (payload: any) => void) {
    if (!this.isAvailable) {
      console.warn('⚠️ Supabase not available, skipping real-time subscription')
      return { unsubscribe: () => {} }
    }

    return supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `branch_id=eq.${branchId}`
        },
        callback
      )
      .subscribe()
  }

  subscribeToCategories(branchId: string, callback: (payload: any) => void) {
    if (!this.isAvailable) {
      console.warn('⚠️ Supabase not available, skipping real-time subscription')
      return { unsubscribe: () => {} }
    }

    return supabase
      .channel('categories-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'categories',
          filter: `branch_id=eq.${branchId}`
        },
        callback
      )
      .subscribe()
  }

  // Data migration utilities
  async migrateFromLocalData(localData: any) {
    if (!this.isAvailable) {
      throw new Error('Supabase service not available for migration')
    }

    console.log('🚀 Starting data migration to Supabase...')
    
    try {
      // Migrate branches
      if (localData.branches?.length) {
        for (const branch of localData.branches) {
          await this.createBranch(branch)
        }
        console.log('✅ Branches migrated')
      }

      // Migrate categories
      if (localData.categories?.length) {
        for (const category of localData.categories) {
          await this.createCategory(category)
        }
        console.log('✅ Categories migrated')
      }

      // Migrate products
      if (localData.products?.length) {
        for (const product of localData.products) {
          await this.createProduct(product)
        }
        console.log('✅ Products migrated')
      }

      // Migrate orders
      if (localData.orders?.length) {
        for (const order of localData.orders) {
          await this.createOrder(order)
        }
        console.log('✅ Orders migrated')
      }

      console.log('🎉 Data migration completed successfully!')
    } catch (error) {
      console.error('❌ Migration failed:', error)
      throw error
    }
  }

  // Health check
  async healthCheck(): Promise<boolean> {
    try {
      const { error } = await supabase.from('branches').select('count', { count: 'exact', head: true })
      this.isAvailable = !error
      return this.isAvailable
    } catch (error) {
      this.isAvailable = false
      return false
    }
  }

  get available() {
    return this.isAvailable
  }
}

export const supabaseService = new SupabaseService()