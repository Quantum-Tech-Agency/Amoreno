import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('⚠️ Supabase credentials not found. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment variables.')
}

export const supabase = createClient(supabaseUrl || '', supabaseAnonKey || '', {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// Test connection
supabase.from('branches').select('count', { count: 'exact', head: true })
  .then(({ error }) => {
    if (error) {
      console.warn('⚠️ Supabase connection failed:', error.message)
    } else {
      console.log('✅ Supabase connected successfully')
    }
  })
  .catch(() => {
    console.warn('⚠️ Supabase connection test failed')
  })