import { useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';

interface BackupData {
  timestamp: string;
  version: string;
  data: {
    orders: any[];
    products: any[];
    categories: any[];
    customers: any[];
    users: any[];
    settings: any;
  };
}

export function useAutoBackup() {
  const { state } = useApp();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastBackupRef = useRef<string>('');

  const createBackup = () => {
    try {
      const backupData: BackupData = {
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        data: {
          orders: state.orders,
          products: state.products,
          categories: state.categories,
          customers: state.customers,
          users: state.users.map(u => ({ ...u, password: undefined })), // Remove passwords from backup
          settings: state.settings
        }
      };

      const dataStr = JSON.stringify(backupData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      
      // Create filename with timestamp
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `ice-cream-pos-backup-${timestamp}.json`;
      
      // Create download link
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      
      // Trigger download
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up
      URL.revokeObjectURL(url);
      
      // Update last backup timestamp
      lastBackupRef.current = new Date().toISOString();
      localStorage.setItem('lastBackup', lastBackupRef.current);
      
      console.log(`✅ Auto backup created: ${filename}`);
      
      // Show notification
      showBackupNotification(filename);
      
    } catch (error) {
      console.error('❌ Failed to create backup:', error);
      showBackupErrorNotification();
    }
  };

  const showBackupNotification = (filename: string) => {
    // Create a temporary notification
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #10B981;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
      max-width: 300px;
      animation: slideIn 0.3s ease-out;
    `;
    
    notification.innerHTML = `
      <div style="display: flex; align-items: center;">
        <div style="margin-right: 8px;">💾</div>
        <div>
          <div style="font-weight: 600;">Backup Created</div>
          <div style="font-size: 12px; opacity: 0.9;">${filename}</div>
        </div>
      </div>
    `;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
      notification.style.animation = 'slideIn 0.3s ease-out reverse';
      setTimeout(() => {
        if (notification.parentNode) {
          document.body.removeChild(notification);
        }
        if (style.parentNode) {
          document.head.removeChild(style);
        }
      }, 300);
    }, 5000);
  };

  const showBackupErrorNotification = () => {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #EF4444;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
      max-width: 300px;
    `;
    
    notification.innerHTML = `
      <div style="display: flex; align-items: center;">
        <div style="margin-right: 8px;">❌</div>
        <div>
          <div style="font-weight: 600;">Backup Failed</div>
          <div style="font-size: 12px; opacity: 0.9;">Please check console for details</div>
        </div>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentNode) {
        document.body.removeChild(notification);
      }
    }, 5000);
  };

  const startAutoBackup = () => {
    // Clear existing interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    // Create backup every 30 minutes (30 * 60 * 1000 ms)
    intervalRef.current = setInterval(() => {
      createBackup();
    }, 30 * 60 * 1000);
    
    console.log('🔄 Auto backup started - every 30 minutes');
  };

  const stopAutoBackup = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
      console.log('⏹️ Auto backup stopped');
    }
  };

  const manualBackup = () => {
    createBackup();
  };

  const getLastBackupTime = () => {
    return localStorage.getItem('lastBackup');
  };

  // Start auto backup when component mounts
  useEffect(() => {
    // Load last backup time
    const lastBackup = localStorage.getItem('lastBackup');
    if (lastBackup) {
      lastBackupRef.current = lastBackup;
    }
    
    // Start auto backup
    startAutoBackup();
    
    // Create initial backup if none exists
    if (!lastBackup) {
      setTimeout(() => {
        createBackup();
      }, 5000); // Wait 5 seconds after app start
    }
    
    // Cleanup on unmount
    return () => {
      stopAutoBackup();
    };
  }, []);

  // Create backup when critical data changes
  useEffect(() => {
    const dataHash = JSON.stringify({
      ordersCount: state.orders.length,
      productsCount: state.products.length,
      usersCount: state.users.length
    });
    
    // Only backup if significant changes occurred and it's been at least 5 minutes since last backup
    const lastBackup = lastBackupRef.current;
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    
    if (lastBackup && lastBackup < fiveMinutesAgo && state.orders.length > 0) {
      // Debounce backup creation
      const timeoutId = setTimeout(() => {
        createBackup();
      }, 2000);
      
      return () => clearTimeout(timeoutId);
    }
  }, [state.orders.length, state.products.length, state.users.length]);

  return {
    manualBackup,
    getLastBackupTime,
    isAutoBackupActive: !!intervalRef.current
  };
}