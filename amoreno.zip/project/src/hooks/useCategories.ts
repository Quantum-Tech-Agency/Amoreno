import { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { dbService } from '../services/database';
import { Category } from '../types';

export function useCategories() {
  const { state, dispatch } = useApp();

  const loadCategories = async () => {
    try {
      // Load categories from database for current branch
      const categories = await dbService.getCategories(state.settings.currentBranchId);
      dispatch({ type: 'SET_CATEGORIES', payload: categories });
    } catch (error) {
      console.error('Failed to load categories:', error);
      // Fallback to mock data if database fails
      loadMockCategories();
    }
  };

  const loadMockCategories = () => {
    const mockCategories: Category[] = [
      {
        id: '1',
        name: 'Soft Ice Cream',
        description: 'Creamy soft serve ice cream varieties',
        isActive: true,
        sortOrder: 1,
        branchId: state.settings.currentBranchId,
        createdAt: new Date()
      },
      {
        id: '2',
        name: 'Natural Ice Cream',
        description: 'All-natural ice cream made with organic ingredients',
        isActive: true,
        sortOrder: 2,
        branchId: state.settings.currentBranchId,
        createdAt: new Date()
      },
      {
        id: '3',
        name: 'Italian Ice Cream',
        description: 'Authentic Italian gelato and ice cream',
        isActive: true,
        sortOrder: 3,
        branchId: state.settings.currentBranchId,
        createdAt: new Date()
      },
      {
        id: '4',
        name: 'Juices',
        description: 'Fresh fruit juices and smoothies',
        isActive: true,
        sortOrder: 4,
        branchId: state.settings.currentBranchId,
        createdAt: new Date()
      },
      {
        id: '5',
        name: 'Toppings',
        description: 'Delicious toppings and add-ons',
        isActive: true,
        sortOrder: 5,
        branchId: state.settings.currentBranchId,
        createdAt: new Date()
      }
    ];

    dispatch({ type: 'SET_CATEGORIES', payload: mockCategories });
  };

  useEffect(() => {
    if (state.isDbReady && state.settings.currentBranchId) {
      loadCategories();
    }
  }, [state.isDbReady, state.settings.currentBranchId]);

  const addCategory = async (categoryData: Omit<Category, 'id' | 'createdAt'>) => {
    try {
      const newCategory: Category = {
        ...categoryData,
        id: Date.now().toString(),
        branchId: state.settings.currentBranchId,
        createdAt: new Date()
      };

      // Save to database
      await dbService.createCategory(newCategory);
      
      // Update local state
      dispatch({ type: 'ADD_CATEGORY', payload: newCategory });
      
      console.log('✅ Category added successfully');
    } catch (error) {
      console.error('❌ Failed to add category:', error);
      throw error;
    }
  };

  const updateCategory = async (category: Category) => {
    try {
      // Update in database
      await dbService.updateCategory(category);
      
      // Update local state
      dispatch({ type: 'UPDATE_CATEGORY', payload: category });
      
      console.log('✅ Category updated successfully');
    } catch (error) {
      console.error('❌ Failed to update category:', error);
      throw error;
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      // Delete from database
      await dbService.deleteCategory(id);
      
      // Update local state
      dispatch({ type: 'DELETE_CATEGORY', payload: id });
      
      console.log('✅ Category deleted successfully');
    } catch (error) {
      console.error('❌ Failed to delete category:', error);
      throw error;
    }
  };

  return {
    categories: state.categories,
    addCategory,
    updateCategory,
    deleteCategory,
    loadCategories
  };
}