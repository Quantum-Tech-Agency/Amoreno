import { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { dbService } from '../services/database';
import { Product } from '../types';

export function useProducts() {
  const { state, dispatch } = useApp();

  const loadProducts = async () => {
    try {
      console.log('🔄 Loading products for branch:', state.settings.currentBranchId);
      
      // First try to load from database
      if (state.isDbReady && state.settings.currentBranchId) {
        const products = await dbService.getProducts(state.settings.currentBranchId);
        if (products.length > 0) {
          dispatch({ type: 'SET_PRODUCTS', payload: products });
          // Also save to localStorage as backup
          localStorage.setItem('app_products', JSON.stringify(products));
          console.log(`✅ Loaded ${products.length} products for branch ${state.settings.currentBranchId}`);
          return;
        }
      }
    } catch (error) {
      console.error('Failed to load products from database:', error);
    }

    // Fallback to localStorage
    const savedProducts = localStorage.getItem('app_products');
    if (savedProducts) {
      try {
        const products = JSON.parse(savedProducts);
        // Filter products for current branch
        const branchProducts = products.filter((p: Product) => 
          p.branchId === state.settings.currentBranchId
        );
        
        if (branchProducts.length > 0) {
          dispatch({ type: 'SET_PRODUCTS', payload: branchProducts });
          console.log(`✅ Loaded ${branchProducts.length} products from localStorage for branch ${state.settings.currentBranchId}`);
          return;
        } else {
          console.log('⚠️ No products found for current branch in localStorage, loading mock data');
        }
      } catch (error) {
        console.error('Failed to load products from localStorage:', error);
      }
    }

    // If no products exist, load mock data
    loadMockProducts();
  };

  const loadMockProducts = () => {
    const mockProducts: Product[] = [
      {
        id: '1',
        name: 'بەستەڵەکی ڤانیلا',
        description: 'بەستەڵەکی نەرمی کلاسیکی ڤانیلا',
        categoryId: '1',
        category: 'بەستەڵەکی نەرم',
        basePrice: 7500, // 5000 IQD
        image: 'https://images.pexels.com/photos/1362534/pexels-photo-1362534.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v1', name: 'کوپ', price: 0, type: 'container' },
          { id: 'v2', name: 'کۆن', price: 750, type: 'container' },
          { id: 'v3', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v4', name: 'ناوەند', price: 2250, type: 'size' },
          { id: 'v5', name: 'گەورە', price: 4500, type: 'size' }
        ],
        branchId: state.settings.currentBranchId
      },
      {
        id: '2',
        name: 'بەستەڵەکی چۆکلێت',
        description: 'بەستەڵەکی نەرمی چۆکلێتی دەوڵەمەند',
        categoryId: '1',
        category: 'بەستەڵەکی نەرم',
        basePrice: 8250,
        image: 'https://images.pexels.com/photos/2373520/pexels-photo-2373520.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v1', name: 'کوپ', price: 0, type: 'container' },
          { id: 'v2', name: 'کۆن', price: 750, type: 'container' },
          { id: 'v3', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v4', name: 'ناوەند', price: 2250, type: 'size' },
          { id: 'v5', name: 'گەورە', price: 4500, type: 'size' }
        ],
        branchId: state.settings.currentBranchId
      },
      {
        id: '3',
        name: 'بەستەڵەکی فرۆڵە',
        description: 'بەستەڵەکی سروشتی فرۆڵە لەگەڵ میوەی ڕاستەقینە',
        categoryId: '2',
        category: 'بەستەڵەکی سروشتی',
        basePrice: 10500,
        image: 'https://images.pexels.com/photos/1352278/pexels-photo-1352278.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v1', name: 'کوپ', price: 0, type: 'container' },
          { id: 'v2', name: 'کۆن', price: 750, type: 'container' },
          { id: 'v3', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v4', name: 'ناوەند', price: 2250, type: 'size' },
          { id: 'v5', name: 'گەورە', price: 4500, type: 'size' }
        ],
        branchId: state.settings.currentBranchId
      },
      {
        id: '4',
        name: 'جێلاتۆی پستە',
        description: 'جێلاتۆی ئیتاڵی ڕاستەقینەی پستە',
        categoryId: '3',
        category: 'بەستەڵەکی ئیتاڵی',
        basePrice: 12000,
        image: 'https://images.pexels.com/photos/1294943/pexels-photo-1294943.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v1', name: 'کوپ', price: 0, type: 'container' },
          { id: 'v2', name: 'کۆن', price: 750, type: 'container' },
          { id: 'v3', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v4', name: 'ناوەند', price: 2250, type: 'size' },
          { id: 'v5', name: 'گەورە', price: 4500, type: 'size' }
        ],
        branchId: state.settings.currentBranchId
      },
      {
        id: '5',
        name: 'ئاوی پرتەقاڵ',
        description: 'ئاوی پرتەقاڵی تازە گوشراو',
        categoryId: '4',
        category: 'ئاوەکان',
        basePrice: 6000,
        image: 'https://images.pexels.com/photos/1343502/pexels-photo-1343502.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v6', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v7', name: 'ناوەند', price: 1500, type: 'size' },
          { id: 'v8', name: 'گەورە', price: 3000, type: 'size' }
        ],
        branchId: state.settings.currentBranchId
      },
      {
        id: '6',
        name: 'ڕەنگە ڕەنگەکان',
        description: 'ڕەنگە ڕەنگەکانی ڕەنگاوڕەنگ',
        categoryId: '5',
        category: 'زیادکراوەکان',
        basePrice: 750,
        image: 'https://images.pexels.com/photos/1332306/pexels-photo-1332306.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [],
        branchId: state.settings.currentBranchId
      },
      {
        id: '7',
        name: 'سۆسی چۆکلێت',
        description: 'سۆسی چۆکلێتی گەرم',
        categoryId: '5',
        category: 'زیادکراوەکان',
        basePrice: 1500,
        image: 'https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [],
        branchId: state.settings.currentBranchId
      }
    ];

    dispatch({ type: 'SET_PRODUCTS', payload: mockProducts });
    // Save to localStorage
    localStorage.setItem('app_products', JSON.stringify(mockProducts));
    console.log('✅ Loaded mock products');
  };

  // Load products when branch changes or on initial load
  useEffect(() => {
    loadProducts();
  }, [state.isDbReady, state.settings.currentBranchId]);

  const addProduct = async (product: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      branchId: state.settings.currentBranchId
    };
    
    try {
      // Try to save to database first
      if (state.isDbReady) {
        await dbService.createProduct(newProduct);
        console.log('✅ Product saved to database successfully');
      }
    } catch (error) {
      console.error('❌ Failed to save product to database:', error);
    }
    
    // Always update local state
    dispatch({ type: 'ADD_PRODUCT', payload: newProduct });
    
    // Update localStorage
    updateLocalStorageProducts(prevProducts => [...prevProducts, newProduct]);
    
    console.log('✅ Product saved to local storage');
    return newProduct;
  };

  const updateProduct = async (product: Product) => {
    try {
      // Try to save to database first
      if (state.isDbReady) {
        await dbService.updateProduct(product);
        console.log('✅ Product updated in database successfully');
      }
    } catch (error) {
      console.error('❌ Failed to update product in database:', error);
    }
    
    // Always update local state
    dispatch({ type: 'UPDATE_PRODUCT', payload: product });
    
    // Update localStorage
    updateLocalStorageProducts(prevProducts => 
      prevProducts.map((p: Product) => p.id === product.id ? product : p)
    );
    
    console.log('✅ Product updated in local storage');
    return product;
  };

  const deleteProduct = async (id: string) => {
    try {
      console.log(`🗑️ Deleting product with ID: ${id}`);
      
      // Try to delete from database first
      if (state.isDbReady) {
        await dbService.deleteProduct(id);
        console.log('✅ Product deleted from database successfully');
      }
      
      // Always update local state
      dispatch({ type: 'DELETE_PRODUCT', payload: id });
      
      // Update localStorage by removing the product
      updateLocalStorageProducts(prevProducts => 
        prevProducts.filter((p: Product) => p.id !== id)
      );
      
      console.log('✅ Product deleted from local storage');
    } catch (error) {
      console.error('❌ Failed to delete product:', error);
      throw error;
    }
  };

  // Helper function to update localStorage products
  const updateLocalStorageProducts = (updateFn: (prevProducts: any[]) => any[]) => {
    try {
      // Get all existing products from localStorage
      const savedProducts = localStorage.getItem('app_products');
      const existingProducts = savedProducts ? JSON.parse(savedProducts) : [];
      
      // Apply the update function
      const updatedProducts = updateFn(existingProducts);
      
      // Save back to localStorage
      localStorage.setItem('app_products', JSON.stringify(updatedProducts));
      console.log('✅ Updated products in localStorage');
    } catch (error) {
      console.error('❌ Failed to update products in localStorage:', error);
    }
  };

  return {
    products: state.products,
    addProduct,
    updateProduct,
    deleteProduct,
    loadProducts
  };
}