import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Order, Product } from '../types';

interface SyncStatus {
  isOnline: boolean;
  pendingOrders: number;
  lastSync: Date | null;
  isSyncing: boolean;
}

export function useOfflineSync() {
  const { state, dispatch } = useApp();
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    isOnline: navigator.onLine,
    pendingOrders: 0,
    lastSync: null,
    isSyncing: false
  });

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setSyncStatus(prev => ({ ...prev, isOnline: true }));
      syncPendingData();
    };

    const handleOffline = () => {
      setSyncStatus(prev => ({ ...prev, isOnline: false }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load offline data on startup
  useEffect(() => {
    loadOfflineData();
  }, []);

  const saveToLocalStorage = (key: string, data: any) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
    }
  };

  const loadFromLocalStorage = (key: string) => {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Failed to load from localStorage:', error);
      return null;
    }
  };

  const loadOfflineData = () => {
    // Load orders
    const offlineOrders = loadFromLocalStorage('offline_orders') || [];
    const syncedOrders = loadFromLocalStorage('synced_orders') || [];
    const allOrders = [...syncedOrders, ...offlineOrders];
    
    if (allOrders.length > 0) {
      dispatch({ type: 'SET_ORDERS', payload: allOrders });
    }

    // Load products
    const offlineProducts = loadFromLocalStorage('offline_products');
    if (offlineProducts) {
      dispatch({ type: 'SET_PRODUCTS', payload: offlineProducts });
    }

    // Update pending count
    setSyncStatus(prev => ({ 
      ...prev, 
      pendingOrders: offlineOrders.length,
      lastSync: loadFromLocalStorage('last_sync') ? new Date(loadFromLocalStorage('last_sync')) : null
    }));
  };

  const saveOrderOffline = (order: Order) => {
    const offlineOrders = loadFromLocalStorage('offline_orders') || [];
    const updatedOrders = [...offlineOrders, { ...order, needsSync: true }];
    saveToLocalStorage('offline_orders', updatedOrders);
    
    setSyncStatus(prev => ({ ...prev, pendingOrders: updatedOrders.length }));
  };

  const syncPendingData = async () => {
    if (!syncStatus.isOnline || syncStatus.isSyncing) return;

    setSyncStatus(prev => ({ ...prev, isSyncing: true }));

    try {
      const offlineOrders = loadFromLocalStorage('offline_orders') || [];
      
      if (offlineOrders.length > 0) {
        // Simulate API sync - replace with actual API calls
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Move offline orders to synced orders
        const syncedOrders = loadFromLocalStorage('synced_orders') || [];
        const allSyncedOrders = [...syncedOrders, ...offlineOrders.map((order: any) => ({ ...order, needsSync: false }))];
        
        saveToLocalStorage('synced_orders', allSyncedOrders);
        saveToLocalStorage('offline_orders', []);
        saveToLocalStorage('last_sync', new Date().toISOString());
        
        // Update state
        dispatch({ type: 'SET_ORDERS', payload: allSyncedOrders });
        
        setSyncStatus(prev => ({ 
          ...prev, 
          pendingOrders: 0,
          lastSync: new Date()
        }));
      }
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setSyncStatus(prev => ({ ...prev, isSyncing: false }));
    }
  };

  const forcSync = () => {
    if (syncStatus.isOnline) {
      syncPendingData();
    }
  };

  return {
    syncStatus,
    saveOrderOffline,
    syncPendingData: forcSync,
    saveToLocalStorage,
    loadFromLocalStorage
  };
}