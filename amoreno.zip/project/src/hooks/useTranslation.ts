import { useApp } from '../context/AppContext';
import { translations, Translation } from '../i18n/translations';

export function useTranslation() {
  const { state } = useApp();
  const currentLanguage = state.settings.language;

  const t = (key: keyof Translation): string => {
    return translations[currentLanguage]?.[key] || translations.en[key] || key;
  };

  return { t, currentLanguage };
}