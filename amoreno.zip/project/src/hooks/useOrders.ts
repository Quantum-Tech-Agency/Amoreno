import { useApp } from '../context/AppContext';
import { useOfflineSync } from './useOfflineSync';
import { dbService } from '../services/database';
import { Order, OrderItem } from '../types';

export function useOrders() {
  const { state, dispatch } = useApp();
  const { syncStatus, saveOrderOffline } = useOfflineSync();

  const createOrder = async (items: OrderItem[], customerName?: string, customerNote?: string) => {
    if (!state.user) return;

    const subtotal = items.reduce((sum, item) => sum + item.total, 0);
    const tax = 0; // Tax removed
    const total = subtotal; // No tax added

    const order: Order = {
      id: Date.now().toString(),
      orderNumber: `ORD-${Date.now().toString().slice(-6)}`,
      items,
      subtotal,
      tax,
      discount: 0,
      total,
      paymentMethod: 'cash',
      status: 'completed', // Always completed automatically
      customerName: customerName || null,
      customerNote: customerNote || null,
      cashierId: state.user.id,
      cashierName: `${state.user.firstName} ${state.user.lastName}`,
      branchId: state.settings.currentBranchId,
      createdAt: new Date(),
      completedAt: new Date() // Set completion time immediately
    };

    // Save to database
    try {
      await dbService.createOrder(order);
      dispatch({ type: 'ADD_ORDER', payload: order });
    } catch (error) {
      console.error('Failed to save order to database:', error);
      // If offline, save to offline storage
      if (!syncStatus.isOnline) {
        saveOrderOffline(order);
      }
    }
    
    return order;
  };

  const updateOrder = async (order: Order) => {
    dispatch({ type: 'UPDATE_ORDER', payload: order });
    
    // If offline, save to offline storage
    if (!syncStatus.isOnline) {
      saveOrderOffline(order);
    }
  };

  const cancelOrder = (orderId: string) => {
    const order = state.orders.find(o => o.id === orderId);
    if (order) {
      const updatedOrder = {
        ...order,
        status: 'cancelled' as const
      };
      dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
      
      // If offline, save to offline storage
      if (!syncStatus.isOnline) {
        saveOrderOffline(updatedOrder);
      }
    }
  };

  const refundOrder = (orderId: string) => {
    const order = state.orders.find(o => o.id === orderId);
    if (order) {
      const updatedOrder = {
        ...order,
        status: 'refunded' as const
      };
      dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
      
      // If offline, save to offline storage
      if (!syncStatus.isOnline) {
        saveOrderOffline(updatedOrder);
      }
    }
  };

  return {
    orders: state.orders,
    createOrder,
    updateOrder,
    cancelOrder,
    refundOrder,
    syncStatus
  };
}