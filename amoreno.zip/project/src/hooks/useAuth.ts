import { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { dbService } from '../services/database';
import { User } from '../types';

export function useAuth() {
  const { state, dispatch } = useApp();

  const login = async (username: string, password: string): Promise<boolean> => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      console.log(`🔑 Attempting login for user: ${username}`);
      
      // Find user across all branches
      const user = await dbService.authenticateUser(username, password);
      
      if (user) {
        // Remove password from user object before storing
        const { password: _, ...userWithoutPassword } = user;
        
        // Set the user
        dispatch({ type: 'SET_USER', payload: userWithoutPassword });
        
        // Switch to user's branch automatically
        const newSettings = { ...state.settings, currentBranchId: user.branchId };
        dispatch({ type: 'SET_SETTINGS', payload: newSettings });
        localStorage.setItem('app_settings', JSON.stringify(newSettings));
        
        // Load branch-specific data
        await loadBranchData(user.branchId);
        
        // Store user session
        localStorage.setItem('user', JSON.stringify(userWithoutPassword));
        localStorage.setItem('currentBranchId', user.branchId);
        
        console.log(`✅ User ${username} logged in to branch: ${user.branchId}`);
        
        dispatch({ type: 'SET_LOADING', payload: false });
        return true;
      }
      
      // If database authentication fails, try fallback authentication
      console.log('⚠️ Database authentication failed, trying fallback authentication');
      const fallbackUser = authenticateFallbackUser(username, password);
      
      if (fallbackUser) {
        // Set the user
        dispatch({ type: 'SET_USER', payload: fallbackUser });
        
        // Switch to user's branch automatically
        const newSettings = { ...state.settings, currentBranchId: fallbackUser.branchId };
        dispatch({ type: 'SET_SETTINGS', payload: newSettings });
        localStorage.setItem('app_settings', JSON.stringify(newSettings));
        
        // Load branch-specific data
        await loadBranchData(fallbackUser.branchId);
        
        // Store user session
        localStorage.setItem('user', JSON.stringify(fallbackUser));
        localStorage.setItem('currentBranchId', fallbackUser.branchId);
        
        console.log(`✅ User ${username} logged in using fallback authentication`);
        
        dispatch({ type: 'SET_LOADING', payload: false });
        return true;
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
      return false;
    } catch (error) {
      console.error('Login failed:', error);
      
      // Try fallback authentication if database fails
      console.log('⚠️ Database login failed, trying fallback authentication');
      const fallbackUser = authenticateFallbackUser(username, password);
      
      if (fallbackUser) {
        // Set the user
        dispatch({ type: 'SET_USER', payload: fallbackUser });
        
        // Switch to user's branch automatically
        const newSettings = { ...state.settings, currentBranchId: fallbackUser.branchId };
        dispatch({ type: 'SET_SETTINGS', payload: newSettings });
        localStorage.setItem('app_settings', JSON.stringify(newSettings));
        
        // Load branch-specific data
        await loadBranchData(fallbackUser.branchId);
        
        // Store user session
        localStorage.setItem('user', JSON.stringify(fallbackUser));
        localStorage.setItem('currentBranchId', fallbackUser.branchId);
        
        console.log(`✅ User ${username} logged in using fallback authentication`);
        
        dispatch({ type: 'SET_LOADING', payload: false });
        return true;
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
      return false;
    }
  };

  // Fallback authentication for when database is not available
  const authenticateFallbackUser = (username: string, password: string): User | null => {
    // Hardcoded demo accounts for fallback
    const demoAccounts = [
      { id: 'user-1', username: 'admin_main', email: 'admin.main@icecream.com', role: 'admin', firstName: 'ئەحمەد', lastName: 'حەسەن', password: 'password', branchId: 'branch-1', isActive: true, createdAt: new Date() },
      { id: 'user-2', username: 'cashier_main', email: 'cashier.main@icecream.com', role: 'cashier', firstName: 'فاتیمە', lastName: 'عەلی', password: 'password', branchId: 'branch-1', isActive: true, createdAt: new Date() },
      { id: 'user-3', username: 'admin_north', email: 'admin.north@icecream.com', role: 'admin', firstName: 'عومەر', lastName: 'محەمەد', password: 'password', branchId: 'branch-2', isActive: true, createdAt: new Date() },
      { id: 'user-4', username: 'cashier_north', email: 'cashier.north@icecream.com', role: 'cashier', firstName: 'زارا', lastName: 'ئەحمەد', password: 'password', branchId: 'branch-2', isActive: true, createdAt: new Date() },
      { id: 'user-5', username: 'admin_south', email: 'admin.south@icecream.com', role: 'admin', firstName: 'کەریم', lastName: 'سەلیم', password: 'password', branchId: 'branch-3', isActive: true, createdAt: new Date() },
      { id: 'user-6', username: 'cashier_south', email: 'cashier.south@icecream.com', role: 'cashier', firstName: 'لەیلا', lastName: 'ڕەشید', password: 'password', branchId: 'branch-3', isActive: true, createdAt: new Date() },
      { id: 'user-owner', username: 'owner', email: 'owner@icecream.com', role: 'owner', firstName: 'سەلام', lastName: 'کوردستان', password: 'password', branchId: 'branch-1', isActive: true, createdAt: new Date() }
    ];
    
    const user = demoAccounts.find(u => u.username === username && u.password === password);
    
    if (user) {
      // Remove password before returning
      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword as User;
    }
    
    return null;
  };

  const loadBranchData = async (branchId: string) => {
    try {
      console.log(`🔄 Loading data for branch: ${branchId}`);
      
      // Load users for the branch
      const users = await dbService.getUsers(branchId);
      dispatch({ type: 'SET_USERS', payload: users });
      console.log(`✅ Loaded ${users.length} users for branch ${branchId}`);
      
      // Load products for the branch
      const products = await dbService.getProducts(branchId);
      dispatch({ type: 'SET_PRODUCTS', payload: products });
      
      // Also update localStorage with the products
      localStorage.setItem('app_products', JSON.stringify(products));
      console.log(`✅ Loaded ${products.length} products for branch ${branchId}`);
      
      // Load categories for the branch
      const categories = await dbService.getCategories(branchId);
      dispatch({ type: 'SET_CATEGORIES', payload: categories });
      console.log(`✅ Loaded ${categories.length} categories for branch ${branchId}`);
      
      // Load orders for the branch
      const orders = await dbService.getOrders(branchId);
      dispatch({ type: 'SET_ORDERS', payload: orders });
      console.log(`✅ Loaded ${orders.length} orders for branch ${branchId}`);
      
      // Load customers for the branch
      const customers = await dbService.getCustomers(branchId);
      dispatch({ type: 'SET_CUSTOMERS', payload: customers });
      console.log(`✅ Loaded ${customers.length} customers for branch ${branchId}`);
      
      console.log(`✅ Loaded all data for branch: ${branchId}`);
    } catch (error) {
      console.error('Failed to load branch data:', error);
      
      // Fallback to mock data if database fails
      console.log('⚠️ Using fallback data due to database error');
      
      // Load mock products if needed
      if (state.products.length === 0) {
        const mockProducts = getMockProducts(branchId);
        dispatch({ type: 'SET_PRODUCTS', payload: mockProducts });
        localStorage.setItem('app_products', JSON.stringify(mockProducts));
      }
      
      // Load mock categories if needed
      if (state.categories.length === 0) {
        const mockCategories = getMockCategories(branchId);
        dispatch({ type: 'SET_CATEGORIES', payload: mockCategories });
      }
    }
  };

  const getMockProducts = (branchId: string) => {
    return [
      {
        id: '1',
        name: 'بەستەڵەکی ڤانیلا',
        description: 'بەستەڵەکی نەرمی کلاسیکی ڤانیلا',
        categoryId: '1',
        category: 'بەستەڵەکی نەرم',
        basePrice: 7500,
        image: 'https://images.pexels.com/photos/1362534/pexels-photo-1362534.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v1', name: 'کوپ', price: 0, type: 'container' },
          { id: 'v2', name: 'کۆن', price: 750, type: 'container' },
          { id: 'v3', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v4', name: 'ناوەند', price: 2250, type: 'size' },
          { id: 'v5', name: 'گەورە', price: 4500, type: 'size' }
        ],
        branchId
      },
      {
        id: '2',
        name: 'بەستەڵەکی چۆکلێت',
        description: 'بەستەڵەکی نەرمی چۆکلێتی دەوڵەمەند',
        categoryId: '1',
        category: 'بەستەڵەکی نەرم',
        basePrice: 8250,
        image: 'https://images.pexels.com/photos/2373520/pexels-photo-2373520.jpeg?auto=compress&cs=tinysrgb&w=400',
        isActive: true,
        variants: [
          { id: 'v1', name: 'کوپ', price: 0, type: 'container' },
          { id: 'v2', name: 'کۆن', price: 750, type: 'container' },
          { id: 'v3', name: 'بچووک', price: 0, type: 'size' },
          { id: 'v4', name: 'ناوەند', price: 2250, type: 'size' },
          { id: 'v5', name: 'گەورە', price: 4500, type: 'size' }
        ],
        branchId
      }
    ];
  };

  const getMockCategories = (branchId: string) => {
    return [
      {
        id: '1',
        name: 'بەستەڵەکی نەرم',
        description: 'جۆرەکانی بەستەڵەکی نەرمی کرێمی',
        isActive: true,
        sortOrder: 1,
        branchId,
        createdAt: new Date()
      },
      {
        id: '2',
        name: 'بەستەڵەکی سروشتی',
        description: 'بەستەڵەکی سروشتی دروستکراو لە پێکهاتە ئۆرگانیکەکان',
        isActive: true,
        sortOrder: 2,
        branchId,
        createdAt: new Date()
      }
    ];
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
    localStorage.removeItem('user');
    localStorage.removeItem('currentBranchId');
    
    // Clear branch-specific data
    dispatch({ type: 'SET_USERS', payload: [] });
    dispatch({ type: 'SET_PRODUCTS', payload: [] });
    dispatch({ type: 'SET_CATEGORIES', payload: [] });
    dispatch({ type: 'SET_ORDERS', payload: [] });
    dispatch({ type: 'SET_CUSTOMERS', payload: [] });
  };

  const checkAuth = async () => {
    const savedUser = localStorage.getItem('user');
    const savedBranchId = localStorage.getItem('currentBranchId');
    
    if (savedUser && savedBranchId) {
      try {
        const user = JSON.parse(savedUser);
        dispatch({ type: 'SET_USER', payload: user });
        
        // Update settings with saved branch
        const newSettings = { ...state.settings, currentBranchId: savedBranchId };
        dispatch({ type: 'SET_SETTINGS', payload: newSettings });
        
        // Load branch data
        await loadBranchData(savedBranchId);
      } catch (error) {
        console.error('Failed to restore session:', error);
        logout();
      }
    }
  };

  const switchBranch = async (branchId: string) => {
    if (state.user && state.user.role === 'owner') {
      // Only owners can switch branches
      const newSettings = { ...state.settings, currentBranchId: branchId };
      dispatch({ type: 'SET_SETTINGS', payload: newSettings });
      localStorage.setItem('app_settings', JSON.stringify(newSettings));
      localStorage.setItem('currentBranchId', branchId);
      
      // Load new branch data
      await loadBranchData(branchId);
      
      console.log(`✅ Switched to branch: ${branchId}`);
      return true;
    }
    return false;
  };

  useEffect(() => {
    // Only run checkAuth after the database is ready
    if (state.isDbReady) {
      checkAuth();
    }
  }, [state.isDbReady]);

  return {
    user: state.user,
    login,
    logout,
    switchBranch,
    loadBranchData,
    isLoading: state.isLoading
  };
}