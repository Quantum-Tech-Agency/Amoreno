import React, { useState } from 'react';
import { ProductGrid } from '../components/POS/ProductGrid';
import { ProductCustomizer } from '../components/POS/ProductCustomizer';
import { OrderSummary } from '../components/POS/OrderSummary';
import { CheckoutModal } from '../components/POS/CheckoutModal';
import { useProducts } from '../hooks/useProducts';
import { useOrders } from '../hooks/useOrders';
import { useApp } from '../context/AppContext';
import { Product, OrderItem, SelectedVariant } from '../types';

export function POSView() {
  const { products } = useProducts();
  const { currentOrder, createOrder, completeOrder, setCurrentOrder } = useOrders();
  const { state } = useApp();
  
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);

  const handleProductSelect = (product: Product) => {
    if (product.category === 'toppings') {
      // Add toppings directly without customization
      addToOrder(product, [], 1);
    } else {
      setSelectedProduct(product);
    }
  };

  const addToOrder = (
    product: Product,
    variants: SelectedVariant[],
    quantity: number,
    specialInstructions?: string
  ) => {
    const variantTotal = variants.reduce((sum, variant) => sum + variant.price, 0);
    const itemTotal = (product.basePrice + variantTotal) * quantity;

    const orderItem: OrderItem = {
      id: Date.now().toString(),
      productId: product.id,
      productName: product.name,
      basePrice: product.basePrice,
      quantity,
      variants: variants,
      specialInstructions,
      total: itemTotal
    };

    setOrderItems([...orderItems, orderItem]);
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    setOrderItems(items =>
      items.map(item => {
        if (item.id === itemId) {
          const variantTotal = item.variants.reduce((sum, variant) => sum + variant.price, 0);
          return {
            ...item,
            quantity,
            total: (item.basePrice + variantTotal) * quantity
          };
        }
        return item;
      })
    );
  };

  const removeItem = (itemId: string) => {
    setOrderItems(items => items.filter(item => item.id !== itemId));
  };

  const clearOrder = () => {
    setOrderItems([]);
    setCurrentOrder(null);
  };

  const handleCheckout = () => {
    if (orderItems.length > 0) {
      const order = createOrder(orderItems);
      if (order) {
        setShowCheckout(true);
      }
    }
  };

  const handleCompleteOrder = (paymentMethod: 'cash' | 'card' | 'mobile') => {
    if (currentOrder) {
      completeOrder(currentOrder.id, paymentMethod);
      setOrderItems([]);
      setShowCheckout(false);
    }
  };

  const subtotal = orderItems.reduce((sum, item) => sum + item.total, 0);
  const tax = subtotal * state.settings.taxRate;
  const total = subtotal + tax;

  return (
    <div className="flex h-full gap-6">
      <div className="flex-1">
        <ProductGrid
          products={products}
          selectedCategory={selectedCategory}
          onProductSelect={handleProductSelect}
        />
      </div>

      <div className="w-96">
        <OrderSummary
          items={orderItems}
          subtotal={subtotal}
          tax={tax}
          total={total}
          onUpdateQuantity={updateQuantity}
          onRemoveItem={removeItem}
          onCheckout={handleCheckout}
          onClearOrder={clearOrder}
        />
      </div>

      {selectedProduct && (
        <ProductCustomizer
          product={selectedProduct}
          onAddToOrder={addToOrder}
          onClose={() => setSelectedProduct(null)}
        />
      )}

      {showCheckout && currentOrder && (
        <CheckoutModal
          order={currentOrder}
          onComplete={handleCompleteOrder}
          onClose={() => setShowCheckout(false)}
        />
      )}
    </div>
  );
}