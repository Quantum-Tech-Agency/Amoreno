import React, { useState, useEffect } from 'react';
import { Save, Upload, Bell, Shield, Globe, Receipt, Wifi, WifiOff, Palette, Users as UsersIcon, Download, Clock, Building, FileText, Trash2, Type } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useOfflineSync } from '../hooks/useOfflineSync';
import { useTranslation } from '../hooks/useTranslation';
import { useAutoBackup } from '../hooks/useAutoBackup';
import { UserManagement } from '../components/Settings/UserManagement';
import { BackupManagement } from '../components/Settings/BackupManagement';
import { BranchManagement } from '../components/Settings/BranchManagement';
import { InvoiceCustomization } from '../components/Settings/InvoiceCustomization';
import { DataManagement } from '../components/Settings/DataManagement';
import { FontManagement } from '../components/Settings/FontManagement';
import { ColorPalette } from '../types';

export function SettingsView() {
  const { state, dispatch } = useApp();
  const { syncStatus, syncPendingData } = useOfflineSync();
  const { t } = useTranslation();
  const { manualBackup, getLastBackupTime, isAutoBackupActive } = useAutoBackup();
  const [settings, setSettings] = useState(state.settings);
  const [showUserManagement, setShowUserManagement] = useState(false);
  const [showBranchManagement, setShowBranchManagement] = useState(false);
  const [showInvoiceCustomization, setShowInvoiceCustomization] = useState(false);
  const [showDataManagement, setShowDataManagement] = useState(false);
  const [showFontManagement, setShowFontManagement] = useState(false);
  const [lastBackupTime, setLastBackupTime] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [businessInfoSaveSuccess, setBusinessInfoSaveSuccess] = useState(false);

  const colorPalettes: ColorPalette[] = [
    {
      id: 'blue',
      name: t('oceanBlue'),
      primary: 'from-blue-500 to-cyan-600',
      secondary: 'from-blue-600 to-cyan-700',
      gradient: 'bg-gradient-to-r from-blue-500 to-cyan-600'
    },
    {
      id: 'purple',
      name: t('royalPurple'),
      primary: 'from-purple-500 to-pink-600',
      secondary: 'from-purple-600 to-pink-700',
      gradient: 'bg-gradient-to-r from-purple-500 to-pink-600'
    },
    {
      id: 'green',
      name: t('forestGreen'),
      primary: 'from-green-500 to-emerald-600',
      secondary: 'from-green-600 to-emerald-700',
      gradient: 'bg-gradient-to-r from-green-500 to-emerald-600'
    },
    {
      id: 'orange',
      name: t('sunsetOrange'),
      primary: 'from-orange-500 to-red-600',
      secondary: 'from-orange-600 to-red-700',
      gradient: 'bg-gradient-to-r from-orange-500 to-red-600'
    },
    {
      id: 'teal',
      name: t('tropicalTeal'),
      primary: 'from-teal-500 to-cyan-600',
      secondary: 'from-teal-600 to-cyan-700',
      gradient: 'bg-gradient-to-r from-teal-500 to-cyan-600'
    },
    {
      id: 'indigo',
      name: t('deepIndigo'),
      primary: 'from-indigo-500 to-purple-600',
      secondary: 'from-indigo-600 to-purple-700',
      gradient: 'bg-gradient-to-r from-indigo-500 to-purple-600'
    }
  ];

  // Update local settings when global settings change
  useEffect(() => {
    setSettings(state.settings);
  }, [state.settings]);

  // Update last backup time
  useEffect(() => {
    const updateBackupTime = () => {
      setLastBackupTime(getLastBackupTime());
    };
    
    updateBackupTime();
    const interval = setInterval(updateBackupTime, 60000); // Update every minute
    
    return () => clearInterval(interval);
  }, [getLastBackupTime]);

  const handleSave = () => {
    // Create a new settings object to ensure all properties are included
    const newSettings = {
      ...state.settings,
      ...settings,
      businessName: settings.businessName || 'ئەمۆرینۆ ئایسکرێم'
    };
    
    // Update the global state
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    
    // Save to localStorage for offline access
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    
    // Apply theme and language changes immediately
    applySettings(newSettings);
    
    // Show success message
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleBusinessInfoSave = () => {
    // Create a new settings object with just the business info properties
    const newSettings = {
      ...state.settings,
      businessName: settings.businessName || 'ئەمۆرینۆ ئایسکرێم',
      logo: settings.logo,
      currency: settings.currency,
      language: settings.language,
      receiptFooter: settings.receiptFooter
    };
    
    // Update the global state
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    
    // Save to localStorage for offline access
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
    
    // Apply language changes immediately
    if (newSettings.language !== state.settings.language) {
      if (newSettings.language === 'ar') {
        document.documentElement.dir = 'rtl';
        document.documentElement.lang = 'ar';
      } else {
        document.documentElement.dir = 'ltr';
        document.documentElement.lang = newSettings.language;
      }
    }
    
    // Show success message
    setBusinessInfoSaveSuccess(true);
    setTimeout(() => setBusinessInfoSaveSuccess(false), 3000);
  };

  const applySettings = (newSettings: typeof settings) => {
    // Apply theme
    if (newSettings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Apply language and RTL
    if (newSettings.language === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = newSettings.language;
    }

    // Apply color palette
    applyColorPalette(newSettings.colorPalette);
  };

  const applyColorPalette = (palette: ColorPalette) => {
    const root = document.documentElement;
    
    // Extract colors from gradient classes
    const colorMap: { [key: string]: { primary: string; secondary: string } } = {
      'blue': { primary: '#3B82F6', secondary: '#06B6D4' },
      'purple': { primary: '#8B5CF6', secondary: '#EC4899' },
      'green': { primary: '#10B981', secondary: '#059669' },
      'orange': { primary: '#F97316', secondary: '#DC2626' },
      'teal': { primary: '#14B8A6', secondary: '#06B6D4' },
      'indigo': { primary: '#6366F1', secondary: '#8B5CF6' }
    };

    const colors = colorMap[palette.id];
    if (colors) {
      root.style.setProperty('--primary-color', colors.primary);
      root.style.setProperty('--secondary-color', colors.secondary);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSettings(prev => ({ ...prev, logo: e.target?.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleColorPaletteChange = (palette: ColorPalette) => {
    setSettings(prev => ({ ...prev, colorPalette: palette }));
  };

  const handleLanguageChange = (language: string) => {
    setSettings(prev => ({ ...prev, language: language as any }));
  };

  const handleThemeChange = (theme: 'light' | 'dark') => {
    setSettings(prev => ({ ...prev, theme }));
  };

  const handleBranchChange = (branchId: string) => {
    setSettings(prev => ({ ...prev, currentBranchId: branchId }));
  };

  const handleBusinessNameChange = (name: string) => {
    setSettings(prev => ({ ...prev, businessName: name }));
  };

  const formatBackupTime = (timeString: string | null) => {
    if (!timeString) return t('never');
    
    const date = new Date(timeString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hours ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('settings')}</h1>
          <p className="text-gray-600 dark:text-gray-400">
            {t('configureSystem')}
          </p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowDataManagement(true)}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-all flex items-center"
          >
            <Trash2 className="h-5 w-5 mr-2" />
            ڕیسێتکردنی داتا
          </button>
          <button
            onClick={() => setShowInvoiceCustomization(true)}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-all flex items-center"
          >
            <FileText className="h-5 w-5 mr-2" />
            دەستکاریکردنی پسوڵە
          </button>
          <button
            onClick={() => setShowFontManagement(true)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-all flex items-center"
          >
            <Type className="h-5 w-5 mr-2" />
            بەڕێوەبردنی فۆنت
          </button>
          <button
            onClick={() => setShowBranchManagement(true)}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-all flex items-center"
          >
            <Building className="h-5 w-5 mr-2" />
            بەڕێوەبردنی لقەکان
          </button>
          <button
            onClick={() => setShowUserManagement(true)}
            className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-all flex items-center"
          >
            <UsersIcon className="h-5 w-5 mr-2" />
            {t('manageUsers')}
          </button>
          <button
            onClick={handleSave}
            className={`${settings.colorPalette.gradient} text-white px-4 py-2 rounded-lg hover:opacity-90 transition-all flex items-center`}
          >
            <Save className="h-5 w-5 mr-2" />
            {t('saveChanges')}
          </button>
        </div>
      </div>

      {/* Success Message */}
      {saveSuccess && (
        <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out">
          ڕێکخستنەکان بە سەرکەوتوویی پاشەکەوت کران!
        </div>
      )}

      {/* Business Info Save Success Message */}
      {businessInfoSaveSuccess && (
        <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out">
          زانیاریەکانی بازرگانی بە سەرکەوتوویی پاشەکەوت کران!
        </div>
      )}

      {/* Current Branch Selector */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center mb-4">
          <div className="bg-purple-100 dark:bg-purple-900/20 p-2 rounded-lg">
            <Building className="h-5 w-5 text-purple-600 dark:text-purple-400" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
            لقی ئێستا
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              لقی چالاک
            </label>
            <select
              value={settings.currentBranchId}
              onChange={(e) => handleBranchChange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {state.branches.map(branch => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-end">
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 w-full">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                هەموو کردارەکانی داتا بۆ لقی هەڵبژێردراو ئەنجام دەدرێن
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Font Settings Quick Access */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-indigo-100 dark:bg-indigo-900/20 p-2 rounded-lg">
              <Type className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
            </div>
            <div className="ml-3">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                ڕێکخستنەکانی فۆنت
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                فۆنتی تایبەت باربکە و بەکاریبهێنە لە سەرتاسەری ئەپەکەدا
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowFontManagement(true)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-all flex items-center"
          >
            <Type className="h-5 w-5 mr-2" />
            دەستکاریکردن
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-400">فۆنتی ئێستا</p>
            <p className="font-medium text-gray-900 dark:text-white">
              {settings.customFont || 'فۆنتی بنەڕەتی (Noto Sans)'}
            </p>
          </div>
          <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">پێشبینین</p>
            <p className={`text-gray-900 dark:text-white ${settings.customFont ? `font-['${settings.customFont}']` : ''}`}>
              بەستەڵەکی ڤانیلا - Vanilla Ice Cream - آيس كريم الفانيليا
            </p>
          </div>
        </div>
      </div>

      {/* Invoice Settings Quick Access */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-green-100 dark:bg-green-900/20 p-2 rounded-lg">
              <Receipt className="h-5 w-5 text-green-600 dark:text-green-400" />
            </div>
            <div className="ml-3">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                ڕێکخستنەکانی پسوڵە
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                دەستکاری شێوە و زانیاریەکانی پسوڵە و فاتورەکانت بکە
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowInvoiceCustomization(true)}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-all flex items-center"
          >
            <FileText className="h-5 w-5 mr-2" />
            دەستکاریکردن
          </button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
          <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-400">قەبارەی کاغەز</p>
            <p className="font-medium text-gray-900 dark:text-white">{state.settings.invoiceSettings?.paperSize || '80mm'}</p>
          </div>
          <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-400">قەبارەی فۆنت</p>
            <p className="font-medium text-gray-900 dark:text-white capitalize">{state.settings.invoiceSettings?.fontSize || 'medium'}</p>
          </div>
          <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-400">پیشاندانی لۆگۆ</p>
            <p className="font-medium text-gray-900 dark:text-white">{state.settings.invoiceSettings?.showLogo ? 'بەڵێ' : 'نەخێر'}</p>
          </div>
          <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-xs text-gray-600 dark:text-gray-400">ژمارەی کۆپی</p>
            <p className="font-medium text-gray-900 dark:text-white">{state.settings.invoiceSettings?.printCopies || 1}</p>
          </div>
        </div>
      </div>

      {/* Backup Management */}
      <BackupManagement 
        onManualBackup={manualBackup}
        lastBackupTime={lastBackupTime}
      />

      {/* Sync Status Card */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center mb-6">
          <div className={`p-2 rounded-lg ${syncStatus.isOnline ? 'bg-green-100 dark:bg-green-900/20' : 'bg-red-100 dark:bg-red-900/20'}`}>
            {syncStatus.isOnline ? (
              <Wifi className="h-5 w-5 text-green-600 dark:text-green-400" />
            ) : (
              <WifiOff className="h-5 w-5 text-red-600 dark:text-red-400" />
            )}
          </div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
            {t('syncStatus')}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-400">{t('connection')}</p>
            <p className={`text-lg font-bold ${syncStatus.isOnline ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {syncStatus.isOnline ? t('online') : t('offline')}
            </p>
          </div>
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-400">{t('pendingOrders')}</p>
            <p className="text-lg font-bold text-blue-600 dark:text-blue-400 number">
              {syncStatus.pendingOrders}
            </p>
          </div>
          <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-400">{t('lastSync')}</p>
            <p className="text-lg font-bold text-gray-900 dark:text-white">
              {syncStatus.lastSync ? syncStatus.lastSync.toLocaleTimeString() : t('never')}
            </p>
          </div>
        </div>

        {syncStatus.pendingOrders > 0 && syncStatus.isOnline && (
          <div className="mt-4">
            <button
              onClick={syncPendingData}
              disabled={syncStatus.isSyncing}
              className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {syncStatus.isSyncing ? t('syncing') : t('syncNow')}
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Business Information */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <div className="bg-blue-100 dark:bg-blue-900/20 p-2 rounded-lg">
                <Globe className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
                {t('businessInfo')}
              </h2>
            </div>
            <button
              onClick={handleBusinessInfoSave}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all flex items-center"
            >
              <Save className="h-4 w-4 mr-2" />
              پاشەکەوتکردن
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                ناوی سیستەم
              </label>
              <input
                type="text"
                value={settings.businessName}
                onChange={(e) => handleBusinessNameChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="ناوی سیستەم"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('systemLogo')}
              </label>
              <div className="flex items-center space-x-4">
                {settings.logo && (
                  <img src={settings.logo} alt="Logo" className="w-16 h-16 object-cover rounded-lg border border-gray-200 dark:border-gray-600" />
                )}
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="logo-upload"
                  />
                  <label
                    htmlFor="logo-upload"
                    className="cursor-pointer bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors flex items-center"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {t('uploadLogo')}
                  </label>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('currency')}
              </label>
              <select
                value={settings.currency}
                onChange={(e) => setSettings(prev => ({ ...prev, currency: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="IQD">IQD (د.ع)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="CAD">CAD ($)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('language')}
              </label>
              <select
                value={settings.language}
                onChange={(e) => handleLanguageChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="en">English</option>
                <option value="ar">العربية</option>
                <option value="ku">کوردی</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('receiptFooter')}
              </label>
              <textarea
                value={settings.receiptFooter}
                onChange={(e) => setSettings(prev => ({ ...prev, receiptFooter: e.target.value }))}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder={t('receiptMessage')}
              />
            </div>
          </div>
        </div>

        {/* Color Palette */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center mb-6">
            <div className="bg-purple-100 dark:bg-purple-900/20 p-2 rounded-lg">
              <Palette className="h-5 w-5 text-purple-600 dark:text-purple-400" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
              {t('colorPalette')}
            </h2>
          </div>

          <div className="space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {t('chooseColorScheme')}
            </p>
            <div className="grid grid-cols-2 gap-3">
              {colorPalettes.map((palette) => (
                <button
                  key={palette.id}
                  onClick={() => handleColorPaletteChange(palette)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    settings.colorPalette.id === palette.id
                      ? 'border-gray-900 dark:border-white'
                      : 'border-gray-200 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
                  }`}
                >
                  <div className={`${palette.gradient} h-8 rounded-lg mb-3`}></div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {palette.name}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Appearance */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center mb-6">
            <div className="bg-purple-100 dark:bg-purple-900/20 p-2 rounded-lg">
              <Bell className="h-5 w-5 text-purple-600 dark:text-purple-400" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
              {t('theme')}
            </h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('displayMode')}
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => handleThemeChange('light')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    settings.theme === 'light'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
                  }`}
                >
                  <div className="bg-white rounded-lg p-2 mb-2">
                    <div className="bg-gray-100 h-2 rounded mb-1"></div>
                    <div className="bg-gray-200 h-1 rounded"></div>
                  </div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{t('light')}</span>
                </button>
                <button
                  onClick={() => handleThemeChange('dark')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    settings.theme === 'dark'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
                  }`}
                >
                  <div className="bg-gray-800 rounded-lg p-2 mb-2">
                    <div className="bg-gray-600 h-2 rounded mb-1"></div>
                    <div className="bg-gray-700 h-1 rounded"></div>
                  </div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{t('dark')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Security */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center mb-6">
            <div className="bg-red-100 dark:bg-red-900/20 p-2 rounded-lg">
              <Shield className="h-5 w-5 text-red-600 dark:text-red-400" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white ml-3">
              {t('securitySettings')}
            </h2>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                  {t('requirePinVoids')}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {t('requireManagerPin')}
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                  {t('autoLogout')}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {t('autoLogoutInactivity')}
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                  {t('auditLogging')}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {t('logSystemActions')}
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Data Management Modal */}
      {showDataManagement && (
        <DataManagement onClose={() => setShowDataManagement(false)} />
      )}

      {/* Invoice Customization Modal */}
      {showInvoiceCustomization && (
        <InvoiceCustomization onClose={() => setShowInvoiceCustomization(false)} />
      )}

      {/* Font Management Modal */}
      {showFontManagement && (
        <FontManagement onClose={() => setShowFontManagement(false)} />
      )}

      {/* Branch Management Modal */}
      {showBranchManagement && (
        <BranchManagement onClose={() => setShowBranchManagement(false)} />
      )}

      {/* User Management Modal */}
      {showUserManagement && (
        <UserManagement onClose={() => setShowUserManagement(false)} />
      )}
    </div>
  );
}