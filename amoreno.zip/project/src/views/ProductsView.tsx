import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit, Trash2, Package, FolderPlus, Folder, AlertTriangle } from 'lucide-react';
import { useProducts } from '../hooks/useProducts';
import { useCategories } from '../hooks/useCategories';
import { useTranslation } from '../hooks/useTranslation';
import { Product, Category } from '../types';
import { CategoryManagement } from '../components/Products/CategoryManagement';
import { ProductForm } from '../components/Products/ProductForm';
import { useApp } from '../context/AppContext';

export function ProductsView() {
  const { products, addProduct, updateProduct, deleteProduct, loadProducts } = useProducts();
  const { categories } = useCategories();
  const { t } = useTranslation();
  const { state } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [showCategoryManagement, setShowCategoryManagement] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [deleteSuccess, setDeleteSuccess] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Reload products when component mounts or when branch changes
  useEffect(() => {
    loadProducts();
  }, [state.settings.currentBranchId]);

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.categoryId === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddProduct = async (productData: Omit<Product, 'id'>) => {
    setIsLoading(true);
    try {
      await addProduct(productData);
      setShowAddForm(false);
      
      // Show success message
      const successMessage = document.createElement('div');
      successMessage.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out';
      successMessage.textContent = 'بەرهەم بە سەرکەوتوویی زیادکرا!';
      document.body.appendChild(successMessage);
      
      setTimeout(() => {
        if (successMessage.parentNode) {
          document.body.removeChild(successMessage);
        }
      }, 3000);
      
      // Reload products to ensure UI is in sync
      await loadProducts();
    } catch (error) {
      console.error('Failed to add product:', error);
      
      // Show error message
      const errorMessage = document.createElement('div');
      errorMessage.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out';
      errorMessage.textContent = 'هەڵەیەک ڕوویدا لە زیادکردنی بەرهەم!';
      document.body.appendChild(errorMessage);
      
      setTimeout(() => {
        if (errorMessage.parentNode) {
          document.body.removeChild(errorMessage);
        }
      }, 3000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateProduct = async (productData: Product) => {
    setIsLoading(true);
    try {
      await updateProduct(productData);
      setEditingProduct(null);
      
      // Show success message
      const successMessage = document.createElement('div');
      successMessage.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out';
      successMessage.textContent = 'بەرهەم بە سەرکەوتوویی نوێکرایەوە!';
      document.body.appendChild(successMessage);
      
      setTimeout(() => {
        if (successMessage.parentNode) {
          document.body.removeChild(successMessage);
        }
      }, 3000);
      
      // Reload products to ensure UI is in sync
      await loadProducts();
    } catch (error) {
      console.error('Failed to update product:', error);
      
      // Show error message
      const errorMessage = document.createElement('div');
      errorMessage.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-out';
      errorMessage.textContent = 'هەڵەیەک ڕوویدا لە نوێکردنەوەی بەرهەم!';
      document.body.appendChild(errorMessage);
      
      setTimeout(() => {
        if (errorMessage.parentNode) {
          document.body.removeChild(errorMessage);
        }
      }, 3000);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (confirm('دڵنیایت لە سڕینەوەی ئەم بەرهەمە؟')) {
      setIsLoading(true);
      try {
        await deleteProduct(id);
        
        // Show success message
        setDeleteSuccess('بەرهەم بە سەرکەوتوویی سڕایەوە');
        setTimeout(() => setDeleteSuccess(null), 3000);
        
        // Reload products to ensure UI is in sync with database
        await loadProducts();
      } catch (error) {
        console.error('Failed to delete product:', error);
        setDeleteError('هەڵەیەک ڕوویدا لە سڕینەوەی بەرهەم');
        setTimeout(() => setDeleteError(null), 3000);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
  };

  const formatPrice = (price: number) => {
    return `${price.toLocaleString()} د.ع`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('products')}</h1>
          <p className="text-gray-600 dark:text-gray-400">
            {t('manageProducts')}
          </p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowCategoryManagement(true)}
            className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-all flex items-center"
            disabled={isLoading}
          >
            <Folder className="h-5 w-5 mr-2" />
            {t('manageCategories')}
          </button>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-cyan-700 transition-all flex items-center"
            disabled={isLoading}
          >
            <Plus className="h-5 w-5 mr-2" />
            {t('addProduct')}
          </button>
        </div>
      </div>

      {/* Success/Error Messages */}
      {deleteSuccess && (
        <div className="bg-green-100 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200 p-3 rounded-lg">
          {deleteSuccess}
        </div>
      )}
      
      {deleteError && (
        <div className="bg-red-100 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200 p-3 rounded-lg">
          {deleteError}
        </div>
      )}

      {/* Loading Indicator */}
      {isLoading && (
        <div className="bg-blue-100 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-200 p-3 rounded-lg flex items-center">
          <div className="animate-spin rounded-full h-5 w-5 border-2 border-blue-600 border-t-transparent mr-3"></div>
          <span>چاوەڕوانبە...</span>
        </div>
      )}

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row md:space-x-4 space-y-3 md:space-y-0">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t('search') + ' ' + t('products').toLowerCase() + '...'}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="all">{t('allItems')}</option>
          {categories.filter(c => c.isActive).map(category => (
            <option key={category.id} value={category.id}>{category.name}</option>
          ))}
        </select>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="aspect-square bg-gray-100 dark:bg-gray-700">
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="h-12 w-12 text-gray-400" />
                </div>
              )}
            </div>

            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    {product.name}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {product.category}
                  </p>
                </div>
                <span className="text-lg font-bold text-blue-600 dark:text-blue-400 number">
                  {formatPrice(product.basePrice)}
                </span>
              </div>

              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
                {product.description}
              </p>

              <div className="flex items-center justify-between mb-4">
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(product)}
                    className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                    title={t('edit')}
                    disabled={isLoading}
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                    title={t('delete')}
                    disabled={isLoading}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className={`text-xs px-2 py-1 rounded-full text-center ${
                product.isActive
                  ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                  : 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400'
              }`}>
                {product.isActive ? t('active') : t('inactive')}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400 text-lg font-medium">
            {searchTerm || selectedCategory !== 'all' ? 'هیچ بەرهەمێک نەدۆزرایەوە' : 'هیچ بەرهەمێک زیاد نەکراوە'}
          </p>
          <p className="text-gray-400 dark:text-gray-500 mt-2">
            {searchTerm || selectedCategory !== 'all' ? 
              'تکایە هەوڵبدە بە وشەیەکی تر بگەڕێیت یان جۆرێکی تر هەڵبژێریت' : 
              'کلیک لە دوگمەی "زیادکردنی بەرهەم" بکە بۆ دەستپێکردن'}
          </p>
          
          {searchTerm === '' && selectedCategory === 'all' && (
            <button
              onClick={() => setShowAddForm(true)}
              className="mt-4 bg-gradient-to-r from-blue-500 to-cyan-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-cyan-700 transition-all flex items-center mx-auto"
              disabled={isLoading}
            >
              <Plus className="h-5 w-5 mr-2" />
              {t('addProduct')}
            </button>
          )}
        </div>
      )}

      {/* Category Management Modal */}
      {showCategoryManagement && (
        <CategoryManagement onClose={() => setShowCategoryManagement(false)} />
      )}

      {/* Product Form Modal */}
      {(showAddForm || editingProduct) && (
        <ProductForm
          product={editingProduct}
          categories={categories}
          onSave={(product) => {
            if (editingProduct) {
              handleUpdateProduct(product);
            } else {
              handleAddProduct(product);
            }
          }}
          onClose={() => {
            setShowAddForm(false);
            setEditingProduct(null);
          }}
        />
      )}
    </div>
  );
}