import React, { useState, useEffect } from 'react';
import { SimpleProductGrid } from '../components/POS/SimpleProductGrid';
import { SimpleOrderSummary } from '../components/POS/SimpleOrderSummary';
import { OrderHistory } from '../components/POS/OrderHistory';
import { OrderDetailModal } from '../components/POS/OrderDetailModal';
import { useProducts } from '../hooks/useProducts';
import { useCategories } from '../hooks/useCategories';
import { useOrders } from '../hooks/useOrders';
import { useApp } from '../context/AppContext';
import { useTranslation } from '../hooks/useTranslation';
import { useAutoBackup } from '../hooks/useAutoBackup';
import { generate80mmReceipt, printReceipt } from '../utils/printUtils';
import { Product, OrderItem, Order } from '../types';

export function MenuView() {
  const { products, loadProducts } = useProducts();
  const { categories } = useCategories();
  const { orders, createOrder } = useOrders();
  const { state } = useApp();
  const { t } = useTranslation();
  const { manualBackup } = useAutoBackup();
  const isRTL = state.settings.language === 'ar';
  const colorPalette = state.settings.colorPalette;
  
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedQuantity, setSelectedQuantity] = useState<number | null>(1);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const quantities = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  // Reload products when component mounts or when branch changes
  useEffect(() => {
    loadProducts();
  }, [state.settings.currentBranchId]);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
  };

  const handleQuantitySelect = (quantity: number) => {
    setSelectedQuantity(quantity);
  };

  const handleProductSelect = (product: Product) => {
    const quantityToAdd = selectedQuantity || 1;

    const existingItem = orderItems.find(item => item.productId === product.id);
    
    if (existingItem) {
      setOrderItems(items =>
        items.map(item =>
          item.id === existingItem.id
            ? {
                ...item,
                quantity: item.quantity + quantityToAdd,
                total: (item.quantity + quantityToAdd) * product.basePrice
              }
            : item
        )
      );
    } else {
      const orderItem: OrderItem = {
        id: Date.now().toString(),
        productId: product.id,
        productName: product.name,
        basePrice: product.basePrice,
        quantity: quantityToAdd,
        variants: [],
        total: quantityToAdd * product.basePrice
      };
      setOrderItems([...orderItems, orderItem]);
    }

    setSelectedQuantity(1);
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    setOrderItems(items =>
      items.map(item => {
        if (item.id === itemId) {
          return {
            ...item,
            quantity,
            total: quantity * item.basePrice
          };
        }
        return item;
      })
    );
  };

  const removeItem = (itemId: string) => {
    setOrderItems(items => items.filter(item => item.id !== itemId));
  };

  const clearOrder = () => {
    setOrderItems([]);
    setSelectedQuantity(1);
  };

  const handlePrint = async () => {
    if (orderItems.length === 0) return;

    try {
      // Create and complete order automatically
      const order = await createOrder(orderItems);
      if (order) {
        const printContent = generate80mmReceipt(order, state.settings, isRTL, t);
        const copies = state.settings.invoiceSettings?.printCopies || 1;
        printReceipt(printContent, copies);
        clearOrder();
      }
    } catch (error) {
      console.error('Failed to create order:', error);
    }
  };

  const handlePrintOrder = (order: Order) => {
    const printContent = generate80mmReceipt(order, state.settings, isRTL, t);
    const copies = state.settings.invoiceSettings?.printCopies || 1;
    printReceipt(printContent, copies);
  };

  const subtotal = orderItems.reduce((sum, item) => sum + item.total, 0);
  const tax = 0; // Tax removed
  const total = subtotal; // No tax added

  return (
    <div className={`flex h-full gap-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
      <div className="flex-1 flex flex-col gap-6">
        <div className="flex-1">
          <SimpleProductGrid
            products={products}
            categories={categories}
            selectedCategory={selectedCategory}
            selectedQuantity={selectedQuantity}
            onProductSelect={handleProductSelect}
            onQuantitySelect={handleQuantitySelect}
            onCategorySelect={handleCategorySelect}
          />
        </div>
        
        {/* Quantity Buttons Row - Moved to bottom */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 text-center">
            بڕ هەڵبژێرە
          </h3>
          <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
            {quantities.map((qty) => (
              <button
                key={qty}
                onClick={() => handleQuantitySelect(qty)}
                className={`aspect-square text-lg font-bold rounded-lg transition-all shadow-md hover:shadow-lg transform hover:scale-105 ${
                  selectedQuantity === qty
                    ? `${colorPalette.gradient} text-white shadow-lg`
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
                }`}
              >
                {qty}
              </button>
            ))}
          </div>
          {selectedQuantity && (
            <div className="mt-3 text-center">
              <p className={`font-medium bg-gradient-to-r ${colorPalette.primary} bg-clip-text text-transparent`}>
                هەڵبژێردراو: {selectedQuantity} - کلیک لە هەر بەرهەمێک بکە بۆ زیادکردنی ئەم بڕە
              </p>
            </div>
          )}
        </div>
        
        <div className="h-80">
          <OrderHistory
            orders={orders}
            onViewOrder={setSelectedOrder}
            onPrintOrder={handlePrintOrder}
          />
        </div>
      </div>

      <div className="w-96">
        <SimpleOrderSummary
          items={orderItems}
          subtotal={subtotal}
          tax={tax}
          total={total}
          onUpdateQuantity={updateQuantity}
          onRemoveItem={removeItem}
          onPrint={handlePrint}
          onClearOrder={clearOrder}
        />
      </div>

      <OrderDetailModal
        order={selectedOrder}
        onClose={() => setSelectedOrder(null)}
        onPrint={handlePrintOrder}
      />
    </div>
  );
}