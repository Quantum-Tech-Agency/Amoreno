import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit, Trash2, Building, MapPin, Phone, Mail, Users } from 'lucide-react';
import { dbService } from '../services/database';
import { useApp } from '../context/AppContext';
import { useTranslation } from '../hooks/useTranslation';
import { BranchManagement } from '../components/Settings/BranchManagement';
import { Branch } from '../types';

export function BranchesView() {
  const { state, dispatch } = useApp();
  const { t } = useTranslation();
  const [branches, setBranches] = useState<Branch[]>([]);
  const [showBranchManagement, setShowBranchManagement] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBranches();
  }, []);

  const loadBranches = async () => {
    try {
      setLoading(true);
      const branchData = await dbService.getBranches();
      setBranches(branchData);
      dispatch({ type: 'SET_BRANCHES', payload: branchData });
    } catch (error) {
      console.error('Failed to load branches:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredBranches = branches.filter(branch =>
    branch.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    branch.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    branch.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSwitchBranch = (branchId: string) => {
    const newSettings = { ...state.settings, currentBranchId: branchId };
    dispatch({ type: 'SET_SETTINGS', payload: newSettings });
    localStorage.setItem('app_settings', JSON.stringify(newSettings));
  };

  const handleDeleteBranch = async (id: string) => {
    if (confirm(t('confirmDeleteBranch'))) {
      // Delete branch logic would go here
      console.log('Delete branch:', id);
      await loadBranches();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('branchManagement')}</h1>
          <p className="text-gray-600 dark:text-gray-400">
            بەڕێوەبردنی لقەکان و شوێنەکانی بازرگانیت
          </p>
        </div>
        <button
          onClick={() => setShowBranchManagement(true)}
          className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-cyan-700 transition-all flex items-center"
        >
          <Plus className="h-5 w-5 mr-2" />
          {t('addBranch')}
        </button>
      </div>

      {/* Branch Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-blue-100 dark:bg-blue-900/20 p-3 rounded-lg">
              <Building className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{t('totalBranches')}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{branches.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-green-100 dark:bg-green-900/20 p-3 rounded-lg">
              <Building className="h-6 w-6 text-green-600 dark:text-green-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{t('activeBranches')}</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {branches.filter(b => b.isActive).length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-purple-100 dark:bg-purple-900/20 p-3 rounded-lg">
              <Users className="h-6 w-6 text-purple-600 dark:text-purple-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{t('currentBranch')}</p>
              <p className="text-lg font-bold text-gray-900 dark:text-white">
                {branches.find(b => b.id === state.settings.currentBranchId)?.name || 'هیچ'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="flex space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="گەڕان لە لقەکان..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Branches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBranches.map((branch) => (
          <div
            key={branch.id}
            className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm border-2 transition-all hover:shadow-lg ${
              branch.id === state.settings.currentBranchId
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-700'
            }`}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 dark:bg-blue-900/20 p-2 rounded-lg">
                    <Building className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      {branch.name}
                    </h3>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      branch.isActive
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400'
                    }`}>
                      {branch.isActive ? t('active') : t('inactive')}
                    </span>
                  </div>
                </div>
                
                {branch.id === state.settings.currentBranchId && (
                  <div className="bg-blue-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                    ئێستا
                  </div>
                )}
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="truncate">{branch.address}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Phone className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span>{branch.phone}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Mail className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="truncate">{branch.email}</span>
                </div>
              </div>

              <div className="flex space-x-2">
                {branch.id !== state.settings.currentBranchId && (
                  <button
                    onClick={() => handleSwitchBranch(branch.id)}
                    className="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                  >
                    {t('switchTo')}
                  </button>
                )}
                <button
                  onClick={() => setShowBranchManagement(true)}
                  className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  title={t('editBranch')}
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDeleteBranch(branch.id)}
                  className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                  title={t('delete') + ' ' + t('branches')}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredBranches.length === 0 && (
        <div className="text-center py-12">
          <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">
            {searchTerm ? 'هیچ لقێک نەدۆزرایەوە کە لەگەڵ گەڕانەکەت بگونجێت' : t('noBranches')}
          </p>
        </div>
      )}

      {/* Branch Management Modal */}
      {showBranchManagement && (
        <BranchManagement 
          onClose={() => {
            setShowBranchManagement(false);
            loadBranches();
          }} 
        />
      )}
    </div>
  );
}