import React, { useState, useMemo, useEffect } from 'react';
import { Calendar, DollarSign, ShoppingBag, TrendingUp, Download } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { useOrders } from '../hooks/useOrders';
import { useProducts } from '../hooks/useProducts';
import { useApp } from '../context/AppContext';
import { useAuth } from '../hooks/useAuth';
import { format, subDays, isAfter, isBefore, startOfDay, endOfDay, parseISO, setHours, setMinutes, addDays, isSameDay } from 'date-fns';

export function ReportsView() {
  const { orders } = useOrders();
  const { products } = useProducts();
  const { state } = useApp();
  const { user } = useAuth();
  const [dateRange, setDateRange] = useState('1day'); // Default to today for admin users
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startTime, setStartTime] = useState('00:00');
  const [endTime, setEndTime] = useState('23:59');

  // Set default date range to today when component mounts or when user changes
  useEffect(() => {
    if (user && (user.role === 'admin' || user.role === 'manager' || user.role === 'owner')) {
      setDateRange('1day'); // Default to today for admin users
    }
  }, [user]);

  const formatPrice = (price: number) => {
    return `${price.toLocaleString()} د.ع`;
  };

  const getDateRange = () => {
    const now = new Date();
    switch (dateRange) {
      case '1day':
        // For "Today", use isSameDay instead of start/end of day
        return { 
          start: startOfDay(now), 
          end: endOfDay(now),
          isToday: true 
        };
      case '7days':
        return { 
          start: startOfDay(subDays(now, 7)), 
          end: endOfDay(now),
          isToday: false 
        };
      case '30days':
        return { 
          start: startOfDay(subDays(now, 30)), 
          end: endOfDay(now),
          isToday: false 
        };
      case 'custom':
        if (startDate && endDate) {
          // Parse the date and time
          const [startHour, startMinute] = startTime.split(':').map(Number);
          const [endHour, endMinute] = endTime.split(':').map(Number);
          
          const startDateTime = setMinutes(setHours(parseISO(startDate), startHour), startMinute);
          const endDateTime = setMinutes(setHours(parseISO(endDate), endHour), endMinute);
          
          return { 
            start: startDateTime, 
            end: endDateTime,
            isToday: false 
          };
        }
        return { 
          start: startOfDay(subDays(now, 7)), 
          end: endOfDay(now),
          isToday: false 
        };
      default:
        return { 
          start: startOfDay(subDays(now, 7)), 
          end: endOfDay(now),
          isToday: false 
        };
    }
  };

  const filteredOrders = useMemo(() => {
    const { start, end, isToday } = getDateRange();
    const today = new Date();
    
    return orders.filter(order => {
      // Only include completed orders
      if (order.status !== 'completed') return false;
      
      // Special handling for "Today" filter to ensure all of today's orders are included
      if (isToday) {
        return isSameDay(order.createdAt, today);
      }
      
      // For other date ranges, use the standard range comparison
      return isAfter(order.createdAt, start) && isBefore(order.createdAt, end);
    });
  }, [orders, dateRange, startDate, endDate, startTime, endTime]);

  const salesData = useMemo(() => {
    const salesByDay = filteredOrders.reduce((acc, order) => {
      const day = format(order.createdAt, 'MMM dd');
      const amount = order.total; // Use the actual total without multiplying
      acc[day] = (acc[day] || 0) + amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(salesByDay).map(([day, total]) => ({
      day,
      total: Math.round(total)
    }));
  }, [filteredOrders]);

  const productSalesData = useMemo(() => {
    const productSales = filteredOrders.reduce((acc, order) => {
      order.items.forEach(item => {
        acc[item.productName] = (acc[item.productName] || 0) + item.quantity;
      });
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(productSales)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([name, quantity]) => ({ name, quantity }));
  }, [filteredOrders]);

  const paymentMethodData = useMemo(() => {
    const paymentMethods = filteredOrders.reduce((acc, order) => {
      const amount = order.total; // Use the actual total without multiplying
      acc[order.paymentMethod] = (acc[order.paymentMethod] || 0) + amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(paymentMethods).map(([method, total]) => ({
      method: method.charAt(0).toUpperCase() + method.slice(1),
      total: Math.round(total)
    }));
  }, [filteredOrders]);

  const stats = useMemo(() => {
    const totalRevenue = filteredOrders.reduce((sum, order) => sum + order.total, 0);
    const totalOrders = filteredOrders.length;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const totalItems = filteredOrders.reduce((sum, order) => sum + order.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0);

    return {
      totalRevenue,
      totalOrders,
      avgOrderValue,
      totalItems
    };
  }, [filteredOrders]);

  const COLORS = ['#EC4899', '#8B5CF6', '#06B6D4', '#10B981', '#F59E0B', '#EF4444'];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800 text-white p-3 rounded-lg shadow-lg border">
          <p className="font-medium">{label}</p>
          <p className="text-pink-400">
            {formatPrice(payload[0].value)}
          </p>
        </div>
      );
    }
    return null;
  };

  const PieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-800 text-white p-3 rounded-lg shadow-lg border">
          <p className="font-medium">{payload[0].payload.method}</p>
          <p className="text-pink-400">
            {formatPrice(payload[0].value)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">ڕاپۆرتەکان و شیکردنەوە</h1>
          <p className="text-gray-600 dark:text-gray-400">
            بەدواداچوونی ئادایی فرۆشتن و تێگەیشتنی بازرگانی
          </p>
        </div>
        <button className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-pink-600 hover:to-purple-700 transition-all flex items-center">
          <Download className="h-5 w-5 mr-2" />
          هەناردەکردنی ڕاپۆرت
        </button>
      </div>

      {/* Enhanced Date Range Filter */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <Calendar className="h-5 w-5 text-gray-400" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent"
            >
              <option value="1day">ئەمڕۆ</option>
              <option value="7days">دوایین ٧ ڕۆژ</option>
              <option value="30days">دوایین ٣٠ ڕۆژ</option>
              <option value="custom">مەودای تایبەت</option>
            </select>
          </div>
          
          {dateRange === 'custom' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              {/* Start Date & Time */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">لە</h4>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">بەروار</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">کات</label>
                    <input
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* End Date & Time */}
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">بۆ</h4>
                <div className="space-y-2">
                  <div>
                    <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">بەروار</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">کات</label>
                    <input
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Quick Time Presets */}
              <div className="md:col-span-2">
                <label className="block text-xs text-gray-500 dark:text-gray-400 mb-2">ڕێکخستنی خێرای کات</label>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      setStartTime('00:00');
                      setEndTime('23:59');
                    }}
                    className="px-3 py-1 text-xs bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full hover:bg-blue-200 dark:hover:bg-blue-900/40 transition-colors"
                  >
                    هەموو ڕۆژ
                  </button>
                  <button
                    onClick={() => {
                      // Yesterday business hours: 9:00 AM yesterday to 3:00 AM today
                      const yesterday = subDays(new Date(), 1);
                      const today = new Date();
                      setStartDate(format(yesterday, 'yyyy-MM-dd'));
                      setEndDate(format(today, 'yyyy-MM-dd'));
                      setStartTime('09:00');
                      setEndTime('03:00');
                    }}
                    className="px-3 py-1 text-xs bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 rounded-full hover:bg-purple-200 dark:hover:bg-purple-900/40 transition-colors"
                  >
                    دوێنێ (٩:٠٠ ب.ن - ٣:٠٠ د.ن)
                  </button>
                  <button
                    onClick={() => {
                      setStartTime('06:00');
                      setEndTime('12:00');
                    }}
                    className="px-3 py-1 text-xs bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-300 rounded-full hover:bg-yellow-200 dark:hover:bg-yellow-900/40 transition-colors"
                  >
                    بەیانی (٦:٠٠-١٢:٠٠)
                  </button>
                  <button
                    onClick={() => {
                      setStartTime('12:00');
                      setEndTime('18:00');
                    }}
                    className="px-3 py-1 text-xs bg-orange-100 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300 rounded-full hover:bg-orange-200 dark:hover:bg-orange-900/40 transition-colors"
                  >
                    دوای نیوەڕۆ (١٢:٠٠-١٨:٠٠)
                  </button>
                  <button
                    onClick={() => {
                      setStartTime('18:00');
                      setEndTime('23:59');
                    }}
                    className="px-3 py-1 text-xs bg-indigo-100 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded-full hover:bg-indigo-200 dark:hover:bg-indigo-900/40 transition-colors"
                  >
                    ئێوارە (١٨:٠٠-٢٤:٠٠)
                  </button>
                  <button
                    onClick={() => {
                      setStartTime('09:00');
                      setEndTime('17:00');
                    }}
                    className="px-3 py-1 text-xs bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-full hover:bg-green-200 dark:hover:bg-green-900/40 transition-colors"
                  >
                    کاتژمێری کار (٩:٠٠-١٧:٠٠)
                  </button>
                </div>
              </div>

              {/* Current Selection Display */}
              {startDate && endDate && (
                <div className="md:col-span-2 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-sm text-blue-800 dark:text-blue-200">
                    <strong>مەودای هەڵبژێردراو:</strong> {format(parseISO(startDate), 'MMM dd, yyyy')} لە {startTime} 
                    {' → '} {format(parseISO(endDate), 'MMM dd, yyyy')} لە {endTime}
                  </p>
                  <p className="text-xs text-blue-600 dark:text-blue-300 mt-1">
                    پیشاندانی داتا بۆ {filteredOrders.length} داواکاری لەم ماوەیەدا
                  </p>
                  {startDate !== endDate && endTime < startTime && (
                    <p className="text-xs text-amber-600 dark:text-amber-400 mt-1 flex items-center">
                      <span className="mr-1">⚠️</span>
                      ئەم مەودایە دەگرێتەوە لە {startDate} کاتژمێر {startTime} تا {endDate} کاتژمێر {endTime} (کاتژمێری کاری شەو)
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-green-100 dark:bg-green-900/20 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-600 dark:text-green-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">کۆی داهات</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white number">
                {formatPrice(stats.totalRevenue)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-blue-100 dark:bg-blue-900/20 p-3 rounded-lg">
              <ShoppingBag className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">کۆی داواکاریەکان</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white number">{stats.totalOrders}</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-purple-100 dark:bg-purple-900/20 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-600 dark:text-purple-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">ناوەندی نرخی داواکاری</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white number">
                {formatPrice(stats.avgOrderValue)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center">
            <div className="bg-orange-100 dark:bg-orange-900/20 p-3 rounded-lg">
              <ShoppingBag className="h-6 w-6 text-orange-600 dark:text-orange-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">شتە فرۆشراوەکان</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white number">{stats.totalItems}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">فرۆشتن بەپێی کات</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="day" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="total" stroke="#EC4899" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Payment Methods */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">ڕێگەکانی پارەدان</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={paymentMethodData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ method, percent }) => `${method} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="total"
              >
                {paymentMethodData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip content={<PieTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Top Products */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 lg:col-span-2">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">بەرهەمە زۆر فرۆشراوەکان</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={productSalesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: 'none', 
                  borderRadius: '8px',
                  color: '#F3F4F6'
                }} 
              />
              <Bar dataKey="quantity" fill="#8B5CF6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}