import React, { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';
import { User, Product, Order, AppSettings, Customer, InventoryItem, ColorPalette, Category, Branch, InvoiceSettings } from '../types';
import { dbService } from '../services/database';

interface AppState {
  user: User | null;
  users: User[];
  products: Product[];
  categories: Category[];
  orders: Order[];
  customers: Customer[];
  inventory: InventoryItem[];
  branches: Branch[];
  settings: AppSettings;
  currentOrder: Order | null;
  isLoading: boolean;
  isDbReady: boolean;
}

type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_USERS'; payload: User[] }
  | { type: 'ADD_USER'; payload: User }
  | { type: 'UPDATE_USER'; payload: User }
  | { type: 'DELETE_USER'; payload: string }
  | { type: 'SET_PRODUCTS'; payload: Product[] }
  | { type: 'ADD_PRODUCT'; payload: Product }
  | { type: 'UPDATE_PRODUCT'; payload: Product }
  | { type: 'DELETE_PRODUCT'; payload: string }
  | { type: 'SET_CATEGORIES'; payload: Category[] }
  | { type: 'ADD_CATEGORY'; payload: Category }
  | { type: 'UPDATE_CATEGORY'; payload: Category }
  | { type: 'DELETE_CATEGORY'; payload: string }
  | { type: 'SET_ORDERS'; payload: Order[] }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER'; payload: Order }
  | { type: 'SET_CURRENT_ORDER'; payload: Order | null }
  | { type: 'SET_CUSTOMERS'; payload: Customer[] }
  | { type: 'ADD_CUSTOMER'; payload: Customer }
  | { type: 'SET_INVENTORY'; payload: InventoryItem[] }
  | { type: 'UPDATE_INVENTORY'; payload: InventoryItem }
  | { type: 'SET_BRANCHES'; payload: Branch[] }
  | { type: 'ADD_BRANCH'; payload: Branch }
  | { type: 'UPDATE_BRANCH'; payload: Branch }
  | { type: 'SET_SETTINGS'; payload: AppSettings }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_DB_READY'; payload: boolean };

const defaultColorPalette: ColorPalette = {
  id: 'blue',
  name: 'شینی زەریا',
  primary: 'from-blue-500 to-cyan-600',
  secondary: 'from-blue-600 to-cyan-700',
  gradient: 'bg-gradient-to-r from-blue-500 to-cyan-600'
};

const defaultInvoiceSettings: InvoiceSettings = {
  showLogo: true,
  showBusinessInfo: true,
  showBranchInfo: true,
  showCashierInfo: true,
  showOrderNumber: true,
  showDateTime: true,
  showItemDetails: true,
  showPrices: true,
  showTax: false,
  showTotal: true,
  showPaymentMethod: true,
  showBarcode: true,
  showFooterMessage: true,
  paperSize: '80mm',
  fontSize: 'medium',
  headerText: '',
  footerText: 'سوپاس بۆ سەردانەکەت!',
  thankYouMessage: 'دووبارە وەرە!',
  includeQRCode: false,
  showItemImages: false,
  showCustomerInfo: true,
  showOrderNotes: true,
  printCopies: 1,
  autoOpenCashDrawer: false,
  useTableLayout: true
};

const initialState: AppState = {
  user: null,
  users: [],
  products: [],
  categories: [],
  orders: [],
  customers: [],
  inventory: [],
  branches: [],
  settings: {
    businessName: 'ئەمۆرینۆ ئایسکرێم',
    taxRate: 0,
    currency: 'IQD',
    theme: 'light',
    language: 'ku',
    receiptFooter: 'سوپاس بۆ سەردانەکەت!',
    colorPalette: defaultColorPalette,
    currentBranchId: 'branch-1',
    invoiceSettings: defaultInvoiceSettings,
    customFont: null
  },
  currentOrder: null,
  isLoading: false,
  isDbReady: false
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_USERS':
      return { ...state, users: action.payload };
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    case 'UPDATE_USER':
      return {
        ...state,
        users: state.users.map(u => u.id === action.payload.id ? action.payload : u)
      };
    case 'DELETE_USER':
      return {
        ...state,
        users: state.users.filter(u => u.id !== action.payload)
      };
    case 'SET_PRODUCTS':
      return { ...state, products: action.payload };
    case 'ADD_PRODUCT':
      return { ...state, products: [...state.products, action.payload] };
    case 'UPDATE_PRODUCT':
      return {
        ...state,
        products: state.products.map(p => p.id === action.payload.id ? action.payload : p)
      };
    case 'DELETE_PRODUCT':
      return {
        ...state,
        products: state.products.filter(p => p.id !== action.payload)
      };
    case 'SET_CATEGORIES':
      return { ...state, categories: action.payload };
    case 'ADD_CATEGORY':
      return { ...state, categories: [...state.categories, action.payload] };
    case 'UPDATE_CATEGORY':
      return {
        ...state,
        categories: state.categories.map(c => c.id === action.payload.id ? action.payload : c)
      };
    case 'DELETE_CATEGORY':
      return {
        ...state,
        categories: state.categories.filter(c => c.id !== action.payload)
      };
    case 'SET_ORDERS':
      return { ...state, orders: action.payload };
    case 'ADD_ORDER':
      return { ...state, orders: [action.payload, ...state.orders] };
    case 'UPDATE_ORDER':
      return {
        ...state,
        orders: state.orders.map(o => o.id === action.payload.id ? action.payload : o)
      };
    case 'SET_CURRENT_ORDER':
      return { ...state, currentOrder: action.payload };
    case 'SET_CUSTOMERS':
      return { ...state, customers: action.payload };
    case 'ADD_CUSTOMER':
      return { ...state, customers: [...state.customers, action.payload] };
    case 'SET_INVENTORY':
      return { ...state, inventory: action.payload };
    case 'UPDATE_INVENTORY':
      return {
        ...state,
        inventory: state.inventory.map(i => i.id === action.payload.id ? action.payload : i)
      };
    case 'SET_BRANCHES':
      return { ...state, branches: action.payload };
    case 'ADD_BRANCH':
      return { ...state, branches: [...state.branches, action.payload] };
    case 'UPDATE_BRANCH':
      return {
        ...state,
        branches: state.branches.map(b => b.id === action.payload.id ? action.payload : b)
      };
    case 'SET_SETTINGS':
      return { ...state, settings: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_DB_READY':
      return { ...state, isDbReady: action.payload };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Initialize database and load data
  useEffect(() => {
    const initializeApp = async () => {
      try {
        dispatch({ type: 'SET_LOADING', payload: true });
        
        console.log('🚀 Initializing application...');
        
        // Initialize SQLite database
        await dbService.initialize();
        
        // Mark database as ready (even if it failed, we'll use localStorage fallback)
        dispatch({ type: 'SET_DB_READY', payload: true });
        
        // Load branches
        try {
          const branches = await dbService.getBranches();
          if (branches.length > 0) {
            dispatch({ type: 'SET_BRANCHES', payload: branches });
            console.log('✅ Branches loaded from database');
          } else {
            // Load default branches if none exist
            const defaultBranches = [
              {
                id: 'branch-1',
                name: 'لقی سەرەکی - ناوەندی شار',
                address: '١٢٣ شەقامی سەرەکی، ناوەندی شار',
                phone: '+964 750 123 4567',
                email: 'main@icecream.com',
                isActive: true,
                createdAt: new Date(),
                settings: {
                  businessName: 'ئەمۆرینۆ ئایسکرێم',
                  taxRate: 0,
                  currency: 'IQD',
                  theme: 'light',
                  language: 'ku',
                  receiptFooter: 'سوپاس بۆ سەردانەکەت!',
                  colorPalette: defaultColorPalette
                }
              }
            ];
            dispatch({ type: 'SET_BRANCHES', payload: defaultBranches });
          }
        } catch (error) {
          console.warn('⚠️ Failed to load branches from database, using defaults');
        }
        
        // Load users for current branch
        try {
          const users = await dbService.getUsers(state.settings.currentBranchId);
          dispatch({ type: 'SET_USERS', payload: users });
          console.log('✅ Users loaded from database');
        } catch (error) {
          console.warn('⚠️ Failed to load users from database');
        }
        
        console.log('✅ App initialized successfully');
      } catch (error) {
        console.error('❌ Failed to initialize app:', error);
      } finally {
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };

    initializeApp();
  }, []);

  // Load settings from localStorage on startup
  useEffect(() => {
    const savedSettings = localStorage.getItem('app_settings');
    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings);
        // Ensure all required settings exist
        if (!settings.colorPalette) {
          settings.colorPalette = defaultColorPalette;
        }
        if (!settings.currency) {
          settings.currency = 'IQD';
        }
        if (!settings.language) {
          settings.language = 'ku';
        }
        if (!settings.currentBranchId) {
          settings.currentBranchId = 'branch-1';
        }
        if (!settings.invoiceSettings) {
          settings.invoiceSettings = defaultInvoiceSettings;
        }
        if (!settings.businessName) {
          settings.businessName = 'ئەمۆرینۆ ئایسکرێم';
        }
        if (!settings.receiptFooter) {
          settings.receiptFooter = 'سوپاس بۆ سەردانەکەت!';
        }
        // Set tax rate to 0
        settings.taxRate = 0;
        dispatch({ type: 'SET_SETTINGS', payload: settings });
        
        // Apply theme immediately
        if (settings.theme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
        
        // Apply language and RTL
        if (settings.language === 'ar') {
          document.documentElement.dir = 'rtl';
          document.documentElement.lang = 'ar';
        } else {
          document.documentElement.dir = 'ltr';
          document.documentElement.lang = settings.language;
        }
        
        // Apply custom font if set
        if (settings.customFont) {
          // Load custom fonts from localStorage
          const savedFonts = localStorage.getItem('custom_fonts');
          if (savedFonts) {
            try {
              const fonts = JSON.parse(savedFonts);
              const selectedFont = fonts.find((f: any) => f.name === settings.customFont);
              
              if (selectedFont) {
                // Apply the font
                document.documentElement.style.fontFamily = `"${settings.customFont}", "Noto Sans", system-ui, -apple-system, sans-serif`;
                
                // Ensure the font is loaded
                const fontFace = `
                  @font-face {
                    font-family: "${selectedFont.name}";
                    src: url("${selectedFont.url}") format("woff2");
                    font-weight: normal;
                    font-style: normal;
                  }
                `;
                
                // Check if the style already exists
                const existingStyle = document.querySelector(`style[data-font="${selectedFont.name}"]`);
                if (!existingStyle) {
                  const styleElement = document.createElement('style');
                  styleElement.setAttribute('data-font', selectedFont.name);
                  styleElement.textContent = fontFace;
                  document.head.appendChild(styleElement);
                }
              }
            } catch (error) {
              console.error('Failed to load custom fonts:', error);
            }
          }
        }
        
        console.log('✅ Settings loaded from localStorage');
      } catch (error) {
        console.error('❌ Failed to load settings:', error);
      }
    }
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}